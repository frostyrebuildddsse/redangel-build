#!/usr/bin/env python3
"""Correct Itanium mangling (with substitutions) for invoke<R>(u64, Args&&...), Menu:: methods and
camelCase names derived from the binary's own UI strings.
usage: nidcrack3.py symbols.json hits.json elf"""
import json, hashlib, base64, itertools, sys, re, subprocess, time
SUF = bytes.fromhex('518D64A635DED8C1E6B039B1C3E55230')
def nid(n): return base64.b64encode(hashlib.sha1(n.encode() + SUF).digest()[:8][::-1], altchars=b'+-').decode()[:11]
symp, hitsp, elfp = sys.argv[1:4]
j = json.load(open(symp))
targets = {e['name']: e for e in j['exports'] if len(e['name']) == 11}
try: hits = json.load(open(hitsp))
except Exception: hits = {}
def check(s):
    n = nid(s)
    if n in targets and n not in hits:
        hits[n] = s; print('%#x %s -> %s (size %d)' % (targets[n]['addr'], n, s, targets[n]['size']), flush=True)
        return True
    return False

BUILTIN = set('vwbcahstijlmxyfdez')
def seqid(k):
    if k == 0: return 'S_'
    k -= 1; digs = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'; s = ''
    while True:
        s = digs[k % 36] + s; k //= 36
        if k == 0: break
    return 'S' + s + '_'
def parse(t):
    """canonical type string -> (kind, payload)"""
    if t[0] in 'RPKO': return t[0], t[1:]
    if t[0] == 'A':
        m = re.match(r'A(\d+)_(.*)', t); return 'A', (m.group(1), m.group(2))
    if t.startswith('F'):
        return 'F', t
    if t[0].isdigit(): return 'N', t
    return 'B', t
def mangle(t, table):
    k, p = parse(t)
    if k == 'B': return t
    if t in table: return seqid(table.index(t))
    if k in 'RPKO':
        inner = mangle(p, table); out = k + inner
    elif k == 'A':
        out = 'A%s_%s' % (p[0], mangle(p[1], table))
    elif k == 'F':
        m = re.match(r'F(.)(.*)E$', t)  # simple: F<ret><params>E with builtin-only
        out = t
    else:
        out = t
    table.append(t)
    return out
def mangle_invoke(name, r, args, hashT='y'):
    table = [name]       # unscoped template name is a candidate
    s = '_Z%d%sI' % (len(name), name) + mangle(r, table) + 'J' + ''.join(mangle(a, table) for a in args) + 'EET_' + hashT + 'DpOT0_'
    return s
def mangle_fn(name, params, cls=None):
    table = []
    if cls:
        table.append(str(len(cls)) + cls)
        pre = '_ZN%d%s%d%sE' % (len(cls), cls, len(name), name)
    else:
        pre = '_Z%d%s' % (len(name), name)
    if not params: return pre + 'v'
    return pre + ''.join(mangle(p, table) for p in params)

# sanity vs clang output
assert mangle_invoke('invoke', '7Vector3', ['Ri', 'Ri']) == '_Z6invokeI7Vector3JRiS1_EET_yDpOT0_', mangle_invoke('invoke', '7Vector3', ['Ri', 'Ri'])
assert mangle_invoke('invoke', 'i', ['Ri', 'Rf', 'Rf', 'Rf', 'Rf', 'Ri', 'Ri']) == '_Z6invokeIiJRiRfS1_S1_S1_S0_S0_EET_yDpOT0_'
assert mangle_fn('drawFeedNotification', ['Pc', 'Pc', 'Pc'], 'Menu') == '_ZN4Menu20drawFeedNotificationEPcS0_S0_'
assert mangle_invoke('invoke', 'Pv', ['RPi']) == '_Z6invokeIPvJRPiEET_yDpOT0_'
t0 = time.time()
# ---- invoke instantiations
R = ['i', 'v', 'b', 'f', 'j', '7Vector3', 'Pc', 'PKc', 'Pv', 'y', 'h', 'Pi', 'c']
A = ['Ri', 'Rf', 'Rb', 'Rj', 'RPc', 'RPKc', 'RPv', 'RPi', 'RPf', 'Ry', 'R7Vector3', 'Rh', 'RPb', 'RPj', 'RPy', 'RK7Vector3', 'RKi', 'RKf', 'RKb', 'RKj',
     'i', 'f', 'b', 'j', 'Pc', 'PKc', 'Pv', 'Pi', 'Pf', 'y', '7Vector3', 'RA2_c', 'RA3_c', 'RA4_c', 'RA8_c', 'RA16_c', 'RA32_c', 'RA64_c', 'RA128_c', 'RA256_c', 'RKA1_c', 'RKA2_c', 'RKA3_c', 'RKA4_c', 'RKA5_c', 'RKA6_c', 'RKA7_c', 'RKA8_c', 'RKA9_c', 'RKA10_c', 'RKA11_c', 'RKA12_c', 'RKA13_c', 'RKA14_c', 'RKA15_c', 'RKA16_c', 'RKA17_c', 'RKA18_c', 'RKA19_c', 'RKA20_c', 'RKA21_c', 'RKA22_c', 'RKA23_c', 'RKA24_c', 'RKA25_c', 'RKA26_c', 'RKA27_c', 'RKA28_c', 'RKA29_c', 'RKA30_c', 'RKA31_c', 'RKA32_c']
A_small = ['Ri', 'Rf', 'Rb', 'Rj', 'RPc', 'RPKc', 'RPi', 'RPf', 'Ry', 'i', 'f', 'b', 'j', 'RPv', 'R7Vector3', 'Pi', 'Pf', 'RKA1_c']
for r in R:
    check(mangle_invoke('invoke', r, []))
    for n in (1, 2):
        for args in itertools.product(A, repeat=n): check(mangle_invoke('invoke', r, list(args)))
    for n in (3, 4):
        for args in itertools.product(A_small, repeat=n): check(mangle_invoke('invoke', r, list(args)))
print('invoke 1-4 done', time.time() - t0, flush=True)
for t in R + A:
    tb = ['pushArg']; check('_Z7pushArgI%sEvT_' % mangle(t, tb))
    tb = ['getReturn']; check('_Z9getReturnI%sET_v' % mangle(t, tb))
print('templates done', flush=True)

# ---- names: reference menu.h vocabulary + camelCase of UI strings
st = subprocess.run(['strings', '-n', '3', elfp], capture_output=True, text=True).stdout.split('\n')
phrases = set()
for s in st:
    s = re.sub(r'~[a-zA-Z_0-9]+~', ' ', s)
    ws = re.findall(r'[A-Za-z][A-Za-z0-9]*', s)
    if 1 <= len(ws) <= 5 and len(s) < 60:
        for a in range(len(ws)):
            for b in range(a + 1, min(len(ws), a + 4) + 1):
                phrases.add(tuple(ws[a:b]))
def camel(ws): return ws[0].lower() + ''.join(w[0].upper() + w[1:].lower() for w in ws[1:])
def camel2(ws): return ws[0][0].lower() + ws[0][1:] + ''.join(w[0].upper() + w[1:] for w in ws[1:])
def pascal(ws): return ''.join(w[0].upper() + w[1:] for w in ws)
names = set()
for ph in phrases:
    for f in (camel, camel2, pascal):
        n = f(list(ph)); names.add(n)
        for suf in ('Menu', 'Options', 'Submenu', 'Loop', 'Handler', 'Callback', 'KeyboardHandler', 'Option', 'Toggle', 'Func', 'Thread', 'Tick', 'Update', 'Draw', 'Init', 'Settings', 'Spawner', 'Manager'):
            names.add(n + suf)
        for pre in ('draw', 'set', 'get', 'is', 'toggle', 'update', 'do', 'apply', 'load', 'save', 'spawn', 'give', 'remove', 'clear', 'reset', 'unlock', 'on', 'handle', 'run', 'init', 'start', 'stop', 'show', 'hide', 'teleport', 'kick', 'add', 'request'):
            names.add(pre + pascal(list(ph)))
names = sorted(n for n in names if len(n) < 48)
print(len(names), 'derived names', flush=True)
P1 = ['i', 'f', 'b', 'j', 'Pc', 'PKc', 'Pi', 'Pf', 'Pb', 'y', 'Pv', 'h', '7Vector3', 'P7Vector3', 'R7Vector3', 'RK7Vector3', 'Ri', 'Rf', 'Rb']
P2 = ['i', 'f', 'b', 'Pc', 'PKc', 'j', 'Pi', 'Pf', 'Pb', '7Vector3', 'y']
glob_pre = ['', 'g_', 'g', 'b', 's_', 'm_', 'is', 'i', 'f', 'n']
for n in names:
    for gp in glob_pre: check(gp + n)
    check(mangle_fn(n, []))
    for p in P1: check(mangle_fn(n, [p]))
    for ps in itertools.product(P2, repeat=2): check(mangle_fn(n, list(ps)))
    for ps in itertools.product(['i', 'f', 'b', 'Pc', 'PKc', 'j'], repeat=3): check(mangle_fn(n, list(ps)))
print('free fns done', time.time() - t0, len(hits), flush=True)
# Menu methods (reference vocabulary + derived)
ref_methods = 'run monitorButtons drawFeedNotification tip data banner option submenu toggle scroll keyboard call vehicleSpawn bool intOption floatOption colorOption drawText playSound setupInstructions addInstruction finishInstructions positionMenuText colorEditor intScrollKeyboardHandler floatScrollKeyboardHandler setMainMenu changeSubmenu goToSubmenu resetVars drawMenu title subtitle separator break header footer info charOption stringOption keyboardOption'.split()
for cls in ('Menu', 'menu', 'Base', 'UI', 'Ui', 'Renderer', 'Drawing', 'Input', 'Controls', 'Natives', 'Features', 'Settings', 'Hooks', 'Utils', 'Util', 'Memory', 'Script', 'Globals', 'Player', 'Vehicle', 'Self', 'Network', 'Online', 'World', 'Weapon', 'Recovery', 'Spooner', 'Outfits', 'Menyoo'):
    for n in ref_methods + names[:]:
        check(mangle_fn(n, [], cls))
        for p in P1: check(mangle_fn(n, [p], cls))
        for ps in itertools.product(P2, repeat=2): check(mangle_fn(n, list(ps), cls))
    print('class', cls, len(hits), time.time() - t0, flush=True)
    json.dump(hits, open(hitsp, 'w'), indent=1)
json.dump(hits, open(hitsp, 'w'), indent=1)
print(len(hits), 'hits total')

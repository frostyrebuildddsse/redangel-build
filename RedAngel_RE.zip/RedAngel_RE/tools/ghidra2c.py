#!/usr/bin/env python3
"""Convert the Ghidra pseudo-C dump of the Expulsion PRX into a compilable C source tree.

usage: ghidra2c.py decompiled.c symbols.json resolved_names.json native_table.json elf outdir
"""
import re, sys, json, struct, os
from collections import OrderedDict

dec_path, sym_path, names_path, nat_path, elf_path, outdir = sys.argv[1:7]
src = open(dec_path).read()
extra = json.load(open(os.environ['GH2C_EXTRA'])) if os.environ.get('GH2C_EXTRA') else {}
if extra:
    src = re.sub(r'\b(' + '|'.join(re.escape(k) for k in extra) + r')\b', lambda m: extra[m.group(1)], src)
src = re.sub(r'(?<![%\w])(s|u)_([^\s"(),;&*\[\]=+]*?)_([0-9a-f]{8})\b', lambda m: m.group(1) + '_' + re.sub(r'[^A-Za-z0-9_]', '_', m.group(2)) + '_' + m.group(3), src)
# Ghidra RAM pseudo-vars: iRam00000000001846 20 -> typed deref of the global at that address
RAMT = {'i': 'int', 'u': 'uint', 'p': 'void *', 'c': 'char', 'b': 'uint8_t', 'f': 'float', 'l': 'long', 's': 'short', 'd': 'double', 'pc': 'char *', 'pi': 'int *', 'pu': 'uint *', 'pl': 'long *', 'pp': 'void **', 'pf': 'float *', 'ul': 'ulong', 'us': 'ushort', 'uc': 'uint8_t'}
def _ram(m):
    t = RAMT.get(m.group(1), 'uint64_t'); a = int(m.group(2), 16)
    return '(*(%s *)&DAT_%08x)' % (t, a)
src = re.sub(r'\b([a-z]{1,2})Ram([0-9a-f]{16})\b', _ram, src)
# far (eboot) addresses: DAT_/_DAT_ >= 0x400000 -> macro, collected below
far_syms = sorted(set(m.group(0) for m in re.finditer(r'\b_?DAT_([0-9a-f]{8})\b', src) if int(m.group(1), 16) >= 0x400000))
syms = json.load(open(sym_path))
rnames = json.load(open(names_path))
natives = {int(k, 16): v['name'] for k, v in json.load(open(nat_path)).items()}
elf = open(elf_path, 'rb').read()
TEXT_END = 0x11c000; DATA_END = 0x1e62f1
CODE_END = int(os.environ.get('GH2C_CODE_END', '0x7a8e0'), 16)

def v2o(va):
    if va < 0x11c000: return 0x4000 + va
    if 0x11c000 <= va < 0x17c000: return 0x120000 + (va - 0x11c000)
    if 0x17c000 <= va < 0x17f431: return 0x180000 + (va - 0x17c000)
    return None

# ---------------- functions ----------------
parts = re.split(r'\n// ---- ', src)
funcs = OrderedDict()
for p in parts[1:]:
    m = re.match(r'(\S+) @ (0x[0-9a-f]+) \(size (\d+)\)', p)
    if not m: continue
    name, addr = m.group(1), int(m.group(2), 16)
    body = p[m.end():]
    # strip my header comments and Ghidra's leading block comments
    i = body.find('\n\n')
    code = body
    # find signature line: last line before '\n{' that is not a comment
    bi = code.find('\n{')
    if bi < 0:
        funcs[addr] = dict(name=name, sig=None, body=None, raw=code); continue
    head = code[:bi]
    lines = [l for l in head.split('\n') if l.strip() and not l.strip().startswith('//') and not l.strip().startswith('/*') and not l.strip().startswith('*') and not l.strip().endswith('*/')]
    # signature may span multiple lines
    sig_lines = []
    for k in range(len(lines) - 1, -1, -1):
        l = lines[k]
        sig_lines.insert(0, l)
        if re.match(r'^\S', l):
            if re.match(r'^\s*' + re.escape(name) + r'\s*\(', ' '.join(x.strip() for x in sig_lines)) and k > 0 and re.match(r'^\S', lines[k-1]) and '(' not in lines[k-1]:
                sig_lines.insert(0, lines[k-1])
            break
    sig = ' '.join(x.strip() for x in sig_lines)
    sig = re.sub(r'\s+', ' ', sig)
    fbody = code[bi:]
    # cut trailing junk after final closing brace of the function
    depth = 0; end = None
    for k, ch in enumerate(fbody):
        if ch == '{': depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0: end = k + 1; break
    fbody = fbody[:end] if end else fbody
    funcs[addr] = dict(name=name, sig=sig, body=fbody, comment=head)
print(len(funcs), 'functions parsed')

export_by_addr = {e['addr']: e for e in syms['exports']}
nid_to_name = {k: v['name'] for k, v in rnames['nids'].items()}
nid_to_full = {k: v['full'] for k, v in rnames['nids'].items()}

# ---------------- collect global identifiers ----------------
ident_re = re.compile(r'\b((?:_?DAT|PTR|s|u|au|p[a-z]*|_?Ram)_?[A-Za-z0-9_]*?_([0-9a-f]{8})|DAT_([0-9a-f]{8})|_DAT_([0-9a-f]{8}))\b')
gl = {}   # name -> addr
all_bodies = '\n'.join((f['body'] or '') + '\n' + (f['sig'] or '') for f in funcs.values())
for m in re.finditer(r'\b([A-Za-z_][A-Za-z0-9_]*_([0-9a-f]{8}))\b', all_bodies):
    name = m.group(1); addr = int(m.group(2), 16)
    if name.startswith(('FUN_', 'switchD_', 'joined_', 'code_', 'caseD_', 'thunk_')): continue
    if name.startswith('LAB_') and not re.search(r'&' + name + r'\b|\b' + name + r'\s*\+', all_bodies): continue
    if addr >= DATA_END or addr < 0x1000: continue
    if name in far_syms: continue
    gl[name] = addr
for m in re.finditer(r'\b_DAT_([0-9a-f]{8})\b', all_bodies):
    if int(m.group(1), 16) < 0x400000: gl['_DAT_' + m.group(1)] = int(m.group(1), 16)
# named globals from resolved names / manual
named = {}
for nid, v in rnames['nids'].items():
    a = v.get('addr')
    if a is not None and a >= TEXT_END: named[v['name']] = a
for a, v in rnames.get('manual', {}).items():
    if int(a, 16) >= TEXT_END: named[v['name']] = int(a, 16)
for e in syms['exports']:
    if e['addr'] >= TEXT_END:
        nm = nid_to_name.get(e['name'], 'g_' + e['name'].replace('+', '_p').replace('-', '_m'))
        named[nm] = e['addr']
named = {extra.get(n, n): a for n, a in named.items()}
for n, a in named.items():
    if re.search(r'\b' + re.escape(n) + r'\b', all_bodies): gl[n] = a
# import pointers
for a, v in syms['data_imports'].items():
    if 'ptr_' + v['name'] in all_bodies: gl['ptr_' + v['name']] = int(a, 16)
for a, v in syms['got_imports'].items():
    if 'got_' + v['name'] in all_bodies: gl['got_' + v['name']] = int(a, 16)
print(len(gl), 'global identifiers referenced')

# sizes: export size if known, else gap to next symbol (any)
all_addrs = sorted(set(list(gl.values()) + [e['addr'] for e in syms['exports'] if e['addr'] >= TEXT_END] + [DATA_END, 0xb4000, 0xac000, 0xb0000]))
def gap(addr):
    for a in all_addrs:
        if a > addr: return min(a - addr, 0x4000)
    return 8
def is_string_name(n): return n.startswith('s_') or n.startswith('u_')
globals_out = []   # (addr, name, decl, is_array)
array_names = set()
for name, addr in sorted(gl.items(), key=lambda kv: kv[1]):
    exp = export_by_addr.get(addr)
    size = exp['size'] if exp and exp['size'] > 0 else None
    o = v2o(addr)
    if is_string_name(name) and o is not None:
        e = elf.index(b'\0', o); raw = elf[o:e]
        s = raw.decode('latin1')
        esc = s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
        esc = ''.join(c if 32 <= ord(c) < 127 else '\\x%02x' % ord(c) for c in esc)
        globals_out.append((addr, name, 'char %s[%d] = "%s";' % (name, len(raw) + 1, esc), True)); array_names.add(name); continue
    scalar_use = bool(re.search(r'(?<![&\w])' + re.escape(name) + r'\s*(=[^=]|==|!=|<|>|\+|-|&(?!&)|\||\*|/)', all_bodies) or re.search(r'[=(,]\s*' + re.escape(name) + r'\s*[;),]', all_bodies))
    deref_use = bool(re.search(r'\*' + re.escape(name) + r'\b', all_bodies) or re.search(r'\b' + re.escape(name) + r'\[', all_bodies) or re.search(r'\b' + re.escape(name) + r'\s*[!=]=\s*\([\w ]+\*\)', all_bodies))
    if size is None:
        size = gap(addr)
        if size > 8 and scalar_use: size = 4
    if size in (3, 5, 6, 7): size = 4 if size == 3 else 8
    if size <= 8 and deref_use and not name.startswith('PTR_'):
        val = struct.unpack_from('<Q', elf, o)[0] if o is not None else 0
        globals_out.append((addr, name, 'uint8_t *%s = (uint8_t *)0x%x;' % (name, val), False)); continue
    if name.startswith('PTR_') and size == 8:
        val = struct.unpack_from('<Q', elf, o)[0] if o is not None else 0
        tgt = [n for n, a in gl.items() if a == val]
        init = ('(char*)&%s' % tgt[0]) if tgt else '(char*)0x%x' % val
        globals_out.append((addr, name, 'char *%s = %s;' % (name, init), False)); continue
    if size in (1, 2, 4, 8) and not name.startswith('PTR_'):
        ty = {1: 'uint8_t', 2: 'uint16_t', 4: 'uint32_t', 8: 'uint64_t'}[size]
        val = int.from_bytes(elf[o:o+size], 'little') if o is not None else 0
        if o is None: val = 0
        globals_out.append((addr, name, '%s %s = 0x%x;' % (ty, name, val), False)); continue
    raw = elf[o:o+size] if o is not None else b'\0' * size
    if any(raw):
        # for pointer tables try to emit symbolic pointers
        if name.startswith('PTR_') and size % 8 == 0:
            items = []
            for k in range(0, size, 8):
                val = struct.unpack_from('<Q', raw, k)[0]
                tgt = [n for n, a in gl.items() if a == val]
                items.append(('(uint64_t)&%s' % tgt[0]) if tgt else '0x%xULL' % val)
            globals_out.append((addr, name, 'uint64_t %s[%d] = {%s};' % (name, size // 8, ', '.join(items)), True)); array_names.add(name); continue
        init = ', '.join('0x%02x' % b for b in raw)
        globals_out.append((addr, name, 'uint8_t %s[%d] = {%s};' % (name, size, init), True))
    else:
        globals_out.append((addr, name, 'uint8_t %s[%d];' % (name, size), True))
    array_names.add(name)
print(len(globals_out), 'globals emitted,', len(array_names), 'arrays')

# ---------------- body transforms ----------------
GH_TYPES_H = r'''// ghidra_types.h - type shims so Ghidra pseudo-C compiles
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
typedef uint8_t  undefined;  typedef uint8_t  undefined1; typedef uint16_t undefined2; typedef uint32_t undefined3;
typedef uint32_t undefined4; typedef uint64_t undefined5; typedef uint64_t undefined6; typedef uint64_t undefined7; typedef uint64_t undefined8;
typedef uint8_t  byte; typedef uint8_t uchar; typedef uint16_t ushort; typedef uint32_t uint; typedef uint64_t ulong;
typedef uint64_t ulonglong; typedef int64_t longlong; typedef int16_t sshort; typedef long double float10;
typedef void code; typedef void *pointer; typedef uint32_t dword; typedef uint16_t word; typedef uint64_t qword;
typedef long (*GH_FN)();
typedef union { uint8_t b[16]; uint32_t d[4]; uint64_t q[2]; } GH_VEC;
#define CONCAT11(a,b) ((uint16_t)(((uint16_t)(uint8_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT22(a,b) ((uint32_t)(((uint32_t)(uint16_t)(a)<<16)|(uint16_t)(b)))
#define CONCAT44(a,b) ((uint64_t)(((uint64_t)(uint32_t)(a)<<32)|(uint32_t)(b)))
#define CONCAT13(a,b) ((uint32_t)(((uint32_t)(uint8_t)(a)<<24)|((uint32_t)(b)&0xffffff)))
#define CONCAT31(a,b) ((uint32_t)(((uint32_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT17(a,b) ((uint64_t)(((uint64_t)(uint8_t)(a)<<56)|((uint64_t)(b)&0xffffffffffffffULL)))
#define CONCAT71(a,b) ((uint64_t)(((uint64_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT26(a,b) ((uint64_t)(((uint64_t)(uint16_t)(a)<<48)|((uint64_t)(b)&0xffffffffffffULL)))
#define CONCAT62(a,b) ((uint64_t)(((uint64_t)(a)<<16)|(uint16_t)(b)))
#define CONCAT35(a,b) ((uint64_t)(((uint64_t)(a)<<40)|((uint64_t)(b)&0xffffffffffULL)))
#define CONCAT53(a,b) ((uint64_t)(((uint64_t)(a)<<24)|((uint64_t)(b)&0xffffffULL)))
#define SUB81(x,n) ((uint8_t)((uint64_t)(x)>>((n)*8)))
#define SUB82(x,n) ((uint16_t)((uint64_t)(x)>>((n)*8)))
#define SUB84(x,n) ((uint32_t)((uint64_t)(x)>>((n)*8)))
#define SUB41(x,n) ((uint8_t)((uint32_t)(x)>>((n)*8)))
#define SUB42(x,n) ((uint16_t)((uint32_t)(x)>>((n)*8)))
#define SUB21(x,n) ((uint8_t)((uint16_t)(x)>>((n)*8)))
#define ZEXT18(x) ((uint64_t)(uint8_t)(x))
#define ZEXT14(x) ((uint32_t)(uint8_t)(x))
#define ZEXT12(x) ((uint16_t)(uint8_t)(x))
#define ZEXT24(x) ((uint32_t)(uint16_t)(x))
#define ZEXT28(x) ((uint64_t)(uint16_t)(x))
#define ZEXT48(x) ((uint64_t)(uint32_t)(x))
#define ZEXT416(x) ((uint64_t)(uint32_t)(x))
#define ZEXT816(x) ((uint64_t)(x))
#define SEXT14(x) ((int32_t)(int8_t)(x))
#define SEXT18(x) ((int64_t)(int8_t)(x))
#define SEXT24(x) ((int32_t)(int16_t)(x))
#define SEXT28(x) ((int64_t)(int16_t)(x))
#define SEXT48(x) ((int64_t)(int32_t)(x))
#define halt_baddata() __builtin_trap()
typedef int32_t int3; typedef int64_t int5; typedef int64_t int6; typedef int64_t int7; typedef uint32_t uint3; typedef uint64_t uint5; typedef uint64_t uint6; typedef uint64_t uint7;
#define SQRT(x) __builtin_sqrtf(x)
#define builtin_strncpy(d, s, n) __builtin_memcpy((d), (s), (n))
#define builtin_memcpy(d, s, n) __builtin_memcpy((d), (s), (n))
#define builtin_strcpy(d, s) __builtin_strcpy((d), (s))
static inline void *invalidInstructionException(void) { __builtin_trap(); return 0; }
#define GHF8(x,o)  (*(uint8_t  *)((char*)&(x)+(o)))
#define GHF16(x,o) (*(uint16_t *)((char*)&(x)+(o)))
#define GHF32(x,o) (*(uint32_t *)((char*)&(x)+(o)))
#define GHF64(x,o) (*(uint64_t *)((char*)&(x)+(o)))
'''

def find_matching(s, i):
    """s[i]=='(' -> index of matching ')' (string/char literal aware)"""
    depth = 0; q = None; esc = False
    for k in range(i, len(s)):
        ch = s[k]
        if q:
            if esc: esc = False
            elif ch == '\\': esc = True
            elif ch == q: q = None
            continue
        if ch in '"\'': q = ch; continue
        if ch == '(': depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0: return k
    return -1

def fix_code_calls(b):
    out = []; i = 0
    while True:
        j = b.find('(**(code **)', i)
        if j < 0: out.append(b[i:]); break
        out.append(b[i:j])
        close = find_matching(b, j)
        expr = b[j + len('(**(code **)'):close]
        out.append('((GH_FN)*(void **)(%s))' % expr)
        i = close + 1
    b = ''.join(out)
    return fix_code_calls1(b)
def fix_code_calls1(b):
    # (*(code *)EXPR)(args)  ->  ((GH_FN)(EXPR))(args)
    out = []; i = 0
    while True:
        j = b.find('(*(code *)', i)
        if j < 0: out.append(b[i:]); break
        out.append(b[i:j])
        close = find_matching(b, j)       # matches the '(' at j
        expr = b[j + len('(*(code *)'):close]
        out.append('((GH_FN)(%s))' % expr)
        i = close + 1
    return ''.join(out)

inv_re = re.compile(r'\b(invoke_(?:Vector3|[A-Za-z]+?)(?:_([A-Za-z0-9]+))?)\(')
TYMAP = {'i': 'int', 'f': 'float', 'j': 'unsigned int', 'b': 'bool', 'PKc': 'const char*', 'Pc': 'char*', 'Pv': 'void*',
         'Pi': 'int*', 'Pf': 'float*', 'y': 'uint64_t', 'Vector3': 'Vector3', 'v': 'void'}
def split_args(s):
    args = []; depth = 0; cur = ''; q = None; esc = False
    for ch in s:
        if q:
            cur += ch
            if esc: esc = False
            elif ch == '\\': esc = True
            elif ch == q: q = None
            continue
        if ch in '"\'': q = ch; cur += ch; continue
        if ch == ',' and depth == 0: args.append(cur.strip()); cur = ''; continue
        if ch in '([': depth += 1
        if ch in ')]': depth -= 1
        cur += ch
    if cur.strip(): args.append(cur.strip())
    return args
def split_mangled(s):
    out = []; i = 0
    while i < len(s):
        if s[i] in 'RPK':
            j = i
            while j < len(s) and s[j] in 'RPK': j += 1
            out.append(s[i:j+1]); i = j + 1
        else:
            out.append(s[i]); i += 1
    return out
def fix_invokes(b):
    out = []; i = 0
    while True:
        m = inv_re.search(b, i)
        if not m: out.append(b[i:]); break
        out.append(b[i:m.start()])
        name = m.group(1)
        open_i = m.end() - 1
        close = find_matching(b, open_i)
        args = split_args(b[open_i + 1:close])
        parts = name.split('_')
        r = parts[1]
        argm = split_mangled(parts[2]) if len(parts) > 2 else []
        rtype = TYMAP.get(r, r)
        if r == 'Vector3':
            outp = args[0]; hash_ = args[1]; rest = args[2:]
        else:
            outp = None; hash_ = args[0]; rest = args[1:]
        try: hv = int(hash_, 0)
        except Exception: hv = None
        if hv is not None and hv in natives: hash_ = 'N_' + natives[hv]
        new_args = []
        for a, mt in zip(rest, argm):
            if mt.startswith('R') and a.startswith('&'): a = a[1:]
            elif mt.startswith('R'): a = '*(%s)' % a
            new_args.append(a)
        call = 'invoke<%s>(%s)' % (rtype, ', '.join([hash_] + new_args))
        if outp is not None:
            call = '(*(Vector3*)(%s) = %s, (Vector3*)(%s))' % (outp, call, outp)
        out.append(call)
        i = close + 1
    return ''.join(out)

CPP = os.environ.get('GH2C_CPP') == '1'
def fix_invokes_c(b):
    def rep(m):
        hv = int(m.group(3), 16)
        return m.group(1) + '(' + (m.group(2) or '') + ('N_' + natives[hv] if hv in natives else m.group(3))
    b = re.sub(r'\b(invoke_[A-Za-z0-9_]+|callHash)\((&?\w+,\s*)?(0x[0-9a-fA-F]+)', rep, b)
    return re.sub(r'\b0x([0-9a-fA-F]{6,7})\b', lambda m: ('N_' + natives[int(m.group(1), 16)]) if int(m.group(1), 16) in natives else m.group(0), b)
def fix_body(b, fname):
    b = fix_code_calls(b)
    vecs = re.findall(r'\bundefined1 (auVar\d+) \[(?:9|1[0-6])\];', b)
    b = re.sub(r'\bundefined1 (auVar\d+) \[(9|1[0-6])\];', r'GH_VEC \1;', b)
    b = re.sub(r'\bsyscall\(\)', 'syscall(0)', b)
    b = re.sub(r'\b(auVar\d+) = (\w+\()', r'\1.q[0] = \2', b)
    b = re.sub(r'\breturn (auVar\d+);', r'return \1.q[0];', b)
    b = re.sub(r'\b(\w+)\._(\d+)_(\d+)_ = 0;', r'memset((char *)&\1 + \2, 0, \3);', b)
    b = re.sub(r'\b(auVar\d+) << 0x40\b', r'\1', b)
    for v in vecs:
        b = re.sub(r'([(,]\s*)' + re.escape(v) + r'(\s*[,)])', r'\1&' + v + r'\2', b)
    b = re.sub(r'\b(auVar\d+)\[', r'\1.b[', b)
    if CPP:
        b = fix_invokes(b)
        b = re.sub(r'\bpushArg_([A-Za-z]+)\(', lambda m: 'pushArg<%s>(' % TYMAP.get(m.group(1), m.group(1)), b)
        b = re.sub(r'\bgetReturn_([A-Za-z0-9]+)\(', lambda m: 'getReturn<%s>(' % TYMAP.get(m.group(1), m.group(1)), b)
    else:
        b = fix_invokes_c(b)
    b = re.sub(r'\bcallHash\((0x[0-9a-fA-F]+)\)', lambda m: 'callHash(%s)' % ('N_' + natives[int(m.group(1), 16)] if int(m.group(1), 16) in natives else m.group(1)), b)
    b = re.sub(r'switchD_[0-9a-f]+::caseD_([0-9a-f]+):', r'case 0x\1:', b)
    b = re.sub(r'switchD_[0-9a-f]+::default:', 'default:', b)
    b = re.sub(r'\b(\w+)\._(\d+)_(\d+)_ = (\w+)\._\2_\3_;', r'memcpy((char *)&\1 + \2, (char *)&\4 + \2, \3);', b)
    b = re.sub(r'\b(\w+)\._(\d+)_(\d+)_', lambda m: 'GHF%d(%s,%s)' % (int(m.group(3)) * 8, m.group(1), m.group(2)) if m.group(3) in ('1','2','4','8') else m.group(0), b)
    b = re.sub(r'\(\*(\w+)\)\(', r'((GH_FN)(\1))(', b)
    # &ARRAYNAME -> ARRAYNAME (array decays to byte pointer, keeps Ghidra's byte arithmetic)
    b = re.sub(r'&(' + '|'.join(re.escape(n) for n in sorted(array_names, key=len, reverse=True)) + r')\b', r'\1', b) if array_names else b
    # stack0x... pseudo vars
    stk = sorted(set(re.findall(r'\bstack0x[0-9a-f]+\b', b)))
    if stk:
        decl = ''.join('  uint8_t %s[4096];\n' % s for s in stk)
        b = b.replace('{\n', '{\n' + decl, 1)
    b = b.replace('&stack0x', 'stack0x')
    if array_names:
        b = re.sub(r'^(\s*)(' + '|'.join(re.escape(n) for n in array_names) + r')\s*=\s*([^;=][^;]*);', r'\1memcpy(\2, &(\3), sizeof(\2));', b, flags=re.M)
    b = re.sub(r'FUN_000478c0\((\w+), 0x80\)', r'FUN_000478c0(\1, (uint64_t)FUN_00000080)', b)
    b = fix_arity(b)
    b = re.sub(r'\breturn (auVar\d+);', r'return \1.q[0];', b)
    for v in re.findall(r'\n\s+undefined8 (\w+);', b):
        m = re.search(r'\b' + v + r' = \((\w+) \*\)', b)
        if m and re.search(r'\*' + v + r'\b', b):
            b = re.sub(r'(\n\s+)undefined8 ' + v + ';', r'\1' + m.group(1) + ' *' + v + ';', b, count=1)
    if fname in void_to_ret:
        b = re.sub(r'\breturn;', 'return 0;', b)
    return b

def fix_sig(sig, name):
    sig = sig.replace('__thiscall ', '').replace('__cdecl ', '')
    sig = re.sub(r'^(\w+)\s+\[\d+\]\s*', 'undefined8 ', sig)
    sig = re.sub(r'\bEVP_PKEY_CTX\b', 'void', sig)
    sig = re.sub(r'(\w+) \[(\d+)\]\s*(\w+)', r'\1 *\3', sig)   # array params -> pointers
    if name in void_to_ret:
        sig = re.sub(r'^void\b', 'undefined8', sig)
    return sig

# ---- analysis: void functions whose result is used; arity of each function
fn_by_name = {f['name']: f for f in funcs.values()}
def param_count(sig):
    m = re.search(r'\((.*)\)\s*$', sig)
    if not m: return None
    inner = m.group(1).strip()
    if inner in ('', 'void'): return 0
    if '...' in inner: return None
    return len(split_args(inner))
arity = {}
for f in funcs.values():
    if f['sig']:
        arity[f['name']] = param_count(f['sig'])
void_to_ret = set()
for f in funcs.values():
    if f['sig'] and re.match(r'^void\s+\**\s*\w+\s*\(', f['sig']) and not f['sig'].startswith('void *'):
        nm = f['name']
        for m in re.finditer(r'(?<![\w.])' + re.escape(nm) + r'\(', all_bodies):
            k = m.start() - 1
            while k >= 0 and all_bodies[k] in ' \t': k -= 1
            if k >= 0 and all_bodies[k] not in ';{}\n':
                void_to_ret.add(nm); break
print(len(void_to_ret), 'void functions used as value')
PLT_NAMES = {v['name'] for v in syms['plt'].values()} | {'memset','memcpy','strlen','strcpy','strncpy','strcmp','strncmp','strstr','sprintf','snprintf','printf','fprintf','sscanf','fscanf','fopen','fclose','malloc','free','remove','strtol','strtoll','strtod','vsprintf','cosf','sinf','memcmp','__error'}
def fix_arity(b):
    out = []; i = 0
    pat = re.compile(r'(?<![\w.])(\w+)\(')
    while True:
        m = pat.search(b, i)
        if not m: out.append(b[i:]); break
        nm = m.group(1)
        n = arity.get(nm)
        if n is None or nm in PLT_NAMES or nm not in fn_by_name:
            out.append(b[i:m.end()]); i = m.end(); continue
        close = find_matching(b, m.end() - 1)
        if close < 0: out.append(b[i:m.end()]); i = m.end(); continue
        args = split_args(b[m.end():close])
        if len(args) < n: args = args + ['0'] * (n - len(args))
        elif len(args) > n: args = args[:n]
        out.append(b[i:m.end()] + ', '.join(args) + ')'); i = close + 1
    return ''.join(out)

# ---------------- emit ----------------
os.makedirs(os.path.join(outdir, 'source'), exist_ok=True)
with open(os.path.join(outdir, 'source', 'ghidra_types.h'), 'w') as f: f.write(GH_TYPES_H)
with open(os.path.join(outdir, 'source', 'natives157.h'), 'w') as f:
    f.write('// natives157.h - GTA V PS4 1.57 eboot native handler offsets (eboot_base + offset), from the binary\'s own table\n#pragma once\n')
    for off, nm in sorted(natives.items(), key=lambda kv: kv[1]):
        f.write('#define N_%-48s 0x%xULL%s\n' % (nm, off, '   /* interpolated name, verify */' if nm.endswith('__guess') else ''))
with open(os.path.join(outdir, 'source', 'globals.h'), 'w') as f:
    f.write('// globals.h - all global data referenced by the decompiled code (byte-exact from the PRX)\n#pragma once\n#include "ghidra_types.h"\n#ifdef __cplusplus\nextern "C" {\n#endif\n')
    f.write('// absolute addresses inside the GTA V 1.57 eboot (loaded at 0x400000)\n')
    for fs in far_syms:
        a = int(fs.split('DAT_')[1], 16)
        wide = re.search(r'\b' + fs + r'\s*=\s*(0x[0-9a-f]{3,}|[0-9]{4,})', all_bodies)
        f.write('#define %s (*(volatile %s *)0x%xULL)\n' % (fs, 'uint64_t' if fs.startswith('_DAT') or wide else 'uint8_t', a))
    for addr, name, decl, isarr in globals_out:
        d = decl.split('=')[0].rstrip().rstrip(';')
        f.write('extern %s;  // 0x%x\n' % (d, addr))
    f.write('#ifdef __cplusplus\n}\n#endif\n')
with open(os.path.join(outdir, 'source', 'globals.c'), 'w') as f:
    f.write('// globals.c - definitions with original initial values\n#include "globals.h"\n')
    for addr, name, decl, isarr in globals_out:
        f.write('%s  // 0x%x\n' % (decl, addr))
# prototypes
protos = []
for addr, fn in funcs.items():
    if fn['sig']: protos.append((addr, fix_sig(fn['sig'], fn['name']) + ';'))
with open(os.path.join(outdir, 'source', 'functions.h'), 'w') as f:
    f.write('// functions.h - prototypes of all decompiled functions\n#pragma once\n#include "ghidra_types.h"\n#include "invoker.h"\n#ifdef __cplusplus\nextern "C" {\n#endif\n')
    for addr, p in protos:
        if re.search(r'\b(_init|_fini)\s*\(', p): continue
        if addr >= CODE_END: continue
        if re.search(r'\b(' + '|'.join(re.escape(x) for x in PLT_NAMES) + r')\s*\(', p): continue
        f.write('%s  // 0x%x\n' % (p, addr))
    f.write('#ifdef __cplusplus\n}\n#endif\n')
# bodies, split by file heuristics (address ranges of the 3 source files + SDK)
SKIP = re.compile(r'^(_init|_fini|' + '|'.join(re.escape(v['name']) for v in syms['plt'].values()) + r')$')
CODE_END = int(os.environ.get('GH2C_CODE_END', '0x7a8e0'), 16)
ranges = [('main.c', 0x0, 0x1000), ('menu.c', 0x1000, 0x79050), ('sdk.c', 0x79050, CODE_END)]
files = {r[0]: [] for r in ranges}
for addr, fn in funcs.items():
    if not fn['sig'] or SKIP.match(fn['name']) or addr >= CODE_END: continue
    for fname, lo, hi in ranges:
        if lo <= addr < hi: break
    hdr = '// %s @ 0x%x' % (fn['name'], addr)
    exp = export_by_addr.get(addr)
    if exp:
        hdr += '  (export NID %s%s)' % (exp['name'], (' = ' + nid_to_full[exp['name']]) if exp['name'] in nid_to_full else '')
    text = hdr + '\n' + fix_sig(fn['sig'], fn['name']) + '\n' + fix_body(fn['body'], fn['name']) + '\n'
    hw = os.environ.get('GH2C_HANDWRITTEN_DIR')
    if hw and os.path.exists(os.path.join(hw, fn['name'] + '_manual.c')):
        text = '#if 0  // auto-converted original, replaced by hand-written version below\n' + text + '#endif\n' + open(os.path.join(hw, fn['name'] + '_manual.c')).read()
    files[fname].append(text)
for fname, bodies in files.items():
    with open(os.path.join(outdir, 'source', fname), 'w') as f:
        f.write('// %s - auto-converted from Ghidra decompilation of LushModz-Expulsion-1.57.prx\n' % fname)
        f.write('#include "ghidra_types.h"\n#include "ps4_imports.h"\n#include "globals.h"\n#include "natives157.h"\n#include "invoker.h"\n#include "functions.h"\n\n')
        f.write('\n'.join(bodies))
    print(fname, len(bodies), 'functions')

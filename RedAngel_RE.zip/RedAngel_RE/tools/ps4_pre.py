# Ghidra Jython pre-script: add computed-jump references for clang -O0 switch tables, raise decompiler timeouts.
import json
from ghidra.program.model.symbol import RefType, SourceType
args = getScriptArgs()
jt = json.load(open(args[0]))
opts = getCurrentAnalysisOptionsAndValues(currentProgram)
for k in sorted(opts.keySet()):
    if 'Timeout' in k or 'Switch' in k:
        print('option: %s = %s' % (k, opts.get(k)))
for k in list(opts.keySet()):
    if 'Decompiler Timeout' in k:
        setAnalysisOption(currentProgram, k, '900')
        print('set %s = 900' % k)
rm = currentProgram.getReferenceManager()
n = 0
for a, v in jt.items():
    src = toAddr(int(a, 16))
    for t in v['targets']:
        rm.addMemoryReference(src, toAddr(t), RefType.COMPUTED_JUMP, SourceType.USER_DEFINED, 0)
        n += 1
print('added %d computed-jump refs for %d tables' % (n, len(jt)))

#!/usr/bin/env python3
"""Build rename map for the Seren decompile: invoker pieces, invoke wrappers, per-native functions, cracked NIDs.
usage: seren_names.py decompiled.c wrappers.json natives_resolved.json nid_hits.json symbols.json out_extra.json out_nattable.json out_resolved.json"""
import json, re, sys, subprocess
dec, wp, natp, hitp, symp, out_extra, out_nat, out_res = sys.argv[1:9]
src = open(dec).read()
W = json.load(open(wp)); NAT = json.load(open(natp)); hits = json.load(open(hitp)); syms = json.load(open(symp))
addr_of = {e['name']: e['addr'] for e in syms['exports']}
extra = {}
TY = {'i': 'i', 'f': 'f', 'b': 'b', 'PKc': 's', 'Pi': 'pi', 'Pf': 'pf', 'P7Vector3': 'pv3', 'Pv': 'p', '7Vector3': 'v3', 'v': 'v', 'j': 'u'}
base = {'FUN_00000340': 'resetArgs', 'FUN_00000260': 'setVectors', 'FUN_00000310': 'callHash',
        'FUN_00000a40': 'pushArg_int', 'FUN_0000a2a0': 'pushArg_cstr', 'FUN_0000a440': 'pushArg_intptr', 'FUN_0000a640': 'pushArg_float',
        'FUN_0000b0a0': 'pushArg_vec3ptr', 'FUN_0000b690': 'pushArg_floatptr', 'FUN_0000daa0': 'pushArg_bool',
        'FUN_000009e0': 'getReturn_int', 'FUN_0000a300': 'getReturn_ptr', 'FUN_0000a8e0': 'getReturn_vec3', 'FUN_0000ae90': 'getReturn_float', 'FUN_00014400': 'getReturn_cstr',
        'g_rUyuGkqlGtk': 'nativeArg', 'FUN_00000080': 'notify_icon', 'FUN_000003d0': 'plugin_load', 'FUN_00000740': 'plugin_unload',
        'FUN_00000570': 'install_cam_hook', 'FUN_00000660': 'menu_arm_thread', 'g_3V50SBwmhFg': 'g_pluginName', 'g_ONwf1cHqObc': 'g_pluginVersion', 'g_W_pBT3_mRLYmY': 'g_pluginAuthor',
        'g_oYo1zQ8508U': 'g_flipRateHook'}
extra.update(base)
used = {}
for wn, w in W.items():
    nm = 'invoke_%s_%s' % (TY.get(w['ret'], w['ret']), ''.join(TY.get(a, a) for a in w['args']) or 'void')
    if nm in used: used[nm] += 1; nm += '_%d' % used[nm]
    else: used[nm] = 1
    extra[wn] = nm
# native functions: small function whose body is exactly one wrapper call with a constant offset
parts = re.split(r'\n// ---- ', src)
nat_used = {}
nat_table = {}
for k, v in NAT.items():
    if not v.get('name'): continue
    nm = v['name'] + ('' if v['conf'] == 'exact' else '__guess')
    if nm in nat_used: nat_used[nm] += 1; nm = '%s_%d' % (nm, nat_used[nm])
    else: nat_used[nm] = 1
    nat_table[k] = dict(name=nm, conf=v['conf'], proto=v.get('proto'), hash=v.get('hash'), alt=v.get('alt'))
fn_named = {}
for p in parts[1:]:
    m = re.match(r'(\S+) @ (0x[0-9a-f]+) \(size (\d+)\)', p)
    if not m or not m.group(1).startswith('FUN_') or int(m.group(3)) > 200: continue
    body = p[p.find('\n{'):]
    calls = re.findall(r'\b(FUN_[0-9a-f]+)\((0x[0-9a-f]{6,7})[,)]', body)
    allcalls = re.findall(r'\b(FUN_[0-9a-f]+)\(', body)
    if len(calls) == 1 and calls[0][0] in W and len(allcalls) <= 2:
        off = calls[0][1]
        if off in nat_table:
            nm = nat_table[off]['name']
            if nm in fn_named.values(): nm = nm + '_' + m.group(1)[-5:]
            fn_named[m.group(1)] = nm
extra.update(fn_named)
# cracked NIDs: functions + globals
res = {'nids': {}, 'manual': {}}
for nid, mangled in hits.items():
    if mangled.startswith('_Z'):
        full = subprocess.check_output(['c++filt', mangled]).decode().strip()
        mm = re.match(r'_Z(\d+)', mangled)
        short = mangled[len(mm.group(0)):len(mm.group(0)) + int(mm.group(1))] if mm else mangled
        if mangled.startswith('_ZN'): short = full.split('(')[0].replace('::', '_')
    else:
        full = short = mangled
    if mangled.startswith('_Z7pushArgI') or mangled.startswith('_Z9getReturnI') or mangled in ('_Z9resetArgsv', '_Z10setVectorsv', '_Z8callHashm'):
        continue   # already named above
    res['nids'][nid] = dict(name=short, full=full, sig=None, addr=addr_of.get(nid))
    a = addr_of.get(nid)
    if a is not None:
        fn = 'FUN_%08x' % a
        if fn in extra: del extra[fn]
        extra[fn] = short
        extra['g_' + nid.replace('+', '_p').replace('-', '_m')] = short
        extra['_g_' + nid.replace('+', '_p').replace('-', '_m')] = short
json.dump(extra, open(out_extra, 'w'), indent=1)
json.dump(nat_table, open(out_nat, 'w'), indent=1)
json.dump(res, open(out_res, 'w'), indent=1)
print(len(extra), 'renames;', len(fn_named), 'native functions;', len(W), 'wrappers;', len(res['nids']), 'cracked names')

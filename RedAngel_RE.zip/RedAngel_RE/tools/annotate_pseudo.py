#!/usr/bin/env python3
"""Apply rename map + native-name comments to the raw Ghidra pseudo-C.
usage: annotate_pseudo.py raw.c extra_names.json nat_table.json out.c"""
import json, re, sys
raw, ex, nt, outp = sys.argv[1:5]
src = open(raw).read()
extra = json.load(open(ex)); nat = {int(k, 16): v['name'] for k, v in json.load(open(nt)).items()}
pat = re.compile(r'\b(' + '|'.join(re.escape(k) for k in sorted(extra, key=len, reverse=True)) + r')\b')
src = pat.sub(lambda m: extra[m.group(1)], src)
src = re.sub(r'\b0x([0-9a-f]{6,7})\b', lambda m: m.group(0) + ('/*' + nat[int(m.group(1), 16)] + '*/' if int(m.group(1), 16) in nat else ''), src)
open(outp, 'w').write(src)
print('ok')

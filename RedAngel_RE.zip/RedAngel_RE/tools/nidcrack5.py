#!/usr/bin/env python3
"""Pattern crack for Serendipity naming: menu_<a>_<b>[_<c>](params), <a>_<b>(params), g_<camel>.
usage: nidcrack5.py symbols.json hits.json elf"""
import json, hashlib, base64, sys, re, subprocess, time
from multiprocessing import Pool
from collections import Counter
SUF = bytes.fromhex('518D64A635DED8C1E6B039B1C3E55230')
def nid(n): return base64.b64encode(hashlib.sha1(n.encode() + SUF).digest()[:8][::-1], altchars=b'+-').decode()[:11]
symp, hitsp, elfp = sys.argv[1:4]
j = json.load(open(symp))
T = {e['name'] for e in j['exports'] if len(e['name']) == 11}
st = subprocess.run(['strings', '-n', '3', elfp], capture_output=True, text=True).stdout.split('\n')
wc = Counter()
for s in st:
    s = re.sub(r'~[a-zA-Z_0-9]+~', ' ', s)
    for w in re.findall(r'[A-Za-z][a-z]+|[A-Z]{2,}(?![a-z])', s):
        if 2 <= len(w) <= 12: wc[w.lower()] += 1
hits = json.load(open(hitsp))
seen = set()
for v in hits.values():
    for w in re.split(r'[_\d]|(?<=[a-z])(?=[A-Z])', re.sub(r'^_Z\d+', '', v)):
        if w and w.isalpha(): seen.add(w.lower())
W = sorted({w for w, c in wc.items() if c >= 2} | seen | set('tick options count option load save draw init update loop toggle press open close spawn give apply reset clear set get is add remove unlock run handle on off submenu list name names index current selected max min value value value hash model draw text title header footer rainbow theme pastel speed mode slot level rank cash money rp stats stat award awards protections protection players player peds ped self world vehicle vehicles weapons weapon tattoos tattoo outfits outfit wardrobe settings tunables recovery teleport teleports spooner menyoo objects object misc fun session online network heist heists casino cayo agency autoshop salvage doomsday cluckin ceo crate cargo nightclub bunker arcade input buttons button controller sound sounds notify notification print keyboard scroll bool int float int_option float_option bool_option submenu_option'.split()))
print(len(W), 'words', flush=True)
P = ['v', 'i', 'f', 'b', 'j', 'PKc', 'Pc', 'Pv', 'm', 'ii', 'ib', 'if', 'bi', 'PKci', 'PKcb', 'PKcf', 'iPKc', 'PKcPb', 'PKcPi', 'PKcPf', 'PKcPKc', 'PKcS_', 'iii', 'ff', 'fff', 'ffff', 'iiii']
def work(a):
    out = []
    for b in W:
        for base in ('menu_%s_%s' % (a, b), '%s_%s' % (a, b)):
            for p in P:
                s = '_Z%d%s%s' % (len(base), base, p)
                if nid(s) in T: out.append(s)
            if nid(base) in T: out.append(base)
        A = a[0].upper() + a[1:]; B = b[0].upper() + b[1:]
        for g in ('g_' + a + B, 'g_' + a + '_' + b, 's_' + a + B, 'g' + A + B):
            if nid(g) in T: out.append(g)
        for c in ('Count', 'Options', 'Index', 'Enabled', 'Value', 'Mode', 'Speed', 'Slot', 'Hash', 'Name', 'Names', 'List', 'Max', 'Min', 'Timer', 'Delay', 'Color', 'Alpha', 'Scale', 'X', 'Y', 'Z', 'Pos', 'Level', 'Active', 'Toggle', 'Type', 'Id', 'Ped', 'Veh', 'Handle', 'Model', 'Amount', 'Prep', 'Contract', 'Act', 'Wins', 'Losses', 'Day', 'Month', 'Year', 'Range', 'Bone', 'Guard', 'Logo', 'Boost', 'Intensity'):
            g = 'g_' + a + B + c
            if nid(g) in T: out.append(g)
    # menu_<a>_<b>_<c> only for c in short verb list
    for b in W:
        for c in ('tick', 'options', 'count', 'option', 'load', 'save', 'draw', 'init', 'update', 'toggle', 'apply', 'reset', 'press', 'handler', 'callback', 'keyboard', 'set', 'get', 'loop', 'menu', 'submenu'):
            base = 'menu_%s_%s_%s' % (a, b, c)
            for p in ('v', 'i', 'PKc', 'b', 'f', 'Pc'):
                s = '_Z%d%s%s' % (len(base), base, p)
                if nid(s) in T: out.append(s)
    return out
if __name__ == '__main__':
    t0 = time.time()
    with Pool(2) as pool:
        for k, res in enumerate(pool.imap_unordered(work, W, chunksize=8)):
            for s in res:
                n = nid(s)
                if n not in hits:
                    hits[n] = s; print('%s -> %s' % (n, s), flush=True)
            if k % 100 == 0:
                print('progress', k, len(W), len(hits), int(time.time() - t0), flush=True); json.dump(hits, open(hitsp, 'w'), indent=1)
    json.dump(hits, open(hitsp, 'w'), indent=1)
    print(len(hits), 'hits total', int(time.time() - t0))

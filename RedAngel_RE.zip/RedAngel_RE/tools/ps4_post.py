# Ghidra Jython post-script: apply PS4 symbol info, decompile everything, export C.
# args: symbols.json out_dir
import json, os, sys, time
from ghidra.program.model.symbol import SourceType
from ghidra.app.util.cparser.C import CParserUtils
from ghidra.app.cmd.function import ApplyFunctionSignatureCmd
from ghidra.app.decompiler import DecompInterface, DecompileOptions
from ghidra.program.model.listing import CodeUnit
from ghidra.program.model.data import PointerDataType, Undefined8DataType

args = getScriptArgs()
symjson, outdir = args[0], args[1]
info = json.load(open(symjson))
prog = currentProgram
fm = prog.getFunctionManager()
listing = prog.getListing()
symtab = prog.getSymbolTable()

def A(x): return toAddr(x)

SIGS = {
 '__error': 'int * __error(void)',
 'cosf': 'float cosf(float x)', 'sinf': 'float sinf(float x)',
 'fclose': 'int fclose(void *f)', 'fopen': 'void * fopen(char *path, char *mode)',
 'fprintf': 'int fprintf(void *f, char *fmt, ...)', 'free': 'void free(void *p)',
 'fscanf': 'int fscanf(void *f, char *fmt, ...)', 'malloc': 'void * malloc(ulong n)',
 'memcmp': 'int memcmp(void *a, void *b, ulong n)', 'memcpy': 'void * memcpy(void *dst, void *src, ulong n)',
 'memset': 'void * memset(void *p, int c, ulong n)', 'printf': 'int printf(char *fmt, ...)',
 'remove': 'int remove(char *path)',
 'sceKernelGetModuleInfo': 'int sceKernelGetModuleInfo(int handle, void *info)',
 'sceKernelGetModuleList': 'int sceKernelGetModuleList(int *handles, ulong n, ulong *out)',
 'sceKernelLoadStartModule': 'int sceKernelLoadStartModule(char *path, ulong argc, void *argv, uint flags, void *opt, int *res)',
 'sceKernelMmap': 'int sceKernelMmap(void *addr, ulong len, int prot, int flags, int fd, longlong off, void **res)',
 'sceKernelMprotect': 'int sceKernelMprotect(void *addr, ulong len, int prot)',
 'sceKernelMunmap': 'int sceKernelMunmap(void *addr, ulong len)',
 'sceKernelSendNotificationRequest': 'int sceKernelSendNotificationRequest(int dev, void *req, ulong size, int blocking)',
 'sceKernelUsleep': 'int sceKernelUsleep(uint us)',
 'scePthreadCreate': 'int scePthreadCreate(void **thread, void *attr, void *entry, void *arg, char *name)',
 'scePthreadJoin': 'int scePthreadJoin(void *thread, void **ret)',
 'snprintf': 'int snprintf(char *buf, ulong n, char *fmt, ...)', 'sprintf': 'int sprintf(char *buf, char *fmt, ...)',
 'sscanf': 'int sscanf(char *s, char *fmt, ...)', 'strcmp': 'int strcmp(char *a, char *b)',
 'strcpy': 'char * strcpy(char *dst, char *src)', 'strlen': 'ulong strlen(char *s)',
 'strncmp': 'int strncmp(char *a, char *b, ulong n)', 'strncpy': 'char * strncpy(char *dst, char *src, ulong n)',
 'strstr': 'char * strstr(char *h, char *n)', 'strtod': 'double strtod(char *s, char **end)',
 'strtol': 'long strtol(char *s, char **end, int base)', 'strtoll': 'longlong strtoll(char *s, char **end, int base)',
 'vsprintf': 'int vsprintf(char *buf, char *fmt, void *ap)',
}

def apply_sig(func, sigtext):
    try:
        sig = CParserUtils.parseSignature(None, prog, sigtext)
        if sig is None:
            print('sig parse failed: ' + sigtext); return
        cmd = ApplyFunctionSignatureCmd(func.getEntryPoint(), sig, SourceType.USER_DEFINED)
        cmd.applyTo(prog)
    except Exception as e:
        print('sig error %s: %s' % (sigtext, e))

# ---- 1. PLT stubs -> import names
n = 0
for a, v in info['plt'].items():
    addr = A(int(a, 16))
    f = fm.getFunctionAt(addr)
    if f is None:
        f = createFunction(addr, v['name'])
    if f is None:
        print('could not create function at ' + a); continue
    f.setName(v['name'], SourceType.IMPORTED)
    f.setComment('PS4 import: %s (%s / %s) NID %s' % (v['name'], v['lib'], v['mod'], v['nid']))
    if v['name'] in SIGS:
        apply_sig(f, SIGS[v['name']])
    n += 1
print('named %d PLT stubs' % n)

# GOT slots of imports
for a, v in info['got_imports'].items():
    addr = A(int(a, 16))
    createLabel(addr, 'got_' + v['name'], True, SourceType.IMPORTED)
for a, v in info['data_imports'].items():
    addr = A(int(a, 16))
    createLabel(addr, 'ptr_' + v['name'], True, SourceType.IMPORTED)
    listing.setComment(addr, CodeUnit.EOL_COMMENT, 'data import %s from %s' % (v['name'], v['lib']))

# ---- 2. exports: functions get NID comment, data gets label
resolved = {}; resolved_full = {}; resolved_sig = {}; manual = {}
if len(args) > 2:
    rn = json.load(open(args[2]))
    for nid_, v in rn['nids'].items():
        resolved[nid_] = v['name']; resolved_full[nid_] = v['full']; resolved_sig[nid_] = v.get('sig')
    manual = rn.get('manual', {})
    print('resolved %d NIDs from dictionary, %d manual names' % (len(resolved), len(manual)))
text_end = 0x11c000
for e in info['exports']:
    addr = A(e['addr']); name = e['name']; size = e['size']
    real = resolved.get(name)
    if e['addr'] < text_end and e['type'] in (2, 0) and size > 0:
        f = fm.getFunctionAt(addr)
        if f is None:
            f = createFunction(addr, None)
        if f is None:
            f = fm.getFunctionContaining(addr)
            if f is not None and f.getEntryPoint() != addr:
                print('export %s at %s inside function %s' % (name, addr, f.getName()))
            continue
        if real:
            try: f.setName(real, SourceType.IMPORTED)
            except Exception as ex: print('rename fail %s: %s' % (real, ex))
            if resolved_sig.get(name):
                apply_sig(f, resolved_sig[name])
        c = f.getComment() or ''
        f.setComment((c + '\n' if c else '') + 'export NID %s size %d%s' % (name, size, (' = ' + resolved_full[name]) if real else ''))
    elif e['addr'] >= text_end:
        lbl = real if real else ('g_' + name.replace('+', '_p').replace('-', '_m'))
        try:
            createLabel(addr, lbl, True, SourceType.IMPORTED)
        except Exception as ex:
            print('label fail %s: %s' % (lbl, ex))
        listing.setComment(addr, CodeUnit.PRE_COMMENT, 'export NID %s size %d' % (name, size))

# manual names (addr -> name/sig/comment)
for a, v in manual.items():
    addr = A(int(a, 16))
    if int(a, 16) < text_end:
        f = fm.getFunctionAt(addr)
        if f is None: f = createFunction(addr, None)
        if f is None: print('manual: no function at ' + a); continue
        f.setName(v['name'], SourceType.USER_DEFINED)
        if v.get('sig'): apply_sig(f, v['sig'])
        if v.get('comment'):
            c = f.getComment() or ''
            f.setComment((c + '\n' if c else '') + v['comment'])
    else:
        createLabel(addr, v['name'], True, SourceType.USER_DEFINED)
        if v.get('comment'): listing.setComment(addr, CodeUnit.PRE_COMMENT, v['comment'])

# init / fini
for nm, key in (('_init', 'init'), ('_fini', 'fini')):
    if info.get(key) is not None:
        addr = A(info[key]); f = fm.getFunctionAt(addr)
        if f is None: f = createFunction(addr, nm)
        if f is not None: f.setName(nm, SourceType.IMPORTED)

# ---- 2a. make sure every switch case target is disassembled (disassembler ignores reference flows)
if len(args) > 3:
    jt = json.load(open(args[3]))
    nd = 0
    for a, v in jt.items():
        for t in v['targets']:
            ta = A(t)
            if listing.getInstructionAt(ta) is None:
                if listing.getDefinedDataAt(ta) is not None:
                    listing.clearCodeUnits(ta, ta, False)
                disassemble(ta); nd += 1
    print('disassembled %d switch targets' % nd)

# ---- 2b. check big exported functions whose Ghidra body is much smaller than the export size -> recreate
from ghidra.app.cmd.function import CreateFunctionCmd
for e in info['exports']:
    if e['addr'] < text_end and e['size'] > 2000:
        addr = A(e['addr']); f = fm.getFunctionAt(addr)
        if f is not None and f.getBody().getNumAddresses() < e['size'] * 0.8:
            print('function %s body %d < export size %d, recreating' % (f.getName(), f.getBody().getNumAddresses(), e['size']))
            nm = f.getName()
            fm.removeFunction(addr)
            cmd = CreateFunctionCmd(addr)
            cmd.applyTo(prog, monitor)
            f = fm.getFunctionAt(addr)
            if f is not None:
                f.setName(nm, SourceType.IMPORTED)
                print('  new body size %d' % f.getBody().getNumAddresses())

# ---- 3. decompile everything
opts = DecompileOptions()
opts.setMaxPayloadMBytes(2000)
ifc = DecompInterface()
ifc.setOptions(opts)
ifc.toggleCCode(True)
ifc.toggleSyntaxTree(True)
ifc.setSimplificationStyle('decompile')
ifc.openProgram(prog)

funcs = list(fm.getFunctions(True))
print('decompiling %d functions' % len(funcs))
if not os.path.exists(outdir): os.makedirs(outdir)
allc = open(os.path.join(outdir, 'expulsion_decompiled.c'), 'w')
allc.write('// LushModz-Expulsion-1.57.prx -- Ghidra %s decompilation, base 0\n' % (getGhidraVersion()))
allc.write('// %d functions. Imports named from PS4 NID db; own symbols are NID-hashed (see comments).\n\n' % len(funcs))
index = []
t0 = time.time()
for i, f in enumerate(funcs):
    ep = f.getEntryPoint()
    body = f.getBody()
    size = body.getNumAddresses()
    timeout = 7000 if size > 20000 else (900 if size > 4000 else 120)
    res = ifc.decompileFunction(f, timeout, monitor)
    hdr = '// ---- %s @ 0x%x (size %d)' % (f.getName(), ep.getOffset(), size)
    com = f.getComment()
    if com: hdr += '\n// ' + com.replace('\n', '\n// ')
    allc.write('\n' + hdr + '\n')
    if res is not None and res.decompileCompleted() and res.getDecompiledFunction() is not None:
        code = res.getDecompiledFunction().getC()
        allc.write(code)
        index.append(dict(name=f.getName(), addr=ep.getOffset(), size=size, ok=True, comment=com))
    else:
        err = res.getErrorMessage() if res is not None else 'null'
        allc.write('// DECOMPILE FAILED: %s\n' % err)
        index.append(dict(name=f.getName(), addr=ep.getOffset(), size=size, ok=False, comment=com, err=err))
    if i % 50 == 0:
        print('  %d/%d (%.0fs)' % (i, len(funcs), time.time() - t0))
        allc.flush()
allc.close()
json.dump(index, open(os.path.join(outdir, 'function_index.json'), 'w'), indent=1)
ifc.dispose()
print('done in %.0fs' % (time.time() - t0))

# ---- 4. strings
with open(os.path.join(outdir, 'strings.txt'), 'w') as sf:
    for d in listing.getDefinedData(True):
        if d.getDataType().getName().lower() in ('string', 'char', 'unicode', 'terminatedcstring'):
            try:
                v = d.getValue()
                if v is not None:
                    sf.write('0x%x\t%s\n' % (d.getAddress().getOffset(), unicode(v).encode('utf-8').replace('\n', '\\n')))
            except Exception as ex:
                pass
print('strings written')

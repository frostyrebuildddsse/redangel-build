#!/usr/bin/env python3
"""Style-targeted crack for Serendipity: snake_case functions (menu_*, prefixes), g_camelCase globals,
words from the binary's UI strings. usage: nidcrack4.py symbols.json hits.json elf"""
import json, hashlib, base64, itertools, sys, re, subprocess, time
SUF = bytes.fromhex('518D64A635DED8C1E6B039B1C3E55230')
def nid(n): return base64.b64encode(hashlib.sha1(n.encode() + SUF).digest()[:8][::-1], altchars=b'+-').decode()[:11]
symp, hitsp, elfp = sys.argv[1:4]
j = json.load(open(symp))
targets = {e['name']: e for e in j['exports'] if len(e['name']) == 11}
try: hits = json.load(open(hitsp))
except Exception: hits = {}
def check(s):
    n = nid(s)
    if n in targets and n not in hits:
        hits[n] = s; print('%#x %s -> %s (size %d)' % (targets[n]['addr'], n, s, targets[n]['size']), flush=True)
def mangle_params(ps):
    table = []; out = ''
    for p in ps:
        if len(p) == 1: out += p; continue
        if p in table: out += 'S_' if table.index(p) == 0 else 'S%d_' % (table.index(p) - 1); continue
        # pointer/const chain
        inner = p
        chain = []
        while inner[0] in 'PK' and len(inner) > 1:
            chain.append(inner); inner = inner[1:]
        o = p
        # simple: emit literally, register sub-candidates (inner-most first)
        for c in reversed(chain):
            if c not in table and len(c) > 1 and not (c[0] == 'K' and len(c) == 2 and False): table.append(c)
        out += o
    return out
t0 = time.time()
st = subprocess.run(['strings', '-n', '3', elfp], capture_output=True, text=True).stdout.split('\n')
from collections import Counter
wc = Counter()
for s in st:
    s = re.sub(r'~[a-zA-Z_0-9]+~', ' ', s)
    for w in re.findall(r'[A-Za-z][a-z]+|[A-Z]{2,}(?![a-z])', s):
        if 2 <= len(w) <= 14: wc[w.lower()] += 1
words = {w for w, c in wc.items() if c >= 3}
base = set('menu option options submenu sub toggle bool int float scroll keyboard draw text title print notify notification feed tip info banner header footer back open close input button buttons pad controller press pressed held hold up down left right select cancel square triangle cross circle r1 l1 r2 l2 r3 l3 dpad sound sounds instruction instructions scaleform color colour theme rainbow pos position width height scale font alpha self player players ped peds vehicle vehicles veh weapon weapons world online session network recovery money cash rp rank stats stat unlock unlocks teleport tp spawn spawner object objects spooner menyoo outfit outfits wardrobe clothes clothing tattoo tattoos model models anim anims scenario god mode godmode invincible invisible wanted never super jump run speed fast swim ragdoll noclip ammo infinite explosive rapid fire reload aim aimbot esp blip blips map radar weather time clock gravity freeze kick crash attach detach clone host script scripts global globals local locals tunable tunables hash hashes joaat native natives invoke call hook hooks patch patches memory mem read write ini settings config save load file files dir path loop loops tick update init setup run start stop main thread delay wait sleep timer frame frames count index list current last next prev max min value values data entity entities pickup pickups drop drops bodyguard bodyguards protection protections block bypass event events heist heists casino cayo perico apartment garage property business nightclub arcade agency bunker hangar facility yacht office clubhouse warehouse cargo vehicle_spawner'.split())
words = sorted(words | base)
base = sorted(base)
print(len(words), 'words', flush=True)
# snake_case names: 1-3 words; 3-word only with common first word
common = 'menu draw is get set add do toggle update handle on run init load save spawn give remove clear reset unlock apply open close show hide teleport kick crash request start stop render tick loop check parse read write find'.split()
names = set()
for a in words:
    names.add(a)
    for b in words:
        names.add(a + '_' + b)
for a in common:
    for b in base:
        for c in base:
            names.add(a + '_' + b + '_' + c)
names = sorted(names)
print(len(names), 'snake names', flush=True)
P = [[], ['i'], ['f'], ['b'], ['j'], ['PKc'], ['Pc'], ['Pv'], ['m'], ['y'], ['Pi'], ['Pf'], ['Pb'], ['ii'], ['if'], ['ib'], ['PKci'], ['PKcb'], ['PKcf'], ['PKcPb'], ['PKcPi'], ['PKcPf'], ['iPKc'], ['bi'], ['ff'], ['fff'], ['iii'], ['PKcPKc'], ['jj'], ['ji'], ['ij'],
     ['PKcPbPFvvE'], ['PKcPFvvE'], ['PKcPiiii'], ['PKcPfffi'], ['PKcPiiiPFvvE'], ['PKcPfffiPFvvE'], ['PFvvE'], ['PFvPKcE'], ['PKcPKcPKc'], ['PKcS_'], ['PKcS_S_'], ['PcS_'], ['PKcPKcS_']]
P = [''.join(p) for p in P]
for k, nm in enumerate(names):
    check(nm); check('_Z%d%sv' % (len(nm), nm))
    if k % 1000000 == 0: print(k, len(hits), time.time() - t0, flush=True); json.dump(hits, open(hitsp, 'w'), indent=1)
print('pass v done', time.time() - t0, flush=True)
json.dump(hits, open(hitsp, 'w'), indent=1)
pre_ok = ('menu_', 'draw_', 'set_', 'get_', 'is_', 'add_', 'toggle_', 'spawn_', 'give_', 'apply_', 'load_', 'save_', 'teleport_', 'notify', 'kick_', 'request_', 'update_', 'reset_', 'remove_', 'clear_', 'unlock_', 'handle_', 'on_', 'do_')
sub = [n for n in names if n.startswith(pre_ok) and n.count('_') <= 2]
print(len(sub), 'names for param pass', flush=True)
for k, nm in enumerate(sub):
    for p in P:
        if p: check('_Z%d%s%s' % (len(nm), nm, p))
    if k % 200000 == 0: print('p', k, len(hits), time.time() - t0, flush=True); json.dump(hits, open(hitsp, 'w'), indent=1)
print('snake done', time.time() - t0, flush=True)
# camelCase globals g_xxx / bool flags
for a in words:
    A = a[0].upper() + a[1:]
    for pre in ('g_', 'g', 's_', 'b'):
        check(pre + a); check(pre + A)
    for b in words:
        B = b[0].upper() + b[1:]
        for pre in ('g_', 'g', 's_', 'b', ''):
            check(pre + a + B)
            check(pre + A + B)
        check('g_' + a + '_' + b)
        for c in ('Enabled', 'Toggle', 'Index', 'Count', 'Value', 'Speed', 'Color', 'Alpha', 'Scale', 'Pos', 'Timer', 'Delay', 'Mode', 'Id', 'Ped', 'Veh', 'Handle', 'Max', 'Min', 'X', 'Y', 'Z', 'Hash', 'Model', 'List', 'Table', 'Names', 'Name', 'Text', 'Option', 'Options', 'Level', 'Active', 'On', 'Open', 'State', 'Type', 'Slot'):
            check('g_' + a + B + c); check('g_' + a + c)
print('globals done', time.time() - t0, flush=True)
json.dump(hits, open(hitsp, 'w'), indent=1)
print(len(hits), 'hits total')

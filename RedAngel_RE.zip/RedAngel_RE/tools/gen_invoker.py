#!/usr/bin/env python3
"""Generate invoker.h / invoker.c (C, exact replica of the binary's native invoker) + invoker.hpp (C++ template original form)."""
import json, sys, re, os
rn = json.load(open(sys.argv[1])); outdir = sys.argv[2]
TY = {'i': 'int', 'f': 'float', 'j': 'unsigned int', 'b': 'bool', 'PKc': 'const char *', 'Pc': 'char *', 'Pv': 'void *',
      'Pi': 'int *', 'Pf': 'float *', 'y': 'uint64_t', 'm': 'uint64_t', 'l': 'long', 'x': 'long long'}
def ctype(m):
    if m.startswith('R'): return ctype(m[1:]).rstrip() + ' *'
    return TY.get(m, 'void *')
def split_mangled(s):
    out = []; i = 0
    while i < len(s):
        if s[i] in 'RPK':
            j = i
            while j < len(s) and s[j] in 'RPK': j += 1
            out.append(s[i:j+1]); i = j + 1
        else: out.append(s[i]); i += 1
    return out
variants = []
for nid, v in rn['nids'].items():
    m = re.match(r'_Z6invokeI(.+?)J(.*?)EET_yDpOT0_$', v['full'] if v['full'].startswith('_Z') else '')
    m = re.match(r'invoke_(Vector3|[A-Za-z]+)(?:_([A-Za-z0-9]+))?$', v['name'])
    if m: variants.append((v['name'], m.group(1), split_mangled(m.group(2)) if m.group(2) else [], v.get('addr')))
for a, v in rn['manual'].items():
    m = re.match(r'invoke_(Vector3|[A-Za-z]+)(?:_([A-Za-z0-9]+))?$', v['name'])
    if m: variants.append((v['name'], m.group(1), split_mangled(m.group(2)) if m.group(2) else [], int(a, 16)))
variants.sort(key=lambda x: x[3] or 0)

H = ['''// invoker.h - native invoker of the Expulsion menu, reconstructed 1:1 from the PRX (C version).
// Natives are called through the game's own handler functions: eboot_base + offset (see natives157.h).
#pragma once
#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct { float x; float _px; float y; float _py; float z; float _pz; } Vector3;
typedef struct scrNativeCallContext {      // 128 bytes @ nativeContext (0xb4970)
    uint64_t *ret;        // -> nativeArgs
    uint32_t  argCount;
    uint32_t  _pad0;
    uint64_t *args;       // -> nativeArgs
    uint32_t  vecFixCount;
    uint32_t  _pad1;
    uint64_t *vecFixPtrs[8];
    Vector3   vecFixCopies[4];
} scrNativeCallContext;
extern uint64_t eboot_base;          // set in module_start from sceKernelGetModuleInfo("eboot.bin")
void nativeInit(void);               // 0x490
void nativeFixVectors(void);         // 0x3a0
void callHash(uint64_t offset);      // 0x450: ((void(*)(scrNativeCallContext*))(eboot_base + offset))(&ctx)
void pushArg_i(int v);               // 0x43460
void pushArg_j(unsigned int v);      // 0x435a0
void pushArg_f(float v);             // 0x43850
void pushArg_PKc(const char *v);     // 0x43ec0
void pushArg_Pi(int *v);             // 0x435e0
void pushArg_Pf(float *v);           // 0x45750
int           getReturn_i(void);     // 0x43500
unsigned int  getReturn_j(void);     // 0x434a0
float         getReturn_f(void);     // 0x438f0
const char   *getReturn_PKc(void);   // 0x44460
void         *getReturn_Pv(void);    // 0x436f0
void         *getReturn_Vector3(void *out); // 0x43970
''']
C = ['''// invoker.c - exact C replica of the binary's native invoker (originally C++ templates, see invoker.hpp)
#include "invoker.h"
#include <string.h>
uint64_t eboot_base = 0;
static uint64_t nativeArgs[30];                 // 0xb49f0, 240 bytes
static scrNativeCallContext nativeContext;      // 0xb4970
static uint32_t nativeArgCount;                 // 0xb4978
static uint64_t *nativeArgsPtr;                 // 0xb4980
static uint32_t nativeVecFixCount;              // 0xb4988
static float   *nativeVecFixPtrs[8];            // 0xb4990
static Vector3  nativeVecFixCopies[4];          // 0xb49b0

void nativeInit(void) {
    for (int i = 0; i < 30; i++) nativeArgs[i] = 0;
    nativeArgCount = 0;
    nativeVecFixCount = 0;
    nativeContext.ret = nativeArgs;
    nativeArgsPtr = nativeArgs;
}
void nativeFixVectors(void) {
    while (nativeVecFixCount != 0) {
        nativeVecFixCount--;
        float *dst = nativeVecFixPtrs[nativeVecFixCount];
        Vector3 *src = &nativeVecFixCopies[nativeVecFixCount];
        dst[0] = src->x; dst[2] = src->y; dst[4] = src->z;
    }
}
void callHash(uint64_t offset) {
    if (offset != 0)
        ((void (*)(scrNativeCallContext *))(offset + eboot_base))(&nativeContext);
}
void pushArg_i(int v)            { *(int *)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
void pushArg_j(unsigned int v)   { *(unsigned int *)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
void pushArg_f(float v)          { *(float *)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
void pushArg_PKc(const char *v)  { *(const char **)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
void pushArg_Pi(int *v)          { *(int **)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
void pushArg_Pf(float *v)        { *(float **)(nativeArgsPtr + nativeArgCount) = v; nativeArgCount++; }
int          getReturn_i(void)   { return *(int *)nativeContext.ret; }
unsigned int getReturn_j(void)   { return *(unsigned int *)nativeContext.ret; }
float        getReturn_f(void)   { return *(float *)nativeContext.ret; }
const char  *getReturn_PKc(void) { return *(const char **)nativeContext.ret; }
void        *getReturn_Pv(void)  { return *(void **)nativeContext.ret; }
void        *getReturn_Vector3(void *out) { memcpy(out, nativeContext.ret, 24); return out; }

// ---- invoke<R>(offset, Args&&...) instantiations found in the binary ----
''']
for name, r, args, addr in variants:
    params = ['uint64_t hash'] + ['%sa%d' % (ctype(a), k) for k, a in enumerate(args)]
    pushes = ''.join('pushArg_%s(%sa%d); ' % (a[1:] if a.startswith('R') else a, '*' if a.startswith('R') else '', k) for k, a in enumerate(args))
    if r == 'Vector3':
        sig = 'void *%s(void *out, %s)' % (name, ', '.join(params))
        body = '{ nativeInit(); %scallHash(hash); nativeFixVectors(); return getReturn_Vector3(out); }' % pushes
    else:
        sig = '%s%s(%s)' % (ctype(r) + ('' if ctype(r).endswith('*') else ' '), name, ', '.join(params))
        body = '{ nativeInit(); %scallHash(hash); nativeFixVectors(); return getReturn_%s(); }' % (pushes, r)
    H.append('%s;  // 0x%x' % (sig, addr or 0))
    C.append('%s %s' % (sig, body))
H.append('#ifdef __cplusplus\n}\n#endif\n')
open(os.path.join(outdir, 'invoker.h'), 'w').write('\n'.join(H))
open(os.path.join(outdir, 'invoker.c'), 'w').write('\n'.join(C) + '\n')
open(os.path.join(outdir, 'invoker.hpp'), 'w').write('''// invoker.hpp - the original C++ form of the invoker (what the mangled names _Z6invokeI<R>J<Args>EET_yDpOT0_,
// _Z7pushArgI<T>EvT_ and _Z9getReturnI<T>ET_v tell us). Use this when migrating the C files back to C++.
#pragma once
#include <cstdint>
#include <utility>
#include "invoker.h"
template<typename T> void pushArg(T v);
template<> inline void pushArg<int>(int v)                 { pushArg_i(v); }
template<> inline void pushArg<unsigned int>(unsigned v)   { pushArg_j(v); }
template<> inline void pushArg<float>(float v)             { pushArg_f(v); }
template<> inline void pushArg<const char *>(const char *v){ pushArg_PKc(v); }
template<> inline void pushArg<int *>(int *v)              { pushArg_Pi(v); }
template<> inline void pushArg<float *>(float *v)          { pushArg_Pf(v); }
template<typename T> T getReturn();
template<> inline int          getReturn<int>()          { return getReturn_i(); }
template<> inline unsigned int getReturn<unsigned int>() { return getReturn_j(); }
template<> inline float        getReturn<float>()        { return getReturn_f(); }
template<> inline const char  *getReturn<const char *>() { return getReturn_PKc(); }
template<> inline void        *getReturn<void *>()       { return getReturn_Pv(); }
template<> inline Vector3      getReturn<Vector3>()      { Vector3 v; getReturn_Vector3(&v); return v; }
template<typename R, typename... Args>
inline R invoke(uint64_t hash, Args&&... args) {
    nativeInit();
    (pushArg<std::decay_t<Args>>(std::forward<Args>(args)), ...);
    callHash(hash);
    nativeFixVectors();
    return getReturn<R>();
}
''')
print(len(variants), 'invoke variants')

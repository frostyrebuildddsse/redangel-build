#!/usr/bin/env python3
"""Build resolved_names.json: nid -> {name, full, sig} plus manual address names."""
import json, re, subprocess, sys
hits = json.load(open(sys.argv[1]))
syms = json.load(open(sys.argv[2]))
addr_of = {e['name']: e['addr'] for e in syms['exports']}

TY = {'i': 'int', 'f': 'float', 'j': 'uint', 'b': 'bool', 'v': 'void', 'PKc': 'char *', 'Pc': 'char *', 'Pv': 'void *',
      'Pi': 'int *', 'Pf': 'float *', 'y': 'ulonglong', 'm': 'ulong', 'l': 'long', 'x': 'longlong', 'c': 'char', 'h': 'uchar'}
def ctype(m):
    if m.startswith('R'):
        inner = ctype(m[1:]); return inner + ' *' if not inner.endswith('*') else inner + '*'
    if m == '7Vector3': return 'Vector3'
    return TY.get(m, 'undefined8')

def demangle(m):
    try:
        return subprocess.check_output(['c++filt', m]).decode().strip()
    except Exception:
        return m

def split_types(s):
    out = []; i = 0
    while i < len(s):
        if s[i] == 'R' or s[i] == 'P' or s[i] == 'K':
            j = i
            while s[j] in 'RPK': j += 1
            if s[j].isdigit():
                m = re.match(r'\d+', s[j:]); n = int(m.group(0)); end = j + len(m.group(0)) + n
            else:
                end = j + 1
            out.append(s[i:end]); i = end
        elif s[i].isdigit():
            m = re.match(r'\d+', s[i:]); n = int(m.group(0)); end = i + len(m.group(0)) + n
            out.append(s[i:end]); i = end
        else:
            out.append(s[i]); i += 1
    return out

names = {}
for nid, mangled in hits.items():
    full = demangle(mangled) if mangled.startswith('_Z') else mangled
    sig = None
    m = re.match(r'_Z6invokeI(.+?)J(.*?)EET_yDpOT0_$', mangled)
    if m:
        r, args = m.group(1), split_types(m.group(2))
        name = 'invoke_' + ('Vector3' if r == '7Vector3' else r) + ('_' + ''.join(args) if args else '')
        params = ['ulonglong hash'] + ['%s a%d' % (ctype(a), k) for k, a in enumerate(args)]
        if r == '7Vector3':
            sig = 'void * %s(void *out, %s)' % (name, ', '.join(params))
        else:
            sig = '%s %s(%s)' % (ctype(r), name, ', '.join(params))
    else:
        m = re.match(r'_Z7pushArgI(.+?)EvT_$', mangled)
        if m:
            t = m.group(1); name = 'pushArg_' + t; sig = 'void %s(%s v)' % (name, ctype(t))
        else:
            m = re.match(r'_Z9getReturnI(.+?)ET_v$', mangled)
            if m:
                t = m.group(1); name = 'getReturn_' + t; sig = '%s %s(void)' % (ctype(t), name)
            elif mangled.startswith('_Z'):
                mm = re.match(r'_Z(\d+)', mangled); n = int(mm.group(1))
                name = mangled[len(mm.group(0)):len(mm.group(0)) + n]
                if mangled == '_Z8callHashy': sig = 'void callHash(ulonglong hash)'
            else:
                name = mangled
    names[nid] = dict(name=name, full=full, sig=sig, addr=addr_of.get(nid))

manual = {
 0x490: ('nativeInit', 'void nativeInit(void)', 'clears 30 arg slots, argCount=0, vecFixCount=0, ctx.ret=ctx.args=nativeArgs'),
 0x3a0: ('nativeFixVectors', 'void nativeFixVectors(void)', 'copies Vector3 out-args back (scrNativeCallContext::FixVectors)'),
 0x43970: ('getReturn_Vector3', 'void * getReturn_Vector3(void *out)', None),
 0x43910: ('invoke_Vector3_Ri', 'void * invoke_Vector3_Ri(void *out, ulonglong hash, int *a0)', None),
 0x439a0: ('invoke_Vector3', 'void * invoke_Vector3(void *out, ulonglong hash)', None),
 0x43b30: ('invoke_Vector3_RiRi', 'void * invoke_Vector3_RiRi(void *out, ulonglong hash, int *a0, int *a1)', None),
 0xfc0: ('PLAYER_PED_ID', 'int PLAYER_PED_ID(void)', 'invoke<int>(0xaab000) -> eboot 1.57 native handler offset'),
 0xf10: ('GetCharacterIndex', 'int GetCharacterIndex(void)', 'model hash of player ped: 0=player_zero(Michael) 1=player_one(Franklin) 2=player_two(Trevor)'),
 0x510: ('FindGameModule', 'uint FindGameModule(char *name, ulonglong *base, uint *size)', 'source/main.cpp: sceKernelGetModuleList/Info loop'),
 0x1d0: ('Notify', 'void Notify(char *text, ulonglong icon)', 'sceKernelSendNotificationRequest wrapper'),
 0x380: ('NotifyText', 'void NotifyText(char *text)', None),
 0xb4050: ('eboot_base', None, 'base address of eboot.bin (GTA V 1.57), natives are called via eboot_base + offset'),
 0xb4970: ('nativeContext', None, 'scrNativeCallContext: {ret*, argCount, args*, ...} 128 bytes'),
 0xb49f0: ('nativeArgs', None, '30 x 8-byte native argument/return slots'),
 0xb4978: ('nativeArgCount', None, None),
 0xb4980: ('nativeArgsPtr', None, None),
 0xb4988: ('nativeVecFixCount', None, None),
 0xb4990: ('nativeVecFixPtrs', None, None),
 0xb49b0: ('nativeVecFixCopies', None, None),
}
out = dict(nids=names, manual={hex(k): dict(name=v[0], sig=v[1], comment=v[2]) for k, v in manual.items()})
json.dump(out, open(sys.argv[3], 'w'), indent=1)
print(len(names), 'nid names,', len(manual), 'manual')
for nid, v in sorted(names.items(), key=lambda kv: kv[1]['addr'] or 0):
    if v['sig']: print('  %#x %s' % (v['addr'], v['sig']))

#!/usr/bin/env python3
"""Resolve GTA V 1.57 native handler offsets used in a decompile to names.
exact: from the 390-entry 1.57 table (Expulsion); interpolated: monotonic mapping onto 2much4u's 1.27 natives.h
ordering, filtered by argument count observed at the call site.
usage: native_resolve.py decompiled.c table157.json natives127.h out.json
"""
import json, re, bisect, sys
dec, t157p, refp, outp = sys.argv[1:5]
t157 = {int(k, 16): v['name'] for k, v in json.load(open(t157p)).items()}
ref = []
for l in open(refp):
    m = re.search(r'static (.+?) (\w+)\((.*?)\) \{ .*?invoke<(.*?)>\((0x[0-9A-Fa-f]+)', l)
    if m:
        args = [a for a in m.group(3).split(',') if a.strip()]
        h = re.search(r'// (0x[0-9A-F]{16})', l)
        ref.append(dict(addr=int(m.group(5), 16), name=m.group(2), argc=len(args), ret=m.group(4), proto=l.strip().split('{')[0].replace('static ', '').strip(), hash=h.group(1) if h else None))
ref.sort(key=lambda r: r['addr'])
by_name = {r['name']: r for r in ref}
anchors = sorted((a, by_name[n]['addr']) for a, n in t157.items() if n in by_name)
src = open(dec).read()
# invoke wrappers: FUN_x(offset, args...) where FUN_x body = resetArgs; pushArg*; callNative; setVectors; getReturn
parts = re.split(r'\n// ---- ', src)
wrap_argc = {}
for p in parts[1:]:
    m = re.match(r'(\S+) @ (0x[0-9a-f]+)', p)
    if not m: continue
    body = p[p.find('\n{'):]
    if 'FUN_00000310(' in body and 'FUN_00000340()' in body and len(body) < 900:
        wrap_argc[m.group(1)] = len(re.findall(r'\bFUN_[0-9a-f]+\(\*?param_\d+\)|\bFUN_[0-9a-f]+\(\*?\(\w+ \*\)param_\d+\)', body.split('FUN_00000310(')[0]))
# call sites
sites = {}
for m in re.finditer(r'\b(FUN_[0-9a-f]+)\((0x[0-9a-f]{6,7})((?:,[^;]*?)?)\)', src):
    f = m.group(1)
    if f not in wrap_argc: continue
    off = int(m.group(2), 16)
    sites.setdefault(off, set()).add(wrap_argc[f])
def candidates(x, argc, anchors):
    xs = [a for a, _ in anchors]; i = bisect.bisect_left(xs, x)
    if i == 0 or i >= len(anchors): return None, []
    (a, ap), (b, bp) = anchors[i - 1], anchors[i]
    est = ap + (x - a) * (bp - ap) / (b - a)
    c = [r for r in ref if ap < r['addr'] < bp]
    if argc is not None:
        ca = [r for r in c if r['argc'] == argc]
        if ca: c = ca
    c.sort(key=lambda r: abs(r['addr'] - est))
    return est, c
# leave-one-out accuracy with argc
ok = tot = 0
for k, (a, ap) in enumerate(anchors):
    rest = anchors[:k] + anchors[k + 1:]
    r = by_name[t157[a]]
    _, c = candidates(a, r['argc'], rest)
    if c: tot += 1; ok += c[0]['name'] == t157[a]
print('leave-one-out with argc: %d/%d' % (ok, tot))
res = {}
for off in sorted(sites):
    argc = next(iter(sites[off])) if len(sites[off]) == 1 else None
    if off in t157:
        r = by_name.get(t157[off])
        res[hex(off)] = dict(name=t157[off], conf='exact', argc=argc, proto=r['proto'] if r else None, hash=r['hash'] if r else None); continue
    est, c = candidates(off, argc, anchors)
    if c:
        res[hex(off)] = dict(name=c[0]['name'], conf='interp', argc=argc, proto=c[0]['proto'], hash=c[0]['hash'], alt=[x['name'] for x in c[1:3]])
    else:
        res[hex(off)] = dict(name=None, conf='none', argc=argc)
json.dump(res, open(outp, 'w'), indent=1)
from collections import Counter
print(Counter(v['conf'] for v in res.values()), len(wrap_argc), 'invoke wrappers')

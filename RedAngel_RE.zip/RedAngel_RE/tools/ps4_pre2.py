# enable Decompiler Parameter ID with short timeout (skips the giant Menu function)
opts = getCurrentAnalysisOptionsAndValues(currentProgram)
for k in list(opts.keySet()):
    if k == 'Decompiler Parameter ID':
        setAnalysisOption(currentProgram, k, 'true'); print('enabled ' + k)
    if k == 'Decompiler Parameter ID.Analysis Decompiler Timeout (sec)':
        setAnalysisOption(currentProgram, k, '180'); print('set ' + k)
    if k == 'Decompiler Switch Analysis.Analysis Decompiler Timeout (sec)':
        setAnalysisOption(currentProgram, k, '180')

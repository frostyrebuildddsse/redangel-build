#!/usr/bin/env python3
"""Template + string-vocab NID crack: invoke<R>(hash, Args&&...), pushArg<T>, getReturn<T>, plus words from the binary's strings."""
import json, hashlib, base64, itertools, sys, re, subprocess, time
SUF = bytes.fromhex('518D64A635DED8C1E6B039B1C3E55230')
def nid(n): return base64.b64encode(hashlib.sha1(n.encode() + SUF).digest()[:8][::-1], altchars=b'+-').decode()[:11]
symp, hitsp, elfp = sys.argv[1:4]
j = json.load(open(symp))
targets = {e['name']: e for e in j['exports'] if len(e['name']) == 11}
try: hits = json.load(open(hitsp))
except Exception: hits = {}
def check(s):
    n = nid(s)
    if n in targets and n not in hits:
        hits[n] = s; print('%#x %s -> %s (size %d)' % (targets[n]['addr'], n, s, targets[n]['size']), flush=True)
t0 = time.time()
R = ['i', 'v', 'b', 'f', 'j', '7Vector3', 'PKc', 'Pc', 'y', 'Pv', 'm', 'l', 'x', 'h', 'c', 's', 't']
A1 = ['Ri', 'Rf', 'Rb', 'Rj', 'RPKc', 'RPv', 'RPi', 'RPf', 'Ry', 'RPc', 'R7Vector3', 'Rm', 'Rl', 'Rx', 'i', 'f', 'b', 'j', 'PKc', 'Pv', 'Pi', 'Pf', 'y', 'Pc', '7Vector3', 'RKi', 'RKf', 'RKj', 'RKb', 'Rh', 'RPh', 'RA2_c', 'RA16_c', 'RA32_c', 'RA64_c', 'RA128_c', 'RA256_c', 'RK7Vector3', 'RPb', 'RPj', 'RPy']
A2 = ['Ri', 'Rf', 'Rb', 'Rj', 'RPKc', 'i', 'f', 'j', 'b', 'RPv', 'Ry', 'RPi', 'RPf']
for fname in ['invoke', 'Invoke']:
    for hashT in ['y', 'm', 'j']:
        for r in R:
            check('_Z%d%sI%sJEET_%sDpOT0_' % (len(fname), fname, r, hashT))
            for n in range(1, 4):
                for args in itertools.product(A1, repeat=n):
                    check('_Z%d%sI%sJ%sEET_%sDpOT0_' % (len(fname), fname, r, ''.join(args), hashT))
            for n in range(4, 7):
                for args in itertools.product(A2, repeat=n):
                    check('_Z%d%sI%sJ%sEET_%sDpOT0_' % (len(fname), fname, r, ''.join(args), hashT))
    print(fname, 'done', time.time() - t0, flush=True)
    if any(v.startswith('_Z6invokeI') for v in hits.values()): break
TT = R + [a for a in A1]
for fname in ['pushArg', 'push', 'nativePush', 'PushArg', 'Push', 'pushArgs', 'addArg']:
    for t in TT:
        check('_Z%d%sI%sEvT_' % (len(fname), fname, t)); check('_Z%d%sI%sEvRKT_' % (len(fname), fname, t))
for fname in ['getReturn', 'GetReturn', 'getResult', 'nativeReturn', 'getRet', 'ret']:
    for t in TT:
        check('_Z%d%sI%sET_v' % (len(fname), fname, t))
print('push/ret done', flush=True)
# vocab from strings
st = subprocess.run(['strings', '-n', '3', elfp], capture_output=True, text=True).stdout
words = set(re.findall(r'\b[A-Za-z][a-z]{2,14}\b', st))
words |= {w.lower() for w in words} | {w[0].upper() + w[1:] for w in words}
words = sorted(words)[:6000]
print(len(words), 'vocab words', flush=True)
params = ['v', 'i', 'f', 'b', 'j', 'y', 'Pc', 'PKc', 'Pv', 'Pb', 'Pi', 'Pf', 'ii', 'iii', 'ib', 'if', 'bb', 'ff', 'fff', 'ffff', 'Pci', 'Pcb', 'PKci', 'PKcb', 'PKcf',
          'PKcPb', 'PKcPi', 'PKcPf', 'PcPb', 'PKcPKc', 'PKcii', 'PKciii', 'PKcPbPFvvE', 'PKcPFvvE', 'PFvvE', 'iPKc', 'iPc', 'ji', 'ij', 'jj', 'jb', 'bi', 'iiii', 'Pvm', 'PvPKvm', 'PKcz', 'PcPKcz', 'PcmPKcz', 'PKcRb', 'PKcRi', 'PKcRf', 'PKcRbPFvvE', 'PKcRiiiPFvvE', 'PKcRfffPFvvE', 'PKcRiii', 'PKcRfff']
pref = ['', 'is', 'get', 'set', 'add', 'draw', 'do', 'run', 'on', 'toggle', 'update', 'handle', 'menu', 'g_', 'b', 's_', 'm_']
for w in words:
    for p in pref:
        nm = (p + w[0].upper() + w[1:]) if p and not p.endswith('_') else p + w
        check(nm)
        for pr in params:
            check('_Z%d%s%s' % (len(nm), nm, pr))
print('vocab done', time.time() - t0, flush=True)
json.dump(hits, open(hitsp, 'w'), indent=1)
print(len(hits), 'hits total')

#!/usr/bin/env python3
"""Parse PS4 ELF dynlibdata: symbols, imports/exports, relocations.
Applies RELATIVE/64/GLOB_DAT relocs at base 0 into a Ghidra-friendly ELF,
and emits a JSON with symbol info for a Ghidra post-script.
"""
import struct, sys, json, hashlib, base64

NID_SUFFIX = bytes.fromhex('518D64A635DED8C1E6B039B1C3E55230')

def calc_nid(name: str) -> str:
    h = hashlib.sha1(name.encode() + NID_SUFFIX).digest()
    return base64.b64encode(h[:8][::-1], altchars=b'+-').decode()[:11]

def load_nid_db(path):
    db = {}
    for line in open(path, encoding='utf-8-sig'):
        n = line.strip()
        if n:
            db[calc_nid(n)] = n
    return db

DT = {
 'SCE_FINGERPRINT':0x61000007,'SCE_ORIGINAL_FILENAME':0x61000009,'SCE_MODULE_INFO':0x6100000D,
 'SCE_NEEDED_MODULE':0x6100000F,'SCE_MODULE_ATTR':0x61000011,'SCE_EXPORT_LIB':0x61000013,
 'SCE_IMPORT_LIB':0x61000015,'SCE_EXPORT_LIB_ATTR':0x61000017,'SCE_IMPORT_LIB_ATTR':0x61000019,
 'SCE_HASH':0x61000025,'SCE_PLTGOT':0x61000027,'SCE_JMPREL':0x61000029,'SCE_PLTREL':0x6100002B,
 'SCE_PLTRELSZ':0x6100002D,'SCE_RELA':0x6100002F,'SCE_RELASZ':0x61000031,'SCE_RELAENT':0x61000033,
 'SCE_STRTAB':0x61000035,'SCE_STRSZ':0x61000037,'SCE_SYMTAB':0x61000039,'SCE_SYMENT':0x6100003B,
 'SCE_HASHSZ':0x6100003D,'SCE_SYMTABSZ':0x6100003F,'INIT':12,'FINI':13,'NEEDED':1,
 'INIT_ARRAY':0x19,'INIT_ARRAYSZ':0x1b,'FINI_ARRAY':0x1a,'FINI_ARRAYSZ':0x1c,
}
DTN = {v:k for k,v in DT.items()}

B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-'

class PS4Elf:
    def __init__(self, path):
        self.d = bytearray(open(path,'rb').read())
        d = self.d
        (self.e_type, self.e_machine, _, self.e_entry, self.e_phoff, self.e_shoff, _, _,
         self.e_phentsize, self.e_phnum, _, _, _) = struct.unpack_from('<HHIQQQIHHHHHH', d, 16)
        self.phdrs = []
        for i in range(self.e_phnum):
            self.phdrs.append(list(struct.unpack_from('<IIQQQQQQ', d, self.e_phoff + i*self.e_phentsize)))
        self.dyn = None; self.dynlib = None
        for ph in self.phdrs:
            if ph[0] == 2: self.dyn = ph
            if ph[0] == 0x61000000: self.dynlib = ph
        self.tags = []
        off = self.dyn[2]
        for i in range(self.dyn[5]//16):
            t,v = struct.unpack_from('<QQ', d, off+i*16)
            if t == 0: break
            self.tags.append((t,v))
        self.tag = {}
        for t,v in self.tags:
            self.tag.setdefault(t, []).append(v)
        dl = self.dynlib[2]
        self.dl = dl
        self.strtab_off = dl + self.tag[DT['SCE_STRTAB']][0]
        self.strsz = self.tag[DT['SCE_STRSZ']][0]
        self.symtab_off = dl + self.tag[DT['SCE_SYMTAB']][0]
        self.symtabsz = self.tag[DT['SCE_SYMTABSZ']][0]
        self.rela_off = dl + self.tag[DT['SCE_RELA']][0]
        self.relasz = self.tag[DT['SCE_RELASZ']][0]
        self.jmprel_off = dl + self.tag[DT['SCE_JMPREL']][0]
        self.pltrelsz = self.tag[DT['SCE_PLTRELSZ']][0]
        # modules / libraries
        self.modules = {}   # id -> name
        for v in self.tag.get(DT['SCE_NEEDED_MODULE'], []):
            mid = (v >> 48) & 0xffff; self.modules[mid] = self.str(v & 0xffffffff)
        for v in self.tag.get(DT['SCE_MODULE_INFO'], []):
            mid = (v >> 48) & 0xffff; self.modules[mid] = self.str(v & 0xffffffff)
        self.libs = {}      # id -> (name, is_export)
        for v in self.tag.get(DT['SCE_IMPORT_LIB'], []):
            lid = (v >> 48) & 0xffff; self.libs[lid] = (self.str(v & 0xffffffff), False)
        for v in self.tag.get(DT['SCE_EXPORT_LIB'], []):
            lid = (v >> 48) & 0xffff; self.libs[lid] = (self.str(v & 0xffffffff), True)
        self.orig_filename = self.str(self.tag[DT['SCE_ORIGINAL_FILENAME']][0]) if DT['SCE_ORIGINAL_FILENAME'] in self.tag else None
        # symbols
        self.syms = []
        for i in range(self.symtabsz // 24):
            st_name, st_info, st_other, st_shndx, st_value, st_size = struct.unpack_from('<IBBHQQ', d, self.symtab_off + i*24)
            name = self.str(st_name)
            self.syms.append(dict(idx=i, raw=name, info=st_info, bind=st_info>>4, type=st_info&0xf,
                                  shndx=st_shndx, value=st_value, size=st_size))
        # relocs
        self.rela = [struct.unpack_from('<QQq', d, self.rela_off + i*24) for i in range(self.relasz//24)]
        self.jmprel = [struct.unpack_from('<QQq', d, self.jmprel_off + i*24) for i in range(self.pltrelsz//24)]

    def str(self, off):
        d = self.d; s = self.strtab_off + off; e = d.index(b'\0', s)
        return d[s:e].decode('latin1')

    def v2o(self, va):
        for ph in self.phdrs:
            if ph[0] in (1, 0x61000010) and ph[3] <= va < ph[3] + ph[6]:
                return ph[2] + (va - ph[3])
        return None

    def decode_sym(self, raw, nid_db):
        """'NID#L#M' -> (name, libname, modname)"""
        parts = raw.split('#')
        if len(parts) == 3 and len(parts[0]) == 11:
            nid, l, m = parts
            lid = B64.index(l); mid = B64.index(m)
            return nid_db.get(nid, nid), self.libs.get(lid, ('?',None))[0], self.modules.get(mid, '?'), nid
        return raw, None, None, None


def main():
    inp, outp, jsonp, nid_path = sys.argv[1:5]
    nid_db = load_nid_db(nid_path)
    assert calc_nid('sceKernelLoadStartModule') == 'wzvqT4UqKX8', calc_nid('sceKernelLoadStartModule')
    e = PS4Elf(inp)
    print('original filename:', e.orig_filename)
    print('modules:', e.modules)
    print('libs:', e.libs)
    exports, imports_data, plt = [], {}, {}
    symbyidx = {}
    for s in e.syms:
        name, lib, mod, nid = e.decode_sym(s['raw'], nid_db)
        s['name'] = name; s['lib'] = lib; s['mod'] = mod; s['nid'] = nid
        if s['shndx'] != 0 and s['value'] != 0:
            exports.append(dict(addr=s['value'], name=name, size=s['size'], type=s['type'], lib=lib))
    print(f'{len(e.syms)} symbols, {len(exports)} defined')
    # apply relocations (base 0)
    d = e.d
    applied = {}
    unresolved = []
    def write64(va, val):
        o = e.v2o(va)
        if o is None:
            unresolved.append(('nofile', va, val)); return
        struct.pack_into('<Q', d, o, val & 0xffffffffffffffff)
    for r_off, r_info, r_add in e.rela:
        rtype = r_info & 0xffffffff; symi = r_info >> 32
        s = e.syms[symi] if symi else None
        if rtype == 8:      # RELATIVE
            write64(r_off, r_add); applied['RELATIVE'] = applied.get('RELATIVE',0)+1
        elif rtype == 1:    # R_X86_64_64: S + A
            if s and s['shndx'] != 0:
                write64(r_off, s['value'] + r_add); applied['64'] = applied.get('64',0)+1
            else:
                imports_data[r_off] = dict(name=s['name'], lib=s['lib'], mod=s['mod'], addend=r_add, kind='64')
        elif rtype == 6:    # GLOB_DAT: S
            if s and s['shndx'] != 0:
                write64(r_off, s['value']); applied['GLOB_DAT'] = applied.get('GLOB_DAT',0)+1
            else:
                imports_data[r_off] = dict(name=s['name'], lib=s['lib'], mod=s['mod'], addend=0, kind='GLOB_DAT')
        elif rtype == 7:
            if s and s['shndx'] != 0: write64(r_off, s['value'])
            else: imports_data[r_off] = dict(name=s['name'], lib=s['lib'], mod=s['mod'], addend=0, kind='JUMP_SLOT')
        else:
            unresolved.append(('type', rtype, r_off))
    got_imports = {}
    for r_off, r_info, r_add in e.jmprel:
        rtype = r_info & 0xffffffff; symi = r_info >> 32
        s = e.syms[symi]
        assert rtype == 7, rtype
        if s['shndx'] != 0:
            write64(r_off, s['value']); continue
        got_imports[r_off] = dict(name=s['name'], lib=s['lib'], mod=s['mod'], nid=s['nid'])
    print('applied relocs:', applied, 'unresolved:', len(unresolved), unresolved[:5])
    print(f'{len(got_imports)} function imports, {len(imports_data)} data imports')
    # find PLT stubs: FF 25 disp32  (jmp [rip+disp])
    text = e.phdrs[0]
    toff, tva, tsz = text[2], text[3], text[5]
    i = 0
    while i < tsz - 6:
        if d[toff+i] == 0xFF and d[toff+i+1] == 0x25:
            disp = struct.unpack_from('<i', d, toff+i+2)[0]
            target = tva + i + 6 + disp
            if target in got_imports:
                plt[tva+i] = got_imports[target]
            i += 6
        else:
            i += 1
    print(f'{len(plt)} PLT stubs matched')
    unresolved_names = sorted({v['name'] for v in list(got_imports.values())+list(imports_data.values()) if len(v['name'])==11 and v['name']==v.get('nid', v['name'])})
    print(f'unresolved NIDs: {len(unresolved_names)}')
    # init/fini
    init = e.tag.get(DT['INIT'],[None])[0]; fini = e.tag.get(DT['FINI'],[None])[0]
    # ---- build Ghidra-friendly ELF
    struct.pack_into('<H', d, 16, 3)              # ET_DYN
    struct.pack_into('<QHHH', d, 40, 0, 0, 0, 0)  # e_shoff=0 ... careful: e_shoff(8) e_flags(4) e_ehsize(2) e_phentsize(2)
    # redo properly: offsets: e_shoff@40(8), e_flags@48(4), e_ehsize@52(2), e_phentsize@54(2), e_phnum@56(2), e_shentsize@58(2), e_shnum@60(2), e_shstrndx@62(2)
    struct.pack_into('<Q', d, 40, 0)
    struct.pack_into('<IHH', d, 48, 0, 64, 56)
    struct.pack_into('<HHH', d, 58, 0, 0, 0)
    for i, ph in enumerate(e.phdrs):
        if ph[0] == 0x61000010: ph[0] = 1            # RELRO -> LOAD
        elif ph[0] in (2, 0x61000000, 0x61000002, 0x6474e550): ph[0] = 0   # NULL out dynamic/dynlibdata/moduleparam/ehframe hdr
        if ph[0] == 1 and ph[5] < ph[6]: ph[5] = ph[6]   # extend bss into file (zeros already there)
        struct.pack_into('<IIQQQQQQ', d, e.e_phoff + i*e.e_phentsize, *ph)
    open(outp, 'wb').write(d)
    info = dict(orig_filename=e.orig_filename, modules=e.modules, libs={k:v[0] for k,v in e.libs.items()},
                init=init, fini=fini,
                exports=exports,
                plt={hex(k):v for k,v in plt.items()},
                got_imports={hex(k):v for k,v in got_imports.items()},
                data_imports={hex(k):v for k,v in imports_data.items()},
                symbols=[dict(raw=s['raw'], name=s['name'], value=s['value'], size=s['size'], bind=s['bind'], type=s['type'], shndx=s['shndx'], lib=s['lib'], mod=s['mod']) for s in e.syms],
                unresolved_nids=unresolved_names)
    json.dump(info, open(jsonp,'w'), indent=1)
    print('wrote', outp, jsonp)

if __name__ == '__main__':
    main()

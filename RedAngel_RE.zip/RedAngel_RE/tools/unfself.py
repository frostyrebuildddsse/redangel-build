#!/usr/bin/env python3
"""Convert a PS4 fake-signed SELF (fSELF) back into a plain ELF."""
import struct, sys

SELF_MAGIC = 0x1D3D154F

def main(inp, outp):
    d = open(inp, 'rb').read()
    magic, ver, mode, endian, attr, keytype, hdr_size, meta_size, file_size, num_entries, flags, pad = \
        struct.unpack_from('<IBBBBIHHQHHI', d, 0)
    assert magic == SELF_MAGIC, 'not a SELF'
    print(f'SELF: ver={ver} mode={mode} attr={attr:#x} keytype={keytype:#x} hdr_size={hdr_size:#x} meta_size={meta_size:#x} file_size={file_size:#x} entries={num_entries} flags={flags:#x}')
    entries = []
    off = 0x20
    for i in range(num_entries):
        props, eoff, filesz, memsz = struct.unpack_from('<QQQQ', d, off)
        off += 0x20
        seg_idx = (props >> 20) & 0xffff
        has_meta = (props >> 20) & 1
        blocked = (props >> 11) & 1
        compressed = (props >> 3) & 1
        encrypted = (props >> 1) & 1
        signed = (props >> 2) & 1
        entries.append((props, eoff, filesz, memsz, seg_idx))
        print(f'  entry {i}: props={props:#010x} seg_idx={seg_idx} blocked={blocked} comp={compressed} enc={encrypted} signed={signed} off={eoff:#x} filesz={filesz:#x} memsz={memsz:#x}')
    elf_off = off
    ehdr = d[elf_off:elf_off+64]
    assert ehdr[:4] == b'\x7fELF'
    (e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags, e_ehsize,
     e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = struct.unpack_from('<HHIQQQIHHHHHH', ehdr, 16)
    print(f'ELF: type={e_type:#x} machine={e_machine} entry={e_entry:#x} phoff={e_phoff:#x} phnum={e_phnum} shoff={e_shoff:#x} shnum={e_shnum}')
    phdrs = []
    for i in range(e_phnum):
        ph = struct.unpack_from('<IIQQQQQQ', d, elf_off + e_phoff + i*e_phentsize)
        phdrs.append(ph)
        p_type, p_flags, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = ph
        print(f'  phdr {i}: type={p_type:#010x} flags={p_flags:#x} off={p_offset:#x} vaddr={p_vaddr:#x} filesz={p_filesz:#x} memsz={p_memsz:#x} align={p_align:#x}')
    # output ELF: header + phdrs at start, then each segment's data at its original p_offset
    total = max([ph[2] + ph[5] for ph in phdrs] + [e_phoff + e_phnum*e_phentsize])
    out = bytearray(total)
    out[0:64] = ehdr
    out[e_phoff:e_phoff + e_phnum*e_phentsize] = d[elf_off + e_phoff: elf_off + e_phoff + e_phnum*e_phentsize]
    # map data entries (those without the meta bit) by segment index -> phdr index
    for props, eoff, filesz, memsz, seg_idx in entries:
        if props & (1 << 16):   # digest/meta block for another entry, skip
            continue
        if (props >> 3) & 1:
            raise SystemExit('compressed segment, need zlib handling')
        ph = phdrs[seg_idx]
        p_offset, p_filesz = ph[2], ph[5]
        n = min(filesz, p_filesz)
        out[p_offset:p_offset+n] = d[eoff:eoff+n]
        print(f'  copied seg {seg_idx}: {n:#x} bytes -> file off {p_offset:#x}')
    open(outp, 'wb').write(out)
    print(f'wrote {outp} ({len(out):#x} bytes)')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])

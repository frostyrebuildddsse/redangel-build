from capstone import *
import struct, json, sys
d=open(sys.argv[1],'rb').read()
md=Cs(CS_ARCH_X86, CS_MODE_64)
TEXT_OFF=0x4000; TEXT_END=0x11c000; CODE_END=0xf72a0
def v2o(va):
    if va<0x11c000: return 0x4000+va
    if 0x11c000<=va<0x17c000: return 0x120000+(va-0x11c000)
    if 0x17c000<=va<0x17f431: return 0x180000+(va-0x17c000)
    return None
ins=[]; pos=0x1000
code=d[TEXT_OFF:TEXT_OFF+TEXT_END]
while pos<TEXT_END:
    got=False
    for i in md.disasm(code[pos:],pos):
        ins.append(i); pos=i.address+i.size; got=True
    if not got or pos<TEXT_END: pos+=1
tables={}
for k,i in enumerate(ins):
    if i.mnemonic=='jmp' and i.op_str=='rax' and k>=5 and i.address<CODE_END:
        p=ins[k-5:k]
        if p[2].mnemonic=='lea' and p[2].op_str.startswith('rcx, [rip + ') and p[3].mnemonic=='movsxd' and p[4].mnemonic=='add' and p[0].mnemonic=='ja':
            disp=int(p[2].op_str.split('+')[1].rstrip(']').strip(),16)
            table=p[2].address+p[2].size+disp
            n=None
            for b in range(k-6,max(k-14,0),-1):
                if ins[b].mnemonic in('sub','cmp') and (ins[b].op_str.startswith('eax, ') or ins[b].op_str.startswith('rax, ')):
                    n=int(ins[b].op_str.split(', ')[1],0); break
            if n is None: print('no bound', hex(i.address)); continue
            cnt=n+1; to=v2o(table)
            targets=[table+struct.unpack_from('<i',d,to+e*4)[0] for e in range(cnt)]
            bad=[t for t in targets if not (0x1000<=t<CODE_END)]
            if bad: print('bad', hex(i.address), [hex(b) for b in bad[:3]]); continue
            tables[i.address]=dict(table=table,count=cnt,default=int(p[0].op_str,16),targets=sorted(set(targets)))
        else:
            print('unmatched', hex(i.address))
print(len(tables),'jump tables resolved')
json.dump({hex(k):v for k,v in tables.items()}, open(sys.argv[2],'w'))

# Red Angel (redangel) – rekonstruierter Source-Tree

**Was das ist:** Das Ghidra-Pseudo-C von `Seren.prx`, automatisch in kompilierbares C überführt. Keine
Original-Source – die ist nicht rekonstruierbar. Die Logik entspricht 1:1 dem Binary (clang -O0, jede
Zeile ≈ eine Source-Zeile). Namen: 110+ per NID-Crack rekonstruiert (`menu_*_tick`, `g_spawn*Options`, …),
1150 Native-Funktionen nach ihrem Native benannt, der Rest heißt `FUN_<addr>` / `DAT_<addr>`.

```
source/
  main.c          plugin_load / plugin_unload, DOES_CAM_EXIST-Hook, Arm-Thread, Notify   (< 0x1000)
  menu.c          das komplette Menü: Invoker, alle Natives, Submenüs, Features, Settings, Spooner …
  sdk.c           einkompilierter GoldHEN-SDK-Anteil (Detour/Patcher/HDE64/Syscalls) – im Rebuild durch libGoldHEN_Hook ersetzbar
  globals.h/.c    alle Globals byte-genau mit Initialwerten; absolute Eboot-Adressen als #define (*(volatile T*)0x…)
  natives157.h    Native-Handler-Offsets (GTA V 1.57, relativ zu 0x400000) als N_<NAME>
                  "__guess" = interpolierter Name (≈89 % Trefferquote), ohne Suffix = exakt verifiziert
  functions.h     Prototypen aller Funktionen
  ghidra_types.h  undefined4/CONCAT44/SUB/… Shims
  ps4_imports.h   die 46 Imports (libkernel, libc, libSceRtc, libSceVideoOut)
  invoker.h       Doku zum Invoker + Vector3
Makefile          OpenOrbis + GoldHEN SDK; `make check` = Host-Syntaxcheck mit clang
```

## Invoker (2much4u-Menu-Base-Schema)
`resetArgs()` → `pushArg_<typ>()` → `callHash(offset)` = `((void(*)(NativeArg_s*))(offset + 0x400000))(&nativeArg)`
→ `setVectors()` → `getReturn_<typ>()`. Die 111 Instanzen von `invoke<R>(u64, Args...)` heißen `invoke_<ret>_<args>`
(i=int, f=float, b=bool, s=const char*, pi=int*, pf=float*, pv3=Vector3*, v3=Vector3, p=void*).
Jede Native hat eine eigene kleine Funktion (`PLAYER_PED_ID()`, `SET_ENTITY_COORDS__guess()` …), mehrfach
vorhanden, weil `natives.h` pro Übersetzungseinheit als `static` eingebunden war – die Duplikate zeigen die
ursprünglichen .cpp-Grenzen.

## Bekannte Baustellen
- Byte-Array-Globals (`uint8_t DAT_xxx[N]`) sind semantisch Structs/Arrays des Originals – Typen bei Bedarf setzen.
- Float-Konstanten an untypisierte Callees erscheinen als Hex (`0x3f800000` = 1.0f).
- `__guess`-Natives vor Nutzung gegen deine 1.57-IDB prüfen (Liste mit Alternativen in `decompile/natives_resolved.json`).

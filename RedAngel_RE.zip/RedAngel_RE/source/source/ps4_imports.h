// ps4_imports.h - the 46 functions Seren imports from libkernel / libSceLibcInternal / libSceRtc / libSceVideoOut
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifdef __cplusplus
extern "C" {
#endif
int   sceKernelOpen(const char *path, int flags, ...);
int   sceKernelClose(int fd);
int   sceKernelGetdents(int fd, char *buf, int nbytes);
int   sceKernelMkdir(const char *path, int mode);
int   sceKernelMmap(void *addr, size_t len, int prot, int flags, int fd, long long off, void **res);
int   sceKernelMprotect(const void *addr, size_t len, int prot);
int   sceKernelMunmap(void *addr, size_t len);
int   sceKernelSendNotificationRequest(int dev, void *req, size_t size, int blocking);
int   sceKernelUsleep(unsigned int us);
int   scePthreadCreate(void **thread, const void *attr, void *(*entry)(void *), void *arg, const char *name);
void  scePthreadExit(void *ret);
int   sceRtcGetCurrentClockLocalTime(void *time);
int   sceVideoOutSetFlipRate(int handle, int rate);
int  *__error(void);
long  syscall(long n, ...);
#ifdef __cplusplus
}
#endif
// Ghidra helper macros that clash with libc names
#undef NAN
#define NAN(x) __builtin_isnan((double)(x))
#ifndef ABS
#define ABS(x) ((x) < 0 ? -(x) : (x))
#endif

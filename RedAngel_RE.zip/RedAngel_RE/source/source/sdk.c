// sdk.c - auto-converted from Ghidra decompilation of LushModz-Expulsion-1.57.prx
#include "ghidra_types.h"
#include "ps4_imports.h"
#include "globals.h"
#include "natives157.h"
#include "invoker.h"
#include "functions.h"

// FUN_00079050 @ 0x79050  (export NID Z2dxx4Mn290)
undefined8 FUN_00079050(long param_1,undefined8 *param_2,undefined8 param_3)

{
  *(undefined8 *)(param_1 + 0x36) = param_3;
  sceKernelMprotect(param_2,0xe,7);
  *param_2 = *(undefined8 *)(param_1 + 0x30);
  *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 0x38);
  *(undefined2 *)((long)param_2 + 0xc) = *(undefined2 *)(param_1 + 0x3c);
  return 0;
}

// FUN_000790b0 @ 0x790b0  (export NID vf70rqua+dY)
undefined8 FUN_000790b0(long param_1,undefined4 *param_2,int param_3)

{
  *(int *)(param_1 + 0x3f) = param_3 - ((int)param_2 + 5);
  sceKernelMprotect(param_2,5,7);
  *param_2 = *(undefined4 *)(param_1 + 0x3e);
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 0x42);
  return 0;
}

// FUN_00079110 @ 0x79110  (export NID 8JoJ+by8mGU)
undefined8 FUN_00079110(undefined8 param_1,long param_2)

{
  return *(undefined8 *)(param_2 + 6);
}

// FUN_00079130 @ 0x79130  (export NID UuFDWO5gZGk)
undefined8 FUN_00079130(int *param_1,undefined8 param_2,undefined8 param_3)

{
  undefined8 local_10;
  
  if (*param_1 == 0) {
    local_10 = FUN_000793d0(param_1, param_2, param_3);
  }
  else if (*param_1 == 1) {
    local_10 = FUN_000791c0(param_1, param_2, param_3);
  }
  else {
    local_10 = 0;
  }
  return local_10;
}

// FUN_000791c0 @ 0x791c0  (export NID zaoOUvh1prY)
undefined8 FUN_000791c0(undefined4 *param_1,void *param_2,long param_3)

{
  uint uVar1;
  int iVar2;
  ulong len;
  void *pvVar3;
  undefined8 local_10;
  
  if ((param_2 == (void *)0x0) || (param_3 == 0)) {
    local_10 = 0;
  }
  else {
    len = FUN_00078fb0(param_1, param_2, 5);
    if (len < 5) {
      local_10 = 0;
    }
    else {
      iVar2 = memcmp(param_2,(void *)((long)param_1 + 0x3e),1);
      if ((iVar2 == 0) && (len == 5)) {
        uVar1 = *(uint *)((long)param_2 + 1);
        *param_1 = 0;
        local_10 = FUN_000793d0(param_1, (long)param_2 + (ulong)uVar1 + 5, param_3);
      }
      else {
        pvVar3 = malloc(0xe);
        *(void **)(param_1 + 8) = pvVar3;
        if (*(long *)(param_1 + 8) == 0) {
          local_10 = 0;
        }
        else {
          FUN_00079050(param_1, *(undefined8 *)(param_1 + 8), param_3);
          *(void **)(param_1 + 6) = param_2;
          *(long *)(param_1 + 10) = param_3;
          sceKernelMprotect(param_2,len,7);
          *(ulong *)(param_1 + 4) = len + 0xe;
          iVar2 = sceKernelMmap((void *)0x0,*(ulong *)(param_1 + 4),7,0x1002,-1,0,
                                (void **)(param_1 + 2));
          if ((iVar2 < 0) || (*(long *)(param_1 + 2) == 0)) {
            local_10 = 0;
          }
          else {
            memcpy(*(void **)(param_1 + 2),param_2,len);
            FUN_00079050(param_1, *(long *)(param_1 + 2) + len, (long)param_2 + len);
            memset(param_2,0x90,len);
            FUN_000790b0(param_1, param_2, *(undefined8 *)(param_1 + 8));
            local_10 = *(undefined8 *)(param_1 + 2);
          }
        }
      }
    }
  }
  return local_10;
}

// FUN_000793d0 @ 0x793d0  (export NID l-65wuZIroM)
undefined8 FUN_000793d0(long param_1,void *param_2,long param_3)

{
  uint uVar1;
  int iVar2;
  undefined8 local_10;
  
  if ((param_2 == (void *)0x0) || (param_3 == 0)) {
    local_10 = 0;
  }
  else {
    uVar1 = FUN_00078fb0(param_1, param_2, 0xe);
    if (uVar1 < 0xe) {
      local_10 = 0;
    }
    else {
      iVar2 = sceKernelMmap((void *)0x0,0xe,7,0x1002,-1,0,(void **)(param_1 + 0x20));
      if ((iVar2 < 0) || (*(long *)(param_1 + 0x20) == 0)) {
        local_10 = 0;
      }
      else {
        FUN_00079050(param_1, *(undefined8 *)(param_1 + 0x20), param_3);
        *(void **)(param_1 + 0x18) = param_2;
        *(long *)(param_1 + 0x28) = param_3;
        sceKernelMprotect(param_2,(ulong)uVar1,7);
        *(ulong *)(param_1 + 0x10) = (ulong)uVar1 + 0xe;
        iVar2 = sceKernelMmap((void *)0x0,*(ulong *)(param_1 + 0x10),7,0x1002,-1,0,
                              (void **)(param_1 + 8));
        if ((iVar2 < 0) || (*(long *)(param_1 + 8) == 0)) {
          local_10 = 0;
        }
        else {
          memcpy(*(void **)(param_1 + 8),param_2,(ulong)uVar1);
          FUN_00079050(param_1, *(long *)(param_1 + 8) + (ulong)uVar1, (long)param_2 + (ulong)uVar1);
          memset(param_2,0x90,(ulong)uVar1);
          FUN_00079050(param_1, param_2, *(undefined8 *)(param_1 + 0x20));
          local_10 = *(undefined8 *)(param_1 + 8);
        }
      }
    }
  }
  return local_10;
}

// FUN_000795b0 @ 0x795b0  (export NID zQCkkfKiJKw)
undefined8 FUN_000795b0(int *param_1)

{
  long lVar1;
  void *local_38;
  ulong local_20;
  void *local_18;
  
  local_18 = (void *)0x0;
  local_20 = 0;
  if (*(long *)(param_1 + 2) != 0) {
    if (*param_1 == 0) {
      lVar1 = FUN_00079110(param_1, *(undefined8 *)(param_1 + 6));
      if (lVar1 == *(long *)(param_1 + 8)) {
        local_38 = *(void **)(param_1 + 6);
      }
      else {
        local_38 = *(void **)(param_1 + 8);
      }
      local_18 = local_38;
      local_20 = *(long *)(param_1 + 4) - 0xe;
    }
    else if (*param_1 == 1) {
      local_18 = *(void **)(param_1 + 6);
      local_20 = *(long *)(param_1 + 4) - 5;
    }
    if ((local_18 != (void *)0x0) && (local_20 != 0)) {
      sceKernelMprotect(local_18,local_20,7);
      memcpy(local_18,*(void **)(param_1 + 2),local_20);
    }
  }
  return 0;
}

// FUN_000796e0 @ 0x796e0  (export NID 3MHMEiZqAgY)
undefined8 FUN_000796e0(undefined4 *param_1,undefined4 param_2)

{
  *(undefined8 *)(param_1 + 2) = 0;
  *(undefined8 *)(param_1 + 4) = 0;
  *(undefined8 *)(param_1 + 6) = 0;
  *(undefined8 *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 10) = 0;
  *(undefined4 *)((long)param_1 + 0x3e) = 0xe9;
  *(undefined1 *)((long)param_1 + 0x42) = 0;
  *(undefined8 *)(param_1 + 0xc) = 0x90900000000025ff;
  param_1[0xe] = 0x90909090;
  *(undefined2 *)(param_1 + 0xf) = 0x9090;
  *param_1 = param_2;
  return 0;
}

// FUN_00079790 @ 0x79790  (export NID hiWlLRFv4vY)
undefined8 FUN_00079790(long param_1)

{
  FUN_000795b0(param_1);
  sceKernelMunmap(*(void **)(param_1 + 8),*(ulong *)(param_1 + 0x10));
  return 0;
}

// FUN_000797c0 @ 0x797c0  (export NID OxgYRA+BVJo)
undefined8 FUN_000797c0(void)

{
  FUN_000797e0(0, 0);
  return 0;
}

// FUN_000797e0 @ 0x797e0  (export NID yxbLcb2i5UQ)
undefined8 FUN_000797e0(undefined8 param_1,undefined8 param_2)

{
  FUN_0007a850(500, param_1, param_2);
  return 0;
}

// FUN_00079810 @ 0x79810  (export NID xaitJOEeT9g)
undefined8 FUN_00079810(undefined8 param_1)

{
  FUN_000797e0(2, param_1);
  return 0;
}

// FUN_00079830 @ 0x79830  (export NID hiIshXvJxMM)
undefined4 FUN_00079830(long param_1)

{
  undefined4 local_c;
  
  if (param_1 == 0) {
    local_c = 0xffffffff;
  }
  else {
    local_c = FUN_000797e0(3, param_1);
  }
  return local_c;
}

// FUN_00079870 @ 0x79870  (export NID 7h+Qs2Xtdi4)
undefined8 FUN_00079870(undefined8 param_1)

{
  FUN_000797e0(4, param_1);
  return 0;
}

// FUN_00079890 @ 0x79890  (export NID wcP2oDbMG3s)
undefined8 FUN_00079890(undefined8 param_1)

{
  FUN_000797e0(5, param_1);
  return 0;
}

// FUN_000798b0 @ 0x798b0  (export NID Zn-JvGNXVlo)
undefined8 FUN_000798b0(char *param_1,char *param_2)

{
  char local_a4 [32];
  char acStack_84 [100];
  undefined8 local_20;
  char *local_18;
  char *local_10;
  
  local_18 = param_2;
  local_10 = param_1;
  memset(local_a4,0,0x8c);
  strncpy(local_a4,local_10,0x20);
  strncpy(acStack_84,local_18,100);
  FUN_000797e0(6, local_a4);
  return local_20;
}

// FUN_00079930 @ 0x79930  (export NID 2ulG4K1TKks)
undefined8 FUN_00079930(char *param_1,int param_2)

{
  char local_44 [32];
  long local_24;
  undefined8 local_1c;
  int local_14;
  char *local_10;
  
  local_14 = param_2;
  local_10 = param_1;
  memset(local_44,0,0x30);
  strncpy(local_44,local_10,0x20);
  local_24 = (long)local_14;
  FUN_000797e0(7, local_44);
  return local_1c;
}

// FUN_00079990 @ 0x79990  (export NID PxIIH88SjJg)
byte FUN_00079990(byte *param_1,byte *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  byte *pbVar6;
  byte *local_60;
  byte local_51;
  byte *local_50;
  byte local_41;
  char local_3d;
  byte local_3c;
  byte local_39;
  byte *local_38;
  byte local_2b;
  byte local_2a;
  byte local_29;
  byte *local_28;
  byte local_1a;
  byte local_19;
  
  local_2b = 0;
  local_38 = g_KLeZa1rlqTk;
  local_3c = 0;
  local_3d = '\0';
  memset(param_2,0,0x25);
  local_28 = param_1;
  for (local_19 = '\x10'; local_19 != '\0'; local_19 = local_19 + -1) {
    pbVar6 = local_28 + 1;
    local_1a = *local_28;
    uVar5 = (uint)local_1a;
    local_28 = pbVar6;
    if ((((uVar5 == 0x26) || (uVar5 == 0x2e)) || (uVar5 == 0x36)) ||
       ((uVar5 == 0x3e || (uVar5 - 100 < 2)))) {
      param_2[3] = local_1a;
      local_2b = local_2b | 0x40;
    }
    else if (uVar5 == 0x66) {
      param_2[4] = local_1a;
      local_2b = local_2b | 8;
    }
    else if (uVar5 == 0x67) {
      param_2[5] = local_1a;
      local_2b = local_2b | 0x10;
    }
    else if (uVar5 == 0xf0) {
      param_2[2] = local_1a;
      local_2b = local_2b | 0x20;
    }
    else if (uVar5 == 0xf2) {
      param_2[1] = local_1a;
      local_2b = local_2b | 2;
    }
    else {
      if (uVar5 != 0xf3) break;
      param_2[1] = local_1a;
      local_2b = local_2b | 4;
    }
  }
  *(uint *)(param_2 + 0x21) = (uint)local_2b << 0x17;
  if (local_2b == 0) {
    local_2b = 1;
  }
  if ((local_1a & 0xf0) == 0x40) {
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x40000000;
    iVar4 = (int)(local_1a & 0xf) >> 3;
    param_2[7] = (byte)iVar4;
    if ((iVar4 != 0) && ((*local_28 & 0xf8) == 0xb8)) {
      local_3d = '\x01';
    }
    param_2[8] = (byte)((int)(local_1a & 7) >> 2);
    param_2[9] = (byte)((int)(local_1a & 3) >> 1);
    param_2[10] = local_1a & 1;
    pbVar6 = local_28 + 1;
    local_2a = *local_28;
    local_28 = pbVar6;
    local_1a = local_2a;
    if ((local_2a & 0xf0) != 0x40) goto LAB_00079c45;
LAB_00079d3e:
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x3000;
    local_29 = (local_2a & 0xfd) == 0x24;
  }
  else {
LAB_00079c45:
    param_2[0xb] = local_1a;
    if (local_1a == 0xf) {
      local_1a = *local_28;
      param_2[0xc] = local_1a;
      local_38 = DAT_0017f26a;
      local_28 = local_28 + 1;
    }
    else if ((0x9f < local_1a) && (local_1a < 0xa4)) {
      local_3d = local_3d + '\x01';
      if ((local_2b & 0x10) == 0) {
        local_2b = local_2b & 0xf7;
      }
      else {
        local_2b = local_2b | 8;
      }
    }
    local_2a = local_1a;
    local_29 = local_38[(int)((uint)local_38[(int)(local_1a / 4)] + (uint)local_1a % 4)];
    if (local_29 == 0xff) goto LAB_00079d3e;
  }
  local_19 = 0;
  if ((local_29 & 0x80) != 0) {
    uVar5 = (uint)local_29;
    local_29 = (byte)*(undefined2 *)(local_38 + (int)(uVar5 & 0x7f));
    local_19 = (byte)((ushort)*(undefined2 *)(local_38 + (int)(uVar5 & 0x7f)) >> 8);
  }
  if ((param_2[0xc] != 0) &&
     ((s_____AI____LB________ODS___DWC____0017f35c
       [(int)((uint)(byte)s_____AI____LB________ODS___DWC____0017f35c[(int)(local_2a / 4)] +
             (uint)local_2a % 4)] & local_2b) != 0)) {
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x3000;
  }
  if ((local_29 & 1) == 0) {
    if ((local_2b & 0x20) != 0) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x9000;
    }
  }
  else {
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 1;
    bVar3 = *local_28;
    param_2[0xd] = bVar3;
    local_39 = (byte)((int)(uint)bVar3 >> 6);
    param_2[0xe] = local_39;
    bVar2 = bVar3 & 7;
    param_2[0x10] = bVar2;
    bVar3 = (byte)((int)(bVar3 & 0x3f) >> 3);
    param_2[0xf] = bVar3;
    if ((local_19 != 0) && (((uint)local_19 << bVar3 & 0x80) != 0)) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x3000;
    }
    if (((param_2[0xc] == 0) && (0xd8 < local_2a)) && (local_2a < 0xe0)) {
      if (local_39 == 3) {
        local_41 = *(char *)((long)(int)((uint)(byte)(local_2a + 0x27) << 3) + 0x17f324 +
                            (ulong)bVar3) << bVar2;
      }
      else {
        local_41 = (DAT_0017f31d)[(byte)(local_2a + 0x27)] << bVar3;
      }
      if ((local_41 & 0x80) != 0) {
        *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x3000;
      }
    }
    if ((local_2b & 0x20) != 0) {
      if (local_39 == 3) {
        *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x9000;
      }
      else {
        local_51 = local_2a;
        if (param_2[0xc] == 0) {
          local_38 = DAT_0017f3ce;
          local_50 = DAT_0017f3e6;
          local_51 = local_2a & 0xfe;
        }
        else {
          local_38 = DAT_0017f3e6;
          local_50 = DAT_0017f3f8;
        }
        for (; local_38 != local_50; local_38 = local_38 + 2) {
          if (*local_38 == local_51) {
            if (((uint)local_38[1] << bVar3 & 0x80) == 0) goto LAB_0007a0c9;
            break;
          }
        }
        *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x9000;
      }
    }
LAB_0007a0c9:
    if (param_2[0xc] == 0) {
      if (local_2a != 0x8c) {
        if (local_2a != 0x8e) goto LAB_0007a1cc;
        if (bVar3 == 1) goto LAB_0007a389;
      }
      if (5 < bVar3) goto LAB_0007a389;
    }
    else {
      switch(local_2a) {
      case 0x20:
      case 0x22:
        local_39 = 3;
        if ((4 < bVar3) || (bVar3 == 1)) {
LAB_0007a389:
          *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x11000;
        }
        break;
      case 0x21:
      case 0x23:
        local_39 = 3;
        if ((bVar3 == 4) || (bVar3 == 5)) goto LAB_0007a389;
        break;
      default:
LAB_0007a1cc:
        if (local_39 == 3) {
          if (param_2[0xc] == 0) {
            local_38 = DAT_0017f3f8;
            local_60 = DAT_0017f407;
          }
          else {
            local_38 = DAT_0017f407;
            local_60 = DAT_0017f431;
          }
          for (; local_38 != local_60; local_38 = local_38 + 3) {
            if (*local_38 == local_2a) {
              if (((local_38[1] & local_2b) != 0) && (((uint)local_38[2] << bVar3 & 0x80) == 0))
              goto LAB_0007a389;
              break;
            }
          }
        }
        else if (param_2[0xc] != 0) {
          if (local_2a == 0x50) {
LAB_0007a346:
            bVar1 = local_2b & 9;
          }
          else {
            if (local_2a == 0xc5) goto LAB_0007a389;
            if (local_2a != 0xd6) {
              if ((local_2a != 0xd7) && (local_2a != 0xf7)) break;
              goto LAB_0007a346;
            }
            bVar1 = local_2b & 6;
          }
          if (bVar1 != 0) goto LAB_0007a389;
        }
      }
    }
    bVar1 = local_28[1];
    if (bVar3 < 2) {
      if (local_2a == 0xf6) {
        local_29 = local_29 | 2;
      }
      else if (local_2a == 0xf7) {
        local_29 = local_29 | 0x10;
      }
    }
    if (local_39 == 0) {
      if ((local_2b & 0x10) == 0) {
        if (bVar2 == 5) {
          local_3c = 4;
        }
      }
      else if (bVar2 == 6) {
        local_3c = 2;
      }
    }
    else if (local_39 == 1) {
      local_3c = 1;
    }
    else if ((local_39 == 2) && (local_3c = 2, (local_2b & 0x10) == 0)) {
      local_3c = 4;
    }
    pbVar6 = local_28 + 2;
    if ((local_39 != 3) && (bVar2 == 4)) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 2;
      pbVar6 = local_28 + 3;
      param_2[0x11] = bVar1;
      param_2[0x12] = (byte)((int)(uint)bVar1 >> 6);
      param_2[0x13] = (byte)((int)(bVar1 & 0x3f) >> 3);
      param_2[0x14] = bVar1 & 7;
      if (((bVar1 & 7) == 5) && ((local_39 & 1) == 0)) {
        local_3c = 4;
      }
    }
    local_28 = pbVar6;
    local_28 = local_28 + -1;
    if (local_3c == 1) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x40;
      param_2[0x1d] = *local_28;
    }
    else if (local_3c == 2) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x80;
      *(undefined2 *)(param_2 + 0x1d) = *(undefined2 *)local_28;
    }
    else if (local_3c == 4) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x100;
      *(undefined4 *)(param_2 + 0x1d) = *(undefined4 *)local_28;
    }
    local_28 = local_28 + (int)(uint)local_3c;
  }
  if ((local_29 & 0x10) == 0) goto LAB_0007a706;
  if ((local_29 & 0x40) == 0) {
    if (local_3d == '\0') {
      if ((local_2b & 8) == 0) {
        *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x10;
        *(undefined4 *)(param_2 + 0x15) = *(undefined4 *)local_28;
        local_28 = local_28 + 4;
        goto LAB_0007a706;
      }
LAB_0007a71b:
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 8;
      *(undefined2 *)(param_2 + 0x15) = *(undefined2 *)local_28;
      local_28 = local_28 + 2;
    }
    else {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x20;
      *(undefined8 *)(param_2 + 0x15) = *(undefined8 *)local_28;
      local_28 = local_28 + 8;
LAB_0007a706:
      if ((local_29 & 4) != 0) goto LAB_0007a71b;
    }
    if ((local_29 & 2) != 0) {
      *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 4;
      param_2[0x15] = *local_28;
      local_28 = local_28 + 1;
    }
    if ((local_29 & 0x40) == 0) {
      if ((local_29 & 0x20) != 0) {
        *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x204;
        param_2[0x15] = *local_28;
        local_28 = local_28 + 1;
      }
      goto LAB_0007a7fd;
    }
  }
  else if ((local_2b & 8) != 0) {
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x208;
    *(undefined2 *)(param_2 + 0x15) = *(undefined2 *)local_28;
    GHF8(local_28,0) = (char)local_28 + '\x02';
    goto LAB_0007a7fd;
  }
  *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x210;
  *(undefined4 *)(param_2 + 0x15) = *(undefined4 *)local_28;
  GHF8(local_28,0) = (char)local_28 + '\x04';
LAB_0007a7fd:
  bVar3 = (char)local_28 - (char)param_1;
  *param_2 = bVar3;
  if (0xf < bVar3) {
    *(uint *)(param_2 + 0x21) = *(uint *)(param_2 + 0x21) | 0x5000;
    *param_2 = 0xf;
  }
  return *param_2;
}

// FUN_0007a850 @ 0x7a850  (export NID kLOul-mCMU0)
undefined8 FUN_0007a850(undefined8 param_1,undefined8 param_2,ulong param_3)

{
  GH_VEC auVar1;
  int *piVar2;
  bool in_CF;
  GH_VEC auVar3;
  
  syscall(0);
  if (!in_CF) {
    memset((char *)&auVar1 + 8, 0, 8);
    GHF64(auVar1,0) = param_3;
    return auVar1.q[0];
  }
  piVar2 = __error();
  *piVar2 = 0;
  GHF64(auVar3,8) = 0xffffffffffffffff;
  GHF64(auVar3,0) = 0xffffffffffffffff;
  return auVar3.q[0];
}

// FUN_0007a880 @ 0x7a880  (export NID EZmVfH-6cvg)
undefined8 FUN_0007a880(undefined4 param_1,undefined8 param_2,undefined8 param_3)

{
  FUN_0007a850(0x24f, param_1, param_2);
  return 0;
}

// FUN_0007a8b0 @ 0x7a8b0  (export NID guFR7i2FiOw)
undefined8 FUN_0007a8b0(undefined8 param_1,undefined8 param_2)

{
  FUN_0007a850(0x252, param_1, 0);
  return 0;
}

// natives157.h - GTA V PS4 1.57 eboot native handler offsets (eboot_base + offset), from the binary's own table
#pragma once
#define N_ADD_ARMOUR_TO_PED__guess                         0xa90850ULL   /* interpolated name, verify */
#define N_ADD_PED_DECORATION_FROM_HASHES                   0xa995d0ULL
#define N_ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME         0x9e08f0ULL
#define N_ARE_ANY_VEHICLE_SEATS_FREE__guess                0xb23e40ULL   /* interpolated name, verify */
#define N_BEGIN_TEXT_COMMAND_DISPLAY_HELP                  0x9e0790ULL
#define N_BEGIN_TEXT_COMMAND_DISPLAY_TEXT                  0x9e0690ULL
#define N_BEGIN_TEXT_COMMAND_PRINT                         0x9e0630ULL
#define N_BEGIN_TEXT_COMMAND_SET_BLIP_NAME                 0x9e0810ULL
#define N_CAN_CREATE_RANDOM_PED__guess                     0xa90a90ULL   /* interpolated name, verify */
#define N_CAN_REGISTER_MISSION_OBJECTS__guess              0xa53730ULL   /* interpolated name, verify */
#define N_CAN_REGISTER_MISSION_PEDS__guess                 0xa537b0ULL   /* interpolated name, verify */
#define N_CLEAR_ALL_HELP_MESSAGES__guess                   0x9e0b40ULL   /* interpolated name, verify */
#define N_CLEAR_ENTITY_LAST_DAMAGE_ENTITY__guess           0x9b5100ULL   /* interpolated name, verify */
#define N_CLEAR_FOCUS                                      0xad9dd0ULL
#define N_CLEAR_HELP__guess                                0x9e1dd0ULL   /* interpolated name, verify */
#define N_CLEAR_OVERRIDE_WEATHER__guess                    0x9f5f80ULL   /* interpolated name, verify */
#define N_CLEAR_PED_BLOOD_DAMAGE                           0xa990e0ULL
#define N_CLEAR_PED_DECORATIONS__guess                     0xa997e0ULL   /* interpolated name, verify */
#define N_CLEAR_PED_PROP                                   0xa97520ULL
#define N_CLEAR_PED_TASKS                                  0xaf3c20ULL
#define N_CLEAR_PED_TASKS_IMMEDIATELY                      0xaf49d0ULL
#define N_CLEAR_PED_WETNESS                                0xa993c0ULL
#define N_CLEAR_PLAYER_PARACHUTE_MODEL_OVERRIDE__guess     0xaad930ULL   /* interpolated name, verify */
#define N_CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE__guess 0xaad870ULL   /* interpolated name, verify */
#define N_CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE__guess_2 0xaad8b0ULL
#define N_CLEAR_PLAYER_WANTED_LEVEL                        0xaa9b40ULL
#define N_CLEAR_VEHICLE_CUSTOM_PRIMARY_COLOUR__guess       0xb1cbf0ULL   /* interpolated name, verify */
#define N_CLEAR_VEHICLE_CUSTOM_SECONDARY_COLOUR__guess     0xb1cdf0ULL   /* interpolated name, verify */
#define N_CLEAR_WEATHER_TYPE_PERSIST__guess                0x9f5dc0ULL   /* interpolated name, verify */
#define N_CLONE_PED                                        0xa8fc50ULL
#define N_DECOR_EXIST_ON__guess                            0x9a0540ULL   /* interpolated name, verify */
#define N_DECOR_GET_INT__guess                             0x9a0480ULL   /* interpolated name, verify */
#define N_DECOR_SET_INT__guess                             0x9a0220ULL   /* interpolated name, verify */
#define N_DELETE_ENTITY                                    0x9b5160ULL
#define N_DELETE_OBJECT                                    0xa63b20ULL
#define N_DELETE_PED                                       0xa8fc40ULL
#define N_DELETE_VEHICLE                                   0xb1b000ULL
#define N_DESTROY_ALL_CAMS__guess                          0x9913c0ULL   /* interpolated name, verify */
#define N_DESTROY_MOBILE_PHONE__guess                      0xaaf050ULL   /* interpolated name, verify */
#define N_DETACH_ENTITY                                    0x9b5170ULL
#define N_DISABLE_CONTROL_ACTION                           0xa6b220ULL
#define N_DISABLE_INTERIOR__guess                          0x9e9110ULL   /* interpolated name, verify */
#define N_DISABLE_PLAYER_FIRING__guess                     0xaaba20ULL   /* interpolated name, verify */
#define N_DISPLAY_HUD__guess                               0x9e10a0ULL   /* interpolated name, verify */
#define N_DISPLAY_ONSCREEN_KEYBOARD                        0x9fa910ULL
#define N_DISPLAY_RADAR__guess                             0x9e1110ULL   /* interpolated name, verify */
#define N_DOES_BLIP_EXIST                                  0x9e30f0ULL
#define N_DOES_ENTITY_EXIST                                0x9b2290ULL
#define N_DOES_PICKUP_EXIST__guess                         0xa66120ULL   /* interpolated name, verify */
#define N_DOES_PICKUP_OBJECT_EXIST__guess                  0xa661a0ULL   /* interpolated name, verify */
#define N_DOES_TEXT_LABEL_EXIST__guess                     0x9e0e30ULL   /* interpolated name, verify */
#define N_DOES_WEAPON_TAKE_WEAPON_COMPONENT__guess         0xb3a530ULL   /* interpolated name, verify */
#define N_DO_SCREEN_FADE_OUT__guess                        0x994070ULL   /* interpolated name, verify */
#define N_DO_SCREEN_FADE_OUT__guess_2                      0x994080ULL
#define N_ENABLE_ALL_CONTROL_ACTIONS__guess                0xa6b390ULL   /* interpolated name, verify */
#define N_ENABLE_CONTROL_ACTION__guess                     0xa6b2b0ULL   /* interpolated name, verify */
#define N_END_TEXT_COMMAND_DISPLAY_HELP                    0x9e07a0ULL
#define N_END_TEXT_COMMAND_PRINT                           0x9e0640ULL
#define N_END_TEXT_COMMAND_SET_BLIP_NAME                   0x9e0820ULL
#define N_EXPLODE_VEHICLE__guess                           0xb1c3f0ULL   /* interpolated name, verify */
#define N_FREEZE_ENTITY_POSITION                           0x9b5190ULL
#define N_GET_AMMO_IN_CLIP__guess                          0xb396d0ULL   /* interpolated name, verify */
#define N_GET_AMMO_IN_PED_WEAPON                           0xb38e00ULL
#define N_GET_BEST_PED_WEAPON__guess                       0xb38a40ULL   /* interpolated name, verify */
#define N_GET_BLIP_COLOUR__guess                           0x9e28c0ULL   /* interpolated name, verify */
#define N_GET_BLIP_INFO_ID_DISPLAY__guess                  0x9e2080ULL   /* interpolated name, verify */
#define N_GET_BLIP_INFO_ID_TYPE__guess                     0x9e20c0ULL   /* interpolated name, verify */
#define N_GET_CLOCK_HOURS__guess                           0x996a40ULL   /* interpolated name, verify */
#define N_GET_CLOCK_HOURS__guess_2                         0x996a50ULL
#define N_GET_CONTROL_NORMAL                               0xa6a720ULL
#define N_GET_CURRENT_PED_WEAPON                           0xb389a0ULL
#define N_GET_DISABLED_CONTROL_NORMAL                      0xa6ab00ULL
#define N_GET_DISPLAY_NAME_FROM_VEHICLE_MODEL              0xb239b0ULL
#define N_GET_DLC_WEAPON_COMPONENT_DATA__guess             0x9a2e20ULL   /* interpolated name, verify */
#define N_GET_DLC_WEAPON_DATA__guess                       0x9a2d40ULL   /* interpolated name, verify */
#define N_GET_ENTITY_ALPHA                                 0x9b6b10ULL
#define N_GET_ENTITY_ATTACHED_TO__guess                    0x9b2b30ULL   /* interpolated name, verify */
#define N_GET_ENTITY_HEADING                               0x9b2df0ULL
#define N_GET_ENTITY_HEALTH                                0x9b3010ULL
#define N_GET_ENTITY_HEIGHT_ABOVE_GROUND                   0x9b3160ULL
#define N_GET_ENTITY_MAX_HEALTH                            0x9b3060ULL
#define N_GET_ENTITY_MODEL                                 0x9b3330ULL
#define N_GET_ENTITY_PLAYER_IS_FREE_AIMING_AT              0xaaa730ULL
#define N_GET_ENTITY_SPEED                                 0x9b3980ULL
#define N_GET_ENTITY_TYPE__guess                           0x9b3dd0ULL   /* interpolated name, verify */
#define N_GET_EVENT_AT_INDEX__guess                        0xab14b0ULL   /* interpolated name, verify */
#define N_GET_EVENT_DATA__guess                            0xab14f0ULL   /* interpolated name, verify */
#define N_GET_EVENT_DATA__guess_2                          0xab1540ULL
#define N_GET_FIRST_BLIP_INFO_ID                           0x9e1f80ULL
#define N_GET_FRAME_COUNT                                  0x9f6430ULL
#define N_GET_FRAME_TIME                                   0x9f63f0ULL
#define N_GET_GAMEPLAY_CAM_RELATIVE_HEADING__guess         0x994270ULL   /* interpolated name, verify */
#define N_GET_GAMEPLAY_CAM_RELATIVE_PITCH                  0x9942b0ULL
#define N_GET_GAME_TIMER                                   0x9f63e0ULL
#define N_GET_HASH_KEY                                     0x9f6de0ULL
#define N_GET_HASH_OF_THIS_SCRIPT_NAME__guess              0xab1410ULL   /* interpolated name, verify */
#define N_GET_HUD_COLOUR__guess                            0x9e15f0ULL   /* interpolated name, verify */
#define N_GET_INTERIOR_GROUP_ID__guess                     0x9e82d0ULL   /* interpolated name, verify */
#define N_GET_INTERIOR_GROUP_ID__guess_2                   0x9e83a0ULL
#define N_GET_INTERIOR_GROUP_ID__guess_3                   0x9e8450ULL
#define N_GET_IS_VEHICLE_ENGINE_RUNNING                    0xb28510ULL
#define N_GET_MAX_AMMO                                     0xb397e0ULL
#define N_GET_MAX_AMMO_IN_CLIP                             0xb39430ULL
#define N_GET_MOD_TEXT_LABEL__guess                        0xb27490ULL   /* interpolated name, verify */
#define N_GET_NEAREST_PLAYER_TO_ENTITY__guess              0x9b3d30ULL   /* interpolated name, verify */
#define N_GET_NEXT_BLIP_INFO_ID__guess                     0x9e1f60ULL   /* interpolated name, verify */
#define N_GET_NUMBER_OF_EVENTS__guess                      0xab1430ULL   /* interpolated name, verify */
#define N_GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS__guess     0xa95e20ULL   /* interpolated name, verify */
#define N_GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS       0xa95ef0ULL
#define N_GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS        0xa95f20ULL
#define N_GET_NUMBER_OF_PED_TEXTURE_VARIATIONS__guess      0xa95ec0ULL   /* interpolated name, verify */
#define N_GET_NUMBER_OF_VEHICLE_NUMBER_PLATES__guess       0xb1f2e0ULL   /* interpolated name, verify */
#define N_GET_NUM_DLC_WEAPONS__guess                       0x9a2cf0ULL   /* interpolated name, verify */
#define N_GET_NUM_VEHICLE_MODS__guess                      0xb27210ULL   /* interpolated name, verify */
#define N_GET_ONSCREEN_KEYBOARD_RESULT                     0x9fa990ULL
#define N_GET_PED_AMMO_BY_TYPE__guess                      0xb39a40ULL   /* interpolated name, verify */
#define N_GET_PED_AMMO_TYPE_FROM_WEAPON__guess             0xb39b20ULL   /* interpolated name, verify */
#define N_GET_PED_AMMO_TYPE_FROM_WEAPON__guess_2           0xb39b50ULL
#define N_GET_PED_DRAWABLE_VARIATION                       0xa95db0ULL
#define N_GET_PED_IN_VEHICLE_SEAT                          0xb1da00ULL
#define N_GET_PED_LAST_WEAPON_IMPACT_COORD                 0xb39c00ULL
#define N_GET_PED_NEARBY_PEDS                              0xa9d250ULL
#define N_GET_PED_NEARBY_VEHICLES__guess                   0xa9d220ULL   /* interpolated name, verify */
#define N_GET_PED_PARACHUTE_STATE                          0xa92310ULL
#define N_GET_PED_PROP_INDEX                               0xa973f0ULL
#define N_GET_PED_PROP_TEXTURE_INDEX                       0xa97660ULL
#define N_GET_PED_RELATIONSHIP_GROUP_HASH                  0xa93b10ULL
#define N_GET_PED_TEXTURE_VARIATION                        0xa95e50ULL
#define N_GET_PED_WEAPON_TINT_INDEX                        0xb3a600ULL
#define N_GET_PLAYERS_LAST_VEHICLE__guess                  0xaaae00ULL   /* interpolated name, verify */
#define N_GET_PLAYER_GROUP                                 0xaaabb0ULL
#define N_GET_PLAYER_INVINCIBLE__guess                     0xaab3a0ULL   /* interpolated name, verify */
#define N_GET_PLAYER_NAME                                  0xaa95b0ULL
#define N_GET_PLAYER_PED                                   0xaa9310ULL
#define N_GET_PLAYER_SWITCH_STATE__guess                   0xada5c0ULL   /* interpolated name, verify */
#define N_GET_PLAYER_TARGET_ENTITY__guess                  0xaaa5d0ULL   /* interpolated name, verify */
#define N_GET_PLAYER_WANTED_LEVEL                          0xaa9c80ULL
#define N_GET_POSIX_TIME__guess                            0x996ae0ULL   /* interpolated name, verify */
#define N_GET_PROFILE_SETTING__guess                       0x9f86e0ULL   /* interpolated name, verify */
#define N_GET_RANDOM_INT_IN_RANGE                          0x9f64a0ULL
#define N_GET_RELATIONSHIP_BETWEEN_PEDS__guess             0xa93a00ULL   /* interpolated name, verify */
#define N_GET_SHAPE_TEST_RESULT                            0xab34b0ULL
#define N_GET_STREET_NAME_FROM_HASH_KEY__guess             0x9e0f80ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_BODY_HEALTH                          0xb2b610ULL
#define N_GET_VEHICLE_COLOURS__guess                       0xb1d970ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_COLOUR_COMBINATION__guess            0xb21990ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_CUSTOM_PRIMARY_COLOUR__guess         0xb1cb70ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_CUSTOM_SECONDARY_COLOUR__guess       0xb1cd70ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_DIRT_LEVEL__guess                    0xb21200ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess       0xb1c120ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_ENGINE_HEALTH                        0xb23140ULL
#define N_GET_VEHICLE_EXTRA_COLOURS__guess                 0xb22220ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS__guess      0xb1bb90ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_MOD_VARIATION__guess                 0xb27140ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_MOD__guess                           0xb27060ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_NUMBER_PLATE_TEXT                    0xb1f280ULL
#define N_GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX__guess       0xb1f350ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_PED_IS_IN                            0xa90e80ULL
#define N_GET_VEHICLE_PETROL_TANK_HEALTH__guess            0xb23340ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_TYRES_CAN_BURST__guess               0xb1e460ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_TYRE_SMOKE_COLOR__guess              0xb27870ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_WHEEL_TYPE__guess                    0xb26970ULL   /* interpolated name, verify */
#define N_GET_VEHICLE_WINDOW_TINT__guess                   0xb27930ULL   /* interpolated name, verify */
#define N_GET_WEAPONTYPE_GROUP__guess                      0xb387a0ULL   /* interpolated name, verify */
#define N_GET_WEAPONTYPE_MODEL__guess                      0xb38660ULL   /* interpolated name, verify */
#define N_GET_WEAPON_HUD_STATS__guess                      0xb3a750ULL   /* interpolated name, verify */
#define N_GET_WEAPON_TINT_COUNT                            0xb3a6e0ULL
#define N_GET_ZONE_FROM_NAME_ID__guess                     0xb3c590ULL   /* interpolated name, verify */
#define N_GIVE_WEAPON_COMPONENT_TO_PED__guess              0xb39f30ULL   /* interpolated name, verify */
#define N_GIVE_WEAPON_TO_PED                               0xb38fd0ULL
#define N_HAS_ANIM_DICT_LOADED                             0xad97e0ULL
#define N_HAS_CLIP_SET_LOADED__guess                       0xad9a20ULL   /* interpolated name, verify */
#define N_HAS_ENTITY_BEEN_DAMAGED_BY_ANY_PED__guess        0x9b25b0ULL   /* interpolated name, verify */
#define N_HAS_ENTITY_BEEN_DAMAGED_BY_ANY_VEHICLE__guess    0x9b2610ULL   /* interpolated name, verify */
#define N_HAS_ENTITY_CLEAR_LOS_TO_ENTITY__guess            0x9b26a0ULL   /* interpolated name, verify */
#define N_HAS_MODEL_LOADED                                 0xad92c0ULL
#define N_HAS_NAMED_PTFX_ASSET_LOADED                      0xad9d50ULL
#define N_HAS_PED_BEEN_DAMAGED_BY_WEAPON__guess            0xb39250ULL   /* interpolated name, verify */
#define N_HAS_PED_GOT_WEAPON                               0xb38cb0ULL
#define N_HAS_PED_GOT_WEAPON_COMPONENT__guess              0xb3a010ULL   /* interpolated name, verify */
#define N_HAS_PLAYER_LEFT_THE_WORLD__guess                 0xaad7f0ULL   /* interpolated name, verify */
#define N_HAS_PLAYER_LEFT_THE_WORLD__guess_2               0xaad830ULL
#define N_HAS_SCRIPT_LOADED                                0xab0f20ULL
#define N_HAS_THIS_CUTSCENE_LOADED__guess                  0x9993f0ULL   /* interpolated name, verify */
#define N_HAS_VEHICLE_ASSET_LOADED__guess                  0xb24980ULL   /* interpolated name, verify */
#define N_HAS_WEAPON_ASSET_LOADED                          0xb3a240ULL
#define N_HIDE_PED_WEAPON_FOR_SCRIPTED_CUTSCENE__guess     0xb39120ULL   /* interpolated name, verify */
#define N_IS_BLIP_SHORT_RANGE__guess                       0x9e29e0ULL   /* interpolated name, verify */
#define N_IS_CONTROL_JUST_PRESSED                          0xa6a530ULL
#define N_IS_CONTROL_PRESSED                               0xa6a450ULL
#define N_IS_DISABLED_CONTROL_JUST_PRESSED                 0xa6a9c0ULL
#define N_IS_DISABLED_CONTROL_PRESSED                      0xa6a880ULL
#define N_IS_ENTITY_AN_OBJECT                              0x9b4010ULL
#define N_IS_ENTITY_ATTACHED                               0x9b4110ULL
#define N_IS_ENTITY_ATTACHED_TO_ANY_OBJECT__guess          0x9b41a0ULL   /* interpolated name, verify */
#define N_IS_ENTITY_ATTACHED_TO_ANY_PED__guess             0x9b4230ULL   /* interpolated name, verify */
#define N_IS_ENTITY_ATTACHED_TO_ENTITY                     0x9b4350ULL
#define N_IS_ENTITY_A_MISSION_ENTITY__guess                0x9b3f50ULL   /* interpolated name, verify */
#define N_IS_ENTITY_A_PED__guess                           0x9b3ef0ULL   /* interpolated name, verify */
#define N_IS_ENTITY_A_VEHICLE                              0x9b3fb0ULL
#define N_IS_ENTITY_DEAD                                   0x9b4380ULL
#define N_IS_ENTITY_IN_AIR                                 0x9b4440ULL
#define N_IS_ENTITY_TOUCHING_ENTITY__guess                 0x9b4830ULL   /* interpolated name, verify */
#define N_IS_ENTITY_TOUCHING_MODEL__guess                  0x9b4860ULL   /* interpolated name, verify */
#define N_IS_ENTITY_VISIBLE                                0x9b4980ULL
#define N_IS_INTERIOR_SCENE__guess                         0x9e82c0ULL   /* interpolated name, verify */
#define N_IS_IPL_ACTIVE__guess                             0xad9bc0ULL   /* interpolated name, verify */
#define N_IS_MODEL_A_VEHICLE                               0xad95d0ULL
#define N_IS_MODEL_IN_CDIMAGE                              0xad9480ULL
#define N_IS_MODEL_VALID                                   0xad94f0ULL
#define N_IS_PED_ARMED__guess                              0xb38c10ULL   /* interpolated name, verify */
#define N_IS_PED_A_PLAYER                                  0xa902c0ULL
#define N_IS_PED_DEAD_OR_DYING__guess                      0xa90140ULL   /* interpolated name, verify */
#define N_IS_PED_GETTING_INTO_A_VEHICLE__guess             0xa951f0ULL   /* interpolated name, verify */
#define N_IS_PED_GROUP_MEMBER__guess                       0xa92ea0ULL   /* interpolated name, verify */
#define N_IS_PED_IN_ANY_VEHICLE                            0xa8ff40ULL
#define N_IS_PED_IN_PARACHUTE_FREE_FALL__guess             0xa91ed0ULL   /* interpolated name, verify */
#define N_IS_PED_IN_VEHICLE__guess                         0xa8fe30ULL   /* interpolated name, verify */
#define N_IS_PED_SHOOTING                                  0xa905e0ULL
#define N_IS_PED_SITTING_IN_VEHICLE__guess                 0xa913c0ULL   /* interpolated name, verify */
#define N_IS_PLAYER_DEAD__guess                            0xaa9be0ULL   /* interpolated name, verify */
#define N_IS_PLAYER_FREE_AIMING                            0xaaa630ULL
#define N_IS_PLAYER_RIDING_TRAIN__guess                    0xaad740ULL   /* interpolated name, verify */
#define N_IS_SCREEN_FADING_IN__guess                       0x993ff0ULL   /* interpolated name, verify */
#define N_IS_SCREEN_FADING_IN__guess_2                     0x994010ULL
#define N_IS_SCREEN_FADING_IN__guess_3                     0x994030ULL
#define N_IS_SCREEN_FADING_IN__guess_4                     0x994050ULL
#define N_IS_SPECIAL_ABILITY_ENABLED__guess                0xaac2b0ULL   /* interpolated name, verify */
#define N_IS_STRING_NULL_OR_EMPTY__guess                   0x9f9220ULL   /* interpolated name, verify */
#define N_IS_THIS_MODEL_A_BOAT__guess                      0xb20680ULL   /* interpolated name, verify */
#define N_IS_THIS_MODEL_A_HELI__guess                      0xb20880ULL   /* interpolated name, verify */
#define N_IS_TOGGLE_MOD_ON__guess                          0xb27410ULL   /* interpolated name, verify */
#define N_IS_VEHICLE_DRIVEABLE__guess                      0xb234d0ULL   /* interpolated name, verify */
#define N_IS_VEHICLE_EXTRA_TURNED_ON__guess                0xb22bf0ULL   /* interpolated name, verify */
#define N_IS_VEHICLE_ON_ALL_WHEELS                         0xb22000ULL
#define N_IS_VEHICLE_SEAT_FREE                             0xb1d9d0ULL
#define N_IS_VEHICLE_TYRE_BURST__guess                     0xb1db40ULL   /* interpolated name, verify */
#define N_IS_WAYPOINT_ACTIVE__guess                        0x9e3160ULL   /* interpolated name, verify */
#define N_IS_WEAPON_VALID                                  0xb38c40ULL
#define N_NETWORK_ACCESS_TUNABLE_BOOL__guess               0xa56010ULL   /* interpolated name, verify */
#define N_NETWORK_BUY_HEALTHCARE__guess                    0xa1fdf0ULL   /* interpolated name, verify */
#define N_NETWORK_CLEAR_CLOCK_TIME_OVERRIDE__guess         0xa55a50ULL   /* interpolated name, verify */
#define N_NETWORK_DISABLE_INVINCIBLE_FLASHING__guess       0xa4f190ULL   /* interpolated name, verify */
#define N_NETWORK_DOES_NETWORK_ID_EXIST__guess             0xa4f5c0ULL   /* interpolated name, verify */
#define N_NETWORK_DOES_TUNABLE_EXIST__guess                0xa55f40ULL   /* interpolated name, verify */
#define N_NETWORK_EARN_FROM_IMPORT_EXPORT__guess           0xa1dcf0ULL   /* interpolated name, verify */
#define N_NETWORK_FADE_OUT_ENTITY__guess                   0xa53090ULL   /* interpolated name, verify */
#define N_NETWORK_GET_ENTITY_FROM_NETWORK_ID__guess        0xa4f2e0ULL   /* interpolated name, verify */
#define N_NETWORK_GET_ENTITY_IS_NETWORKED                  0xa4f380ULL
#define N_NETWORK_GET_HOST_OF_SCRIPT__guess                0xa4e8b0ULL   /* interpolated name, verify */
#define N_NETWORK_GET_HOST_PLAYER_INDEX                    0xa49ff0ULL
#define N_NETWORK_GET_NUM_CONNECTED_PLAYERS__guess         0xa4e6f0ULL   /* interpolated name, verify */
#define N_NETWORK_GET_PLAYER_INDEX_FROM_PED__guess         0xa4e660ULL   /* interpolated name, verify */
#define N_NETWORK_GET_PRIMARY_CLAN_DATA_START__guess       0xa52960ULL   /* interpolated name, verify */
#define N_NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2     0xa52980ULL
#define N_NETWORK_GET_VC_BANK_BALANCE                      0xa26fc0ULL
#define N_NETWORK_GET_VC_WALLET_BALANCE                    0xa26ff0ULL
#define N_NETWORK_HANDLE_FROM_USER_ID__guess               0xa4fcb0ULL   /* interpolated name, verify */
#define N_NETWORK_HAS_CONTROL_OF_ENTITY                    0xa4f820ULL
#define N_NETWORK_HAS_CONTROL_OF_NETWORK_ID__guess         0xa4f6b0ULL   /* interpolated name, verify */
#define N_NETWORK_IS_ACTIVITY_SESSION__guess               0xa4cc70ULL   /* interpolated name, verify */
#define N_NETWORK_IS_GAME_IN_PROGRESS                      0xa4b650ULL
#define N_NETWORK_IS_HOST                                  0xa49fd0ULL
#define N_NETWORK_IS_IN_SESSION__guess                     0xa4b680ULL   /* interpolated name, verify */
#define N_NETWORK_IS_IN_SPECTATOR_MODE__guess              0xa54650ULL   /* interpolated name, verify */
#define N_NETWORK_IS_PLAYER_ACTIVE                         0xa4e7d0ULL
#define N_NETWORK_IS_PLAYER_IN_MP_CUTSCENE__guess          0xa54660ULL   /* interpolated name, verify */
#define N_NETWORK_IS_SESSION_ACTIVE                        0xa4b660ULL
#define N_NETWORK_IS_SESSION_BUSY                          0xa4b6d0ULL
#define N_NETWORK_IS_SESSION_STARTED                       0xa4b6b0ULL
#define N_NETWORK_IS_TRANSITION_HOST__guess                0xa4c750ULL   /* interpolated name, verify */
#define N_NETWORK_OVERRIDE_CLOCK_TIME                      0xa55a20ULL
#define N_NETWORK_PLAYER_HAS_HEADSET                       0xa51860ULL
#define N_NETWORK_PLAYER_ID_TO_INT__guess                  0xaab040ULL   /* interpolated name, verify */
#define N_NETWORK_PLAYER_IS_BADSPORT__guess                0xa4e0a0ULL   /* interpolated name, verify */
#define N_NETWORK_REGISTER_ENTITY_AS_NETWORKED__guess      0xa4f450ULL   /* interpolated name, verify */
#define N_NETWORK_REQUEST_CONTROL_OF_ENTITY                0xa4f780ULL
#define N_NETWORK_REQUEST_CONTROL_OF_NETWORK_ID__guess     0xa4f640ULL   /* interpolated name, verify */
#define N_NETWORK_SET_ENTITY_CAN_BLEND__guess              0xa52ab0ULL   /* interpolated name, verify */
#define N_NETWORK_SET_SCRIPT_IS_SAFE_FOR_NETWORK_GAME__guess 0x9f7850ULL   /* interpolated name, verify */
#define N_NET_GAMESERVER_TRANSACTION_IN_PROGRESS           0xa28460ULL
#define N_NET_TO_ENT__guess                                0xa4fd20ULL   /* interpolated name, verify */
#define N_OBJ_TO_NET__guess                                0xa4fa70ULL   /* interpolated name, verify */
#define N_PARTICIPANT_ID__guess                            0xa4edc0ULL   /* interpolated name, verify */
#define N_PAUSE_CLOCK__guess                               0x9969e0ULL   /* interpolated name, verify */
#define N_PED_TO_NET__guess                                0xa4fa10ULL   /* interpolated name, verify */
#define N_PLACE_OBJECT_ON_GROUND_PROPERLY__guess           0xa63b30ULL   /* interpolated name, verify */
#define N_PLAYER_ID                                        0xaaafc0ULL
#define N_PLAYER_PED_ID                                    0xaab000ULL
#define N_PLAY_SOUND_FRONTEND                              0x983430ULL
#define N_REFRESH_INTERIOR__guess                          0x9e8f50ULL   /* interpolated name, verify */
#define N_REFRESH_INTERIOR__guess_2                        0x9e90c0ULL
#define N_REGISTER_TARGET__guess                           0xa978d0ULL   /* interpolated name, verify */
#define N_REMOVE_ALL_PED_WEAPONS                           0xb39020ULL
#define N_REMOVE_BLIP__guess                               0x9e2e50ULL   /* interpolated name, verify */
#define N_REMOVE_CUTSCENE__guess                           0x9990b0ULL   /* interpolated name, verify */
#define N_REMOVE_DECALS_FROM_VEHICLE__guess                0x9cfe80ULL   /* interpolated name, verify */
#define N_REMOVE_PED_FROM_GROUP                            0xa92e90ULL
#define N_REMOVE_PICKUP__guess                             0xa660f0ULL   /* interpolated name, verify */
#define N_REMOVE_SCRIPT_FIRE__guess                        0x9bb0c0ULL   /* interpolated name, verify */
#define N_REMOVE_VEHICLE_MOD__guess                        0xb272b0ULL   /* interpolated name, verify */
#define N_REMOVE_WEAPON_COMPONENT_FROM_PED__guess          0xb39fa0ULL   /* interpolated name, verify */
#define N_REMOVE_WEAPON_FROM_PED                           0xb390a0ULL
#define N_RENDER_SCRIPT_CAMS                               0x990e50ULL
#define N_REQUEST_ANIM_DICT                                0xad97d0ULL
#define N_REQUEST_CLIP_SET__guess                          0xad9a10ULL   /* interpolated name, verify */
#define N_REQUEST_IPL                                      0xad9b40ULL
#define N_REQUEST_MODEL                                    0xad9290ULL
#define N_REQUEST_NAMED_PTFX_ASSET                         0xad9d40ULL
#define N_REQUEST_SCRIPT                                   0xab0e40ULL
#define N_REQUEST_VEHICLE_HIGH_DETAIL_MODEL__guess         0xb24770ULL   /* interpolated name, verify */
#define N_REQUEST_WEAPON_ASSET                             0xb3a180ULL
#define N_RESERVE_NETWORK_MISSION_OBJECTS__guess           0xa53650ULL   /* interpolated name, verify */
#define N_RESERVE_NETWORK_MISSION_OBJECTS__guess_2         0xa53660ULL
#define N_RESERVE_NETWORK_MISSION_OBJECTS__guess_3         0xa53670ULL
#define N_RESERVE_NETWORK_MISSION_OBJECTS__guess_4         0xa536b0ULL
#define N_RESET_ENTITY_ALPHA__guess                        0x9b6b70ULL   /* interpolated name, verify */
#define N_RESET_HUD_COMPONENT_VALUES__guess                0x9e4150ULL   /* interpolated name, verify */
#define N_RESET_PED_VISIBLE_DAMAGE                         0xa98ab0ULL
#define N_SET_AGGRESSIVE_HORNS__guess                      0x985600ULL   /* interpolated name, verify */
#define N_SET_AMBIENT_ZONE_LIST_STATE_PERSISTENT__guess    0x985350ULL   /* interpolated name, verify */
#define N_SET_AMMO_IN_CLIP                                 0xb397b0ULL
#define N_SET_AUDIO_FLAG__guess                            0x987300ULL   /* interpolated name, verify */
#define N_SET_BLIP_AS_SHORT_RANGE__guess                   0x9e2d40ULL   /* interpolated name, verify */
#define N_SET_BLIP_CATEGORY__guess                         0x9e2df0ULL   /* interpolated name, verify */
#define N_SET_BLIP_CATEGORY__guess_2                       0x9e2e10ULL
#define N_SET_BLIP_COLOUR                                  0x9e2820ULL
#define N_SET_BLIP_SPRITE                                  0x9e2560ULL
#define N_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS             0xa97810ULL
#define N_SET_CLOCK_TIME                                   0x9969b0ULL
#define N_SET_CREATE_RANDOM_COPS__guess                    0xa95020ULL   /* interpolated name, verify */
#define N_SET_CURRENT_PED_WEAPON                           0xb38980ULL
#define N_SET_DISABLE_AMBIENT_MELEE_MOVE__guess            0xaabad0ULL   /* interpolated name, verify */
#define N_SET_DISABLE_VEHICLE_PETROL_TANK_FIRES__guess     0xb22790ULL   /* interpolated name, verify */
#define N_SET_DISPATCH_COPS_FOR_PLAYER__guess              0xaa9a80ULL   /* interpolated name, verify */
#define N_SET_ENTITY_ALPHA                                 0x9b6ab0ULL
#define N_SET_ENTITY_AS_MISSION_ENTITY                     0x9b5600ULL
#define N_SET_ENTITY_CAN_BE_DAMAGED__guess                 0x9b57a0ULL   /* interpolated name, verify */
#define N_SET_ENTITY_COLLISION                             0x9b5ae0ULL
#define N_SET_ENTITY_DYNAMIC__guess                        0x9b5c70ULL   /* interpolated name, verify */
#define N_SET_ENTITY_HAS_GRAVITY__guess                    0x9b68e0ULL   /* interpolated name, verify */
#define N_SET_ENTITY_HEALTH                                0x9b5d00ULL
#define N_SET_ENTITY_INVINCIBLE                            0x9b5d20ULL
#define N_SET_ENTITY_IS_TARGET_PRIORITY__guess             0x9b5f90ULL   /* interpolated name, verify */
#define N_SET_ENTITY_LOCALLY_INVISIBLE__guess              0xa532e0ULL   /* interpolated name, verify */
#define N_SET_ENTITY_LOCALLY_VISIBLE__guess                0xa53340ULL   /* interpolated name, verify */
#define N_SET_ENTITY_LOD_DIST                              0x9b6a00ULL
#define N_SET_ENTITY_PROOFS                                0x9b6210ULL
#define N_SET_ENTITY_QUATERNION__guess                     0x9b6350ULL   /* interpolated name, verify */
#define N_SET_ENTITY_VISIBLE                               0x9b66c0ULL
#define N_SET_ENTITY_VISIBLE_IN_CUTSCENE__guess            0xa53230ULL   /* interpolated name, verify */
#define N_SET_EXPLOSIVE_MELEE_THIS_FRAME                   0x9faae0ULL
#define N_SET_FRONTEND_ACTIVE__guess                       0x9e5270ULL   /* interpolated name, verify */
#define N_SET_GAME_PAUSES_FOR_STREAMING__guess             0xad9c40ULL   /* interpolated name, verify */
#define N_SET_GRAVITY_LEVEL                                0x9f9830ULL
#define N_SET_INPUT_EXCLUSIVE                              0xa6b1d0ULL
#define N_SET_INTERIOR_ACTIVE__guess                       0xad9260ULL   /* interpolated name, verify */
#define N_SET_MAX_WANTED_LEVEL__guess                      0xaa9cd0ULL   /* interpolated name, verify */
#define N_SET_MISSION_FLAG__guess                          0x9f5800ULL   /* interpolated name, verify */
#define N_SET_MODEL_AS_NO_LONGER_NEEDED                    0xad9400ULL
#define N_SET_OBJECT_AS_NO_LONGER_NEEDED__guess            0x9b56e0ULL   /* interpolated name, verify */
#define N_SET_OBJECT_AS_NO_LONGER_NEEDED__guess_2          0x9b5830ULL
#define N_SET_OBJECT_TINT_INDEX                            0xa670c0ULL
#define N_SET_OVERRIDE_WEATHER                             0x9f5ee0ULL
#define N_SET_PED_AMMO                                     0xb38ea0ULL
#define N_SET_PED_AMMO_BY_TYPE__guess                      0xb398a0ULL   /* interpolated name, verify */
#define N_SET_PED_AMMO_BY_TYPE__guess_2                    0xb399d0ULL
#define N_SET_PED_ARMOUR                                   0xa90930ULL
#define N_SET_PED_AS_ENEMY__guess                          0xa950b0ULL   /* interpolated name, verify */
#define N_SET_PED_AS_GROUP_MEMBER                          0xa92e50ULL
#define N_SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE               0xa94b00ULL
#define N_SET_PED_CAN_BE_TARGETTED                         0xa91be0ULL
#define N_SET_PED_CAN_BE_TARGETTED_BY_PLAYER__guess        0xa91cc0ULL   /* interpolated name, verify */
#define N_SET_PED_CAN_RAGDOLL                              0xa980f0ULL
#define N_SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT           0xa9acf0ULL
#define N_SET_PED_CAN_SWITCH_WEAPON                        0xa9b430ULL
#define N_SET_PED_CHANCE_OF_FIRING_BLANKS__guess           0xb3a770ULL   /* interpolated name, verify */
#define N_SET_PED_COMBAT_ABILITY                           0xa9b680ULL
#define N_SET_PED_COMBAT_ATTRIBUTES__guess                 0xa9b780ULL   /* interpolated name, verify */
#define N_SET_PED_COMBAT_MOVEMENT__guess                   0xa9b5d0ULL   /* interpolated name, verify */
#define N_SET_PED_COMBAT_RANGE__guess                      0xa9b6d0ULL   /* interpolated name, verify */
#define N_SET_PED_COMPONENT_VARIATION                      0xa960a0ULL
#define N_SET_PED_CONFIG_FLAG                              0xa9a7f0ULL
#define N_SET_PED_CURRENT_WEAPON_VISIBLE__guess            0xb391b0ULL   /* interpolated name, verify */
#define N_SET_PED_DEFAULT_COMPONENT_VARIATION__guess       0xa962b0ULL   /* interpolated name, verify */
#define N_SET_PED_INFINITE_AMMO_CLIP                       0xb38ee0ULL
#define N_SET_PED_INTO_VEHICLE                             0xa90a10ULL
#define N_SET_PED_KEEP_TASK__guess                         0xa94db0ULL   /* interpolated name, verify */
#define N_SET_PED_NEVER_LEAVES_GROUP                       0xa94710ULL
#define N_SET_PED_PROP_INDEX                               0xa97450ULL
#define N_SET_PED_RAGDOLL_ON_COLLISION__guess              0xa97ee0ULL   /* interpolated name, verify */
#define N_SET_PED_RANDOM_COMPONENT_VARIATION__guess        0xa96160ULL   /* interpolated name, verify */
#define N_SET_PED_RELATIONSHIP_GROUP_HASH                  0xa93880ULL
#define N_SET_PED_TO_RAGDOLL__guess                        0xa97e30ULL   /* interpolated name, verify */
#define N_SET_PED_WEAPON_TINT_INDEX                        0xb3a5e0ULL
#define N_SET_PLAYER_CONTROL__guess                        0xaa9c60ULL   /* interpolated name, verify */
#define N_SET_PLAYER_INVINCIBLE                            0xaab320ULL
#define N_SET_PLAYER_MAX_ARMOUR__guess                     0xaabb90ULL   /* interpolated name, verify */
#define N_SET_PLAYER_MODEL                                 0xaa93a0ULL
#define N_SET_PLAYER_WANTED_LEVEL_NOW                      0xaa9880ULL
#define N_SET_PLAYER_WANTED_LEVEL__guess                   0xaa97a0ULL   /* interpolated name, verify */
#define N_SET_POLICE_IGNORE_PLAYER__guess                  0xaa9d10ULL   /* interpolated name, verify */
#define N_SET_RENDER_TRAIN_AS_DERAILED__guess              0xb22280ULL   /* interpolated name, verify */
#define N_SET_RENDER_TRAIN_AS_DERAILED__guess_2            0xb222f0ULL
#define N_SET_RIOT_MODE_ENABLED                            0x9fa880ULL
#define N_SET_SCENARIO_GROUP_ENABLED__guess                0xaf5a00ULL   /* interpolated name, verify */
#define N_SET_SCRIPT_AS_NO_LONGER_NEEDED                   0xab0ec0ULL
#define N_SET_SUPER_JUMP_THIS_FRAME                        0x9fab20ULL
#define N_SET_TEAM_PICKUP_OBJECT__guess                    0xa66580ULL   /* interpolated name, verify */
#define N_SET_TEXT_CENTRE                                  0x9e1930ULL
#define N_SET_TEXT_COLOUR                                  0x9e18f0ULL
#define N_SET_TEXT_DROPSHADOW                              0x9e1a20ULL
#define N_SET_TEXT_FONT                                    0x9e19f0ULL
#define N_SET_TEXT_OUTLINE                                 0x9e1a40ULL
#define N_SET_TEXT_RIGHT_JUSTIFY                           0x9e1950ULL
#define N_SET_VEHICLE_CAN_BE_TARGETTED__guess              0xb20e30ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_CAN_BREAK__guess                     0xb216b0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_COLOURS                              0xb1c8b0ULL
#define N_SET_VEHICLE_COLOUR_COMBINATION__guess            0xb21940ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_CUSTOM_PRIMARY_COLOUR                0xb1caa0ULL
#define N_SET_VEHICLE_CUSTOM_SECONDARY_COLOUR              0xb1cca0ULL
#define N_SET_VEHICLE_DEFORMATION_FIXED__guess             0xb22480ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_DOORS_LOCKED                         0xb1bf10ULL
#define N_SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess       0xb1c090ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_ENGINE_CAN_DEGRADE__guess            0xb29290ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_ENGINE_ON                            0xb213b0ULL
#define N_SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE__guess 0xb24380ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_EXTRA_COLOURS__guess                 0xb22180ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_EXTRA__guess                         0xb22bd0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_FIXED__guess                         0xb22410ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_FRICTION_OVERRIDE__guess             0xb2aac0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_HAS_BEEN_OWNED_BY_PLAYER__guess      0xb23560ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_MOD                                  0xb26f80ULL
#define N_SET_VEHICLE_MOD_KIT                              0xb26830ULL
#define N_SET_VEHICLE_NAME_DEBUG__guess                    0xb242e0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_NEEDS_TO_BE_HOTWIRED__guess          0xb23600ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_NUMBER_PLATE_TEXT                    0xb1f230ULL
#define N_SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX              0xb1f300ULL
#define N_SET_VEHICLE_OUT_OF_CONTROL__guess                0xb1c4a0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_STEER_BIAS__guess                    0xb22b60ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_STRONG__guess                        0xb1d8b0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_TYRES_CAN_BURST__guess               0xb1e400ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_TYRE_FIXED__guess                    0xb1f1a0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_TYRE_SMOKE_COLOR                     0xb27810ULL
#define N_SET_VEHICLE_UNDRIVEABLE                          0xb213e0ULL
#define N_SET_VEHICLE_WHEELS_CAN_BREAK__guess              0xb1e4c0ULL   /* interpolated name, verify */
#define N_SET_VEHICLE_WHEEL_TYPE                           0xb269d0ULL
#define N_SET_VEHICLE_WINDOW_TINT                          0xb278e0ULL
#define N_SET_WEAPON_ANIMATION_OVERRIDE__guess             0xb3b580ULL   /* interpolated name, verify */
#define N_SET_WEATHER_TYPE_NOW_PERSIST__guess              0x9f5cb0ULL   /* interpolated name, verify */
#define N_SET_WEATHER_TYPE_NOW__guess                      0x9f5d00ULL   /* interpolated name, verify */
#define N_SET_WEATHER_TYPE_PERSIST__guess                  0x9f5c60ULL   /* interpolated name, verify */
#define N_SET_WIDESCREEN_FORMAT__guess                     0x9e35c0ULL   /* interpolated name, verify */
#define N_SET_ZONE_ENABLED__guess                          0xb3c6d0ULL   /* interpolated name, verify */
#define N_SMASH_VEHICLE_WINDOW__guess                      0xb1e7c0ULL   /* interpolated name, verify */
#define N_SPECIAL_ABILITY_CHARGE_CONTINUOUS__guess         0xaabf50ULL   /* interpolated name, verify */
#define N_SPECIAL_ABILITY_DEPLETE_METER__guess             0xaac180ULL   /* interpolated name, verify */
#define N_SPECIAL_ABILITY_FILL_METER                       0xaac060ULL
#define N_START_NEW_SCRIPT                                 0x1e24d50ULL
#define N_STAT_DELETE_SLOT__guess                          0xacf150ULL   /* interpolated name, verify */
#define N_STAT_GET_DATE__guess                             0xacf850ULL   /* interpolated name, verify */
#define N_STAT_GET_FLOAT__guess                            0xacf7f0ULL   /* interpolated name, verify */
#define N_STAT_GET_INT                                     0xacf710ULL
#define N_STAT_GET_LICENSE_PLATE__guess                    0xacfbc0ULL   /* interpolated name, verify */
#define N_STAT_GET_LICENSE_PLATE__guess_2                  0xacfbe0ULL
#define N_STAT_GET_LICENSE_PLATE__guess_3                  0xacfc00ULL
#define N_STAT_GET_MASKED_INT__guess                       0xacfeb0ULL   /* interpolated name, verify */
#define N_STAT_LOAD_PENDING__guess                         0xacf0e0ULL   /* interpolated name, verify */
#define N_STAT_SAVE_PENDING_OR_REQUESTED__guess            0xacf180ULL   /* interpolated name, verify */
#define N_STAT_SAVE_PENDING_OR_REQUESTED__guess_2          0xacf1a0ULL
#define N_STAT_SAVE__guess                                 0xacf480ULL   /* interpolated name, verify */
#define N_STAT_SET_BOOL                                    0xacf520ULL
#define N_STAT_SET_DATE__guess                             0xacf5a0ULL   /* interpolated name, verify */
#define N_STAT_SET_INT                                     0xacf4b0ULL
#define N_STOP_CUTSCENE_IMMEDIATELY__guess                 0x999600ULL   /* interpolated name, verify */
#define N_STOP_CUTSCENE_IMMEDIATELY__guess_2               0x999630ULL
#define N_TASK_LEAVE_ANY_VEHICLE__guess                    0xaf3a90ULL   /* interpolated name, verify */
#define N_TASK_LEAVE_VEHICLE__guess                        0xaf2260ULL   /* interpolated name, verify */
#define N_TASK_SEEK_COVER_FROM_PED__guess                  0xaf4eb0ULL   /* interpolated name, verify */
#define N_TASK_STAND_STILL                                 0xaf1f50ULL
#define N_TASK_START_SCENARIO_IN_PLACE                     0xaf54d0ULL
#define N_TASK_WARP_PED_INTO_VEHICLE__guess                0xaf47d0ULL   /* interpolated name, verify */
#define N_TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME__guess      0x9f7810ULL   /* interpolated name, verify */
#define N_TOGGLE_VEHICLE_MOD                               0xb27380ULL
#define N_UPDATE_ONSCREEN_KEYBOARD                         0x9fa970ULL
#define N_USE_PARTICLE_FX_ASSET                            0x9cfb80ULL
#define N_VEH_TO_NET__guess                                0xa4f9b0ULL   /* interpolated name, verify */
#define N_WAIT__guess                                      0x1e24a20ULL   /* interpolated name, verify */
#define N__0x0150B6FF25A9E2E5__guess                       0x987690ULL   /* interpolated name, verify */
#define N__0x0378C08504160D0D__guess                       0xa664d0ULL   /* interpolated name, verify */
#define N__0x06A320535F5F0248__guess                       0x9e3fe0ULL   /* interpolated name, verify */
#define N__0x0CDDA42F9E360CA6__guess                       0xb29670ULL   /* interpolated name, verify */
#define N__0x0EDE326D47CD0F3E__guess                       0xa56580ULL   /* interpolated name, verify */
#define N__0x10BD227A753B0D84__guess                       0xa55ec0ULL   /* interpolated name, verify */
#define N__0x10BD227A753B0D84__guess_2                     0xa55ed0ULL
#define N__0x10BD227A753B0D84__guess_3                     0xa55f00ULL
#define N__0x10BD227A753B0D84__guess_4                     0xa55f30ULL
#define N__0x192547247864DFDD__guess                       0xb226e0ULL   /* interpolated name, verify */
#define N__0x1AA8A837D2169D94__guess                       0xb20fd0ULL   /* interpolated name, verify */
#define N__0x206BC5DC9D1AC70A__guess                       0xb22340ULL   /* interpolated name, verify */
#define N__0x206BC5DC9D1AC70A__guess_2                     0xb223b0ULL
#define N__0x228E5C6AD4D74BFD__guess                       0xa70110ULL   /* interpolated name, verify */
#define N__0x22A249A53034450A__guess                       0x9cc930ULL   /* interpolated name, verify */
#define N__0x2311DD7159F00582__guess                       0xb21070ULL   /* interpolated name, verify */
#define N__0x302C91AB2D477F7E__guess                       0x9ce250ULL   /* interpolated name, verify */
#define N__0x341DE7ED1D2A1BFD__guess                       0x9a23e0ULL   /* interpolated name, verify */
#define N__0x3ED1438C1F5C6612__guess                       0x9fa9c0ULL   /* interpolated name, verify */
#define N__0x405DC2AEF6AF95B9__guess                       0x9e88f0ULL   /* interpolated name, verify */
#define N__0x422F32CC7E56ABAD__guess                       0xa53150ULL   /* interpolated name, verify */
#define N__0x428BACCDF5E26EAD__guess                       0xb28930ULL   /* interpolated name, verify */
#define N__0x4A2D4E8BF4265B0F__guess                       0xa55f20ULL   /* interpolated name, verify */
#define N__0x5BFF36D6ED83E0AE__guess                       0x9e5290ULL   /* interpolated name, verify */
#define N__0x616093EC6B139DD9__guess                       0xa66420ULL   /* interpolated name, verify */
#define N__0x67A5589628E0CFF6__guess                       0xa49f70ULL   /* interpolated name, verify */
#define N__0x690A61A6D13583F6__guess                       0xaad2f0ULL   /* interpolated name, verify */
#define N__0x6FDDF453C0C756EC__guess                       0x9fac10ULL   /* interpolated name, verify */
#define N__0x71E7B2E657449AAD__guess                       0xada420ULL   /* interpolated name, verify */
#define N__0x71E7B2E657449AAD__guess_2                     0xada430ULL
#define N__0x78857FC65CADB909__guess                       0xa65dc0ULL   /* interpolated name, verify */
#define N__0x7D6F9A3EF26136A0__guess                       0xb1b010ULL   /* interpolated name, verify */
#define N__0x7D6F9A3EF26136A0__guess_2                     0xb1b130ULL
#define N__0x7DB53B37A2F211A0__guess                       0xa56410ULL   /* interpolated name, verify */
#define N__0x89023FBBF9200E9F__guess                       0xa540d0ULL   /* interpolated name, verify */
#define N__0x95A7DABDDBB78AE7__guess                       0xadb100ULL   /* interpolated name, verify */
#define N__0xA0F93D5465B3094D__guess                       0xad22a0ULL   /* interpolated name, verify */
#define N__0xA13E93403F26C812__guess                       0x9e3900ULL   /* interpolated name, verify */
#define N__0xA48931185F0536FE__guess                       0x9e3890ULL   /* interpolated name, verify */
#define N__0xB56BBBCC2955D9CB__guess                       0x999430ULL   /* interpolated name, verify */
#define N__0xB56BBBCC2955D9CB__guess_2                     0x999490ULL
#define N__0xB56BBBCC2955D9CB__guess_3                     0x9994f0ULL
#define N__0xBED9F5693F34ED17__guess                       0xad00f0ULL   /* interpolated name, verify */
#define N__0xBED9F5693F34ED17__guess_2                     0xad0140ULL
#define N__0xC098810437312FFF__guess                       0x9a2dc0ULL   /* interpolated name, verify */
#define N__0xC17AD0E5752BECDA__guess                       0x9a23b0ULL   /* interpolated name, verify */
#define N__0xCA94551B50B4932C__guess                       0xa56c70ULL   /* interpolated name, verify */
#define N__0xF10B44FD479D69F3__guess                       0xaac3b0ULL   /* interpolated name, verify */
#define N__0xF434A10BA01C37D0__guess                       0xacf300ULL   /* interpolated name, verify */
#define N__0xF70EFA14FE091429__guess                       0xa27370ULL   /* interpolated name, verify */
#define N__0xF92099527DB8E2A7__guess                       0xa66c00ULL   /* interpolated name, verify */
#define N__0xF92099527DB8E2A7__guess_2                     0xa66cd0ULL
#define N__0xFDD85225B2DEA55E__guess                       0x9dfd30ULL   /* interpolated name, verify */
#define N__CREATE_LIGHTNING_THUNDER__guess                 0x9f62d0ULL   /* interpolated name, verify */
#define N__DOES_SCRIPT_WITH_NAME_HASH_EXIST__guess         0xab11f0ULL   /* interpolated name, verify */
#define N__ENABLE_INTERIOR_PROP__guess                     0x9e8ce0ULL   /* interpolated name, verify */
#define N__ENABLE_INTERIOR_PROP__guess_2                   0x9e8d70ULL
#define N__ENABLE_INTERIOR_PROP__guess_3                   0x9e8e00ULL
#define N__GET_BLIP_INFO_ID_ITERATOR__guess                0x9e1ee0ULL   /* interpolated name, verify */
#define N__GET_LABEL_TEXT__guess                           0x9e0a80ULL   /* interpolated name, verify */
#define N__GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess 0xab13c0ULL   /* interpolated name, verify */
#define N__GET_TATTOO_ZONE__guess                          0xa99730ULL   /* interpolated name, verify */
#define N__GET_VEHICLE_NEON_LIGHTS_COLOUR__guess           0xb2b2e0ULL   /* interpolated name, verify */
#define N__GET_VEHICLE_OWNER__guess                        0xb28d20ULL   /* interpolated name, verify */
#define N__IS_INTERIOR_PROP_ENABLED__guess                 0x9e9020ULL   /* interpolated name, verify */
#define N__IS_VEHICLE_NEON_LIGHT_ENABLED__guess            0xb2b410ULL   /* interpolated name, verify */
#define N__LOAD_INTERIOR__guess                            0x9e89a0ULL   /* interpolated name, verify */
#define N__LOAD_MP_DLC_MAPS__guess                         0xa28320ULL   /* interpolated name, verify */
#define N__LOAD_MP_DLC_MAPS__guess_2                       0xa28580ULL
#define N__LOAD_MP_DLC_MAPS__guess_3                       0xa28590ULL
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess 0xa56440ULL   /* interpolated name, verify */
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_2 0xa564a0ULL
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_3 0xa564e0ULL
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_4 0xa56540ULL
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_5 0xa56600ULL
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH__guess         0xa56320ULL   /* interpolated name, verify */
#define N__NETWORK_ACCESS_TUNABLE_BOOL_HASH__guess_2       0xa563c0ULL
#define N__NETWORK_ACCESS_TUNABLE_FLOAT_HASH__guess        0xa56220ULL   /* interpolated name, verify */
#define N__NETWORK_ACCESS_TUNABLE_FLOAT_HASH__guess_2      0xa562a0ULL
#define N__NETWORK_DOES_TUNABLE_EXIST_HASH__guess          0xa561b0ULL   /* interpolated name, verify */
#define N__NETWORK_HAS_CONTROL_OF_PAVEMENT_STATS__guess    0xa4f950ULL   /* interpolated name, verify */
#define N__NETWORK_SESSION_IS_PLAYER_VOTED_TO_KICK__guess  0xa4ab80ULL   /* interpolated name, verify */
#define N__NULLIFY__guess                                  0xa28450ULL   /* interpolated name, verify */
#define N__NULLIFY__guess_2                                0xa28470ULL
#define N__NULLIFY__guess_3                                0xa28560ULL
#define N__PED_SKIP_NEXT_RELOADING__guess                  0xb3a070ULL   /* interpolated name, verify */
#define N__RESET_CURRENT_INTENSITY__guess                  0xb2fdb0ULL   /* interpolated name, verify */
#define N__SET_ENTITY_COLLISION_2__guess                   0x9b5b70ULL   /* interpolated name, verify */
#define N__SET_ENTITY_SOMETHING__guess                     0x9b51b0ULL   /* interpolated name, verify */
#define N__SET_FORCE_PED_FOOTSTEPS_TRACKS__guess           0x9d06b0ULL   /* interpolated name, verify */
#define N__SET_FORCE_VEHICLE_TRAILS__guess                 0x9d06f0ULL   /* interpolated name, verify */
#define N__SET_HUD_COLOUR__guess                           0x9e16d0ULL   /* interpolated name, verify */
#define N__SET_MINIMAP_REVEALED__guess                     0x9e3da0ULL   /* interpolated name, verify */
#define N__SET_NETWORK_ID_SYNC_TO_PLAYER__guess            0xa529a0ULL   /* interpolated name, verify */
#define N__SET_NORTH_YANKTON_MAP__guess                    0x9e3d70ULL   /* interpolated name, verify */
#define N__SET_VEHICLE_NEON_LIGHTS_COLOUR__guess           0xb2b190ULL   /* interpolated name, verify */
#define N__SET_VEHICLE_NEON_LIGHT_ENABLED__guess           0xb2b360ULL   /* interpolated name, verify */
#define N__SET_VEHICLE_SILENT__guess                       0xb238b0ULL   /* interpolated name, verify */
#define N__STAT_SET_PROFILE_SETTING__guess                 0xacff90ULL   /* interpolated name, verify */
#define N__STAT_SET_PROFILE_SETTING__guess_2               0xad0040ULL
#define N__STOP_ALL_SCREEN_EFFECTS__guess                  0x9d2c00ULL   /* interpolated name, verify */
#define N__STOP_ALL_SCREEN_EFFECTS__guess_2                0x9d2c20ULL

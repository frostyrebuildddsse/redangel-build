// invoker.h - Red Angel native invoker (PS4-GTA-V-Menu-Base style). Credits: FrostyTheOne
// In the C conversion the invoker is plain decompiled code in menu.c/main.c:
//   resetArgs() / pushArg_<type>() / callHash(offset) = ((void(*)(NativeArg_s*))(offset + 0x400000))(&nativeArg)
//   setVectors() / getReturn_<type>(), wrapped by invoke_<ret>_<args>(offset, ...).
// Offsets are GTA V 1.57 eboot handler offsets relative to the eboot base 0x400000 (see natives157.h).
#pragma once
#include <stdint.h>
typedef struct { float x; float _px; float y; float _py; float z; float _pz; } Vector3;

// functions.h - prototypes of all decompiled functions
#pragma once
#include "ghidra_types.h"
#include "invoker.h"
#ifdef __cplusplus
extern "C" {
#endif
undefined8 notify_icon(char *param_1,char *param_2);  // 0x80
undefined8 Notify(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, char *param_9,char *param_10,undefined8 param_11,undefined8 param_12, undefined8 param_13,undefined8 param_14);  // 0x120
undefined8 setVectors(void);  // 0x260
undefined8 callHash(long param_1);  // 0x310
undefined8 resetArgs(void);  // 0x340
undefined8 FUN_000003c0(void);  // 0x3c0
undefined8 plugin_load(undefined4 param_1,undefined8 param_2);  // 0x3d0
undefined1 install_cam_hook(void);  // 0x570
undefined8 menu_arm_thread(void);  // 0x660
undefined8 plugin_unload(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0x740
undefined8 FUN_000007b0(void);  // 0x7b0
undefined8 FUN_000007c0(void);  // 0x7c0
bool FUN_000007d0(int *param_1);  // 0x7d0
undefined8 FUN_00000800(undefined8 param_1);  // 0x800
undefined8 FUN_00000900(undefined8 param_1);  // 0x900
undefined8 GET_FRAME_COUNT(void);  // 0x930
undefined8 PLAYER_PED_ID(void);  // 0x940
undefined8 DOES_ENTITY_EXIST(undefined4 param_1);  // 0x950
undefined8 FUN_00000970(uint param_1);  // 0x970
undefined8 invoke_i_void(undefined8 param_1);  // 0x9b0
undefined4 getReturn_int(void);  // 0x9e0
undefined8 invoke_i_i(undefined8 param_1,undefined4 param_2);  // 0xa00
undefined8 pushArg_int(undefined4 param_1);  // 0xa40
undefined8 menu_print(undefined8 param_1);  // 0xaa0
undefined8 BEGIN_TEXT_COMMAND_PRINT(undefined8 param_1);  // 0xae0
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(undefined8 param_1);  // 0xb00
undefined8 END_TEXT_COMMAND_PRINT(undefined4 param_1,undefined4 param_2);  // 0xb20
undefined8 FUN_00000b50(void);  // 0xb50
undefined8 CLEAR_PLAYER_WANTED_LEVEL(undefined4 param_1);  // 0xb90
undefined8 PLAYER_ID(void);  // 0xbb0
undefined8 FUN_00000bc0(void);  // 0xbc0
undefined8 SET_MAX_WANTED_LEVEL__guess(undefined4 param_1);  // 0xc60
undefined8 SET_POLICE_IGNORE_PLAYER__guess(undefined4 param_1,undefined4 param_2);  // 0xc80
undefined8 SET_DISPATCH_COPS_FOR_PLAYER__guess(undefined4 param_1,undefined4 param_2);  // 0xcb0
undefined8 SET_PLAYER_WANTED_LEVEL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0xce0
undefined8 SET_PLAYER_WANTED_LEVEL_NOW(undefined4 param_1,undefined4 param_2);  // 0xd10
undefined8 FUN_00000d40(void);  // 0xd40
undefined8 STAT_GET_INT(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0xe00
undefined8 GET_HASH_KEY(undefined8 param_1);  // 0xe30
undefined8 STAT_SET_INT(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0xe50
undefined8 FUN_00000e80(void);  // 0xe80
undefined8 PLAYER_PED_ID_00f10(void);  // 0xf10
undefined8 DOES_ENTITY_EXIST_00f20(undefined4 param_1);  // 0xf20
undefined8 GET_ENTITY_MAX_HEALTH(undefined4 param_1);  // 0xf40
undefined8 SET_ENTITY_HEALTH(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0xf60
undefined8 SET_PLAYER_MAX_ARMOUR__guess(undefined4 param_1,undefined4 param_2);  // 0xf90
undefined8 SET_PED_ARMOUR(undefined4 param_1,undefined4 param_2);  // 0xfc0
undefined8 CLEAR_PED_BLOOD_DAMAGE(undefined4 param_1);  // 0xff0
undefined8 RESET_PED_VISIBLE_DAMAGE(undefined4 param_1);  // 0x1010
undefined8 CLEAR_PED_WETNESS(undefined4 param_1);  // 0x1030
bool FUN_00001050(void);  // 0x1050
undefined8 NETWORK_IS_IN_SPECTATOR_MODE__guess(void);  // 0x12e0
undefined8 NETWORK_IS_TRANSITION_HOST__guess(void);  // 0x12f0
undefined8 GET_PLAYER_SWITCH_STATE__guess(void);  // 0x1300
undefined8 IS_SCREEN_FADING_IN__guess(void);  // 0x1310
undefined8 IS_SCREEN_FADING_IN__guess_3(void);  // 0x1320
undefined8 IS_SCREEN_FADING_IN__guess_4(void);  // 0x1330
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess(void);  // 0x1340
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_2(void);  // 0x1350
undefined8 GET_INTERIOR_GROUP_ID__guess_3(undefined4 param_1);  // 0x1360
undefined8 GET_INTERIOR_GROUP_ID__guess(undefined4 param_1);  // 0x1380
undefined8 IS_ENTITY_ATTACHED(undefined4 param_1);  // 0x13a0
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess(undefined4 param_1);  // 0x13c0
undefined1 FUN_000013e0(void);  // 0x13e0
undefined8 GET_INTERIOR_GROUP_ID__guess_2(undefined4 param_1);  // 0x1530
bool FUN_00001550(void);  // 0x1550
undefined8 NETWORK_IS_SESSION_STARTED(void);  // 0x1590
undefined8 NETWORK_IS_GAME_IN_PROGRESS(void);  // 0x15a0
byte FUN_000015b0(void);  // 0x15b0
bool FUN_000015c0(void);  // 0x15c0
undefined8 FUN_00001640(void);  // 0x1640
undefined8 FUN_00001650(void);  // 0x1650
undefined8 FUN_00001730(void);  // 0x1730
undefined8 SET_ENTITY_AS_MISSION_ENTITY(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x17c0
undefined8 DELETE_OBJECT(undefined8 param_1);  // 0x17f0
undefined8 FUN_00001810(void);  // 0x1810
undefined8 FUN_00001b70(int param_1);  // 0x1b70
undefined8 HAS_MODEL_LOADED(undefined4 param_1);  // 0x1bb0
undefined8 REQUEST_MODEL(undefined4 param_1);  // 0x1bd0
int FUN_00001bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,int param_8);  // 0x1bf0
int FUN_00001cf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1cf0
undefined8 menu_pickup_net_tick(void);  // 0x1ec0
undefined8 FUN_00001f00(int param_1);  // 0x1f00
undefined8 DOES_PICKUP_EXIST__guess(undefined4 param_1);  // 0x1f80
undefined8 _0xF92099527DB8E2A7__guess_2(undefined4 param_1,undefined4 param_2);  // 0x1fa0
undefined8 _0xF92099527DB8E2A7__guess(undefined4 param_1,undefined4 param_2);  // 0x1fd0
undefined8 DOES_PICKUP_OBJECT_EXIST__guess(undefined4 param_1);  // 0x2000
undefined8 FUN_00002020(int param_1);  // 0x2020
undefined8 FUN_000020a0(void);  // 0x20a0
bool FUN_000020c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4, undefined4 param_5,undefined4 param_6);  // 0x20c0
int FUN_000021a0(int param_1,int param_2);  // 0x21a0
undefined1 FUN_000022b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined8 param_10);  // 0x22b0
undefined8 FUN_00002470(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, int param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,code *param_9);  // 0x2470
undefined8 menu_teleport_to(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2580
undefined8 FUN_000025c0(undefined4 param_1,undefined4 param_2,float param_3);  // 0x25c0
undefined8 FUN_00002630(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2630
undefined8 FUN_00002670(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2670
undefined8 FUN_000026f0(void);  // 0x26f0
byte FUN_00002750(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x2750
undefined8 FUN_000027e0(undefined4 param_1,undefined4 param_2);  // 0x27e0
undefined8 FUN_000028b0(void);  // 0x28b0
byte FUN_00002910(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x2910
undefined8 FUN_00002b90(void);  // 0x2b90
undefined8 FUN_00002c70(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x2c70
undefined8 FUN_00002ca0(void);  // 0x2ca0
undefined * FUN_00002d60(void);  // 0x2d60
byte FUN_00002e00(int param_1);  // 0x2e00
undefined8 FUN_00002e50(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,byte param_5);  // 0x2e50
undefined8 FUN_00002ee0(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4, byte *param_5);  // 0x2ee0
undefined8 FUN_00002fb0(undefined4 param_1,byte param_2);  // 0x2fb0
undefined8 FUN_00002fe0(undefined4 param_1,byte param_2);  // 0x2fe0
undefined8 FUN_000030c0(undefined4 param_1);  // 0x30c0
undefined8 REMOVE_ALL_PED_WEAPONS(undefined4 param_1,undefined4 param_2);  // 0x3100
undefined8 FUN_00003130(int param_1);  // 0x3130
undefined8 GET_CURRENT_PED_WEAPON(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x32b0
bool FUN_000032e0(int param_1);  // 0x32e0
undefined8 GIVE_WEAPON_TO_PED(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x3330
int FUN_00003370(int param_1);  // 0x3370
undefined8 FUN_000033f0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x33f0
undefined8 GET_MAX_AMMO(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x3500
undefined8 SET_PED_AMMO(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x3530
undefined8 SET_CURRENT_PED_WEAPON(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3570
undefined8 FUN_000035a0(void);  // 0x35a0
undefined8 FUN_000035c0(void);  // 0x35c0
undefined8 FUN_00003600(void);  // 0x3600
undefined8 FUN_00003630(void);  // 0x3630
undefined8 GET_NUM_DLC_WEAPONS__guess(void);  // 0x36e0
undefined4 FUN_000036f0(undefined4 param_1);  // 0x36f0
undefined8 FUN_00003750(void);  // 0x3750
undefined8 HAS_PED_GOT_WEAPON(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3800
undefined8 FUN_00003830(void);  // 0x3830
undefined8 FUN_00003850(undefined4 param_1);  // 0x3850
undefined8 FUN_00003960(void);  // 0x3960
undefined8 HAS_THIS_CUTSCENE_LOADED__guess(undefined4 param_1);  // 0x39b0
undefined8 _0xB56BBBCC2955D9CB__guess(void);  // 0x39d0
undefined8 FUN_000039e0(void);  // 0x39e0
bool FUN_00003a10(void);  // 0x3a10
undefined8 menu_session_blacklist_tick(void);  // 0x3a70
undefined8 FUN_00003a90(void);  // 0x3a90
undefined8 FUN_00003b00(void);  // 0x3b00
undefined8 GET_ENTITY_MODEL(undefined4 param_1);  // 0x3c10
undefined8 FUN_00003c30(undefined4 param_1,int param_2);  // 0x3c30
undefined8 CLEAR_PED_DECORATIONS__guess(undefined4 param_1);  // 0x3cc0
undefined8 ADD_PED_DECORATION_FROM_HASHES(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3ce0
undefined8 FUN_00003d10(undefined4 param_1);  // 0x3d10
undefined8 FUN_00003d60(void);  // 0x3d60
undefined8 FUN_00003db0(void);  // 0x3db0
undefined8 FUN_00003e30(ulong param_1,long param_2);  // 0x3e30
undefined8 menu_rockstar_tick(void);  // 0x3e90
undefined8 FUN_00003f30(void);  // 0x3f30
undefined8 FUN_00004030(byte param_1);  // 0x4030
undefined8 FUN_00004180(byte param_1);  // 0x4180
undefined8 FUN_000042b0(void);  // 0x42b0
undefined8 FUN_000042d0(long param_1,char *param_2);  // 0x42d0
undefined8 FUN_00004370(void);  // 0x4370
undefined8 FUN_00004390(void);  // 0x4390
undefined8 FUN_000043b0(void);  // 0x43b0
undefined8 FUN_000043d0(void);  // 0x43d0
undefined8 FUN_000043f0(void);  // 0x43f0
undefined8 FUN_00004410(void);  // 0x4410
undefined8 FUN_00004430(void);  // 0x4430
undefined8 FUN_00004450(void);  // 0x4450
undefined8 FUN_00004470(void);  // 0x4470
undefined8 FUN_00004490(void);  // 0x4490
undefined * FUN_000044b0(void);  // 0x44b0
undefined * FUN_00004510(void);  // 0x4510
undefined * FUN_00004550(void);  // 0x4550
undefined8 menu_world_tick(void);  // 0x45a0
undefined8 FUN_00004b30(void);  // 0x4b30
undefined8 FUN_00004c60(void);  // 0x4c60
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED(undefined4 param_1);  // 0x4cc0
undefined8 FUN_00004ce0(undefined4 param_1);  // 0x4ce0
undefined8 FUN_00004ff0(undefined4 param_1);  // 0x4ff0
undefined8 FUN_00005360(undefined4 param_1);  // 0x5360
undefined8 FUN_000054f0(void);  // 0x54f0
int FUN_00005510(undefined4 param_1);  // 0x5510
undefined8 FUN_000056d0(undefined4 param_1);  // 0x56d0
undefined8 FUN_000057d0(undefined4 param_1);  // 0x57d0
undefined8 FUN_00005910(undefined4 param_1);  // 0x5910
bool FUN_00005a20(undefined4 param_1);  // 0x5a20
undefined8 GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(undefined4 param_1,undefined8 param_2);  // 0x5af0
undefined8 GET_ENTITY_TYPE__guess(undefined4 param_1);  // 0x5b20
undefined8 DELETE_PED(undefined8 param_1);  // 0x5b40
undefined8 DELETE_VEHICLE(undefined8 param_1);  // 0x5b60
undefined8 DELETE_ENTITY(undefined8 param_1);  // 0x5b80
undefined8 GET_PED_LAST_WEAPON_IMPACT_COORD(undefined4 param_1,undefined8 param_2);  // 0x5ba0
undefined8 SET_TEXT_FONT(undefined4 param_1);  // 0x5bd0
undefined8 FUN_00005bf0(undefined4 param_1,undefined4 param_2);  // 0x5bf0
undefined8 SET_TEXT_COLOUR(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x5c20
undefined8 SET_TEXT_CENTRE(undefined4 param_1);  // 0x5c60
undefined8 FUN_00005c80(undefined4 param_1,undefined4 param_2);  // 0x5c80
undefined8 SET_TEXT_DROPSHADOW(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x5cb0
undefined8 SET_TEXT_OUTLINE(void);  // 0x5cf0
undefined8 BEGIN_TEXT_COMMAND_DISPLAY_TEXT(undefined8 param_1);  // 0x5d00
undefined8 FUN_00005d20(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5d20
undefined8 FUN_00005d60(void);  // 0x5d60
undefined8 FUN_00005f60(void);  // 0x5f60
undefined8 NETWORK_PLAYER_IS_BADSPORT__guess(void);  // 0x6040
undefined8 GET_HASH_OF_THIS_SCRIPT_NAME__guess(void);  // 0x6050
undefined8 _0x0378C08504160D0D__guess(undefined4 param_1);  // 0x6060
undefined8 FUN_00006080(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12);  // 0x6080
undefined8 SET_TEAM_PICKUP_OBJECT__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6100
bool FUN_00006130(void);  // 0x6130
undefined4 FUN_000061a0(undefined4 param_1);  // 0x61a0
undefined1 FUN_000061f0(int param_1);  // 0x61f0
int FUN_000062b0(undefined4 param_1,undefined4 param_2,float param_3,int param_4,int param_5);  // 0x62b0
undefined8 _0x616093EC6B139DD9__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6450
undefined4 FUN_00006480(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x6480
undefined8 FUN_00006510(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x6510
undefined8 FUN_00006560(int param_1);  // 0x6560
undefined8 GET_FRAME_COUNT_065c0(void);  // 0x65c0
undefined8 FUN_000065d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x65d0
undefined8 NETWORK_PLAYER_ID_TO_INT__guess(void);  // 0x6640
int FUN_00006650(int param_1);  // 0x6650
undefined8 FUN_00006750(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0x6750
int FUN_00006870(int param_1,int param_2);  // 0x6870
undefined8 FUN_00006890(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x6890
undefined8 FUN_00006900(void);  // 0x6900
undefined8 PED_TO_NET__guess(undefined4 param_1);  // 0x6980
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess(undefined4 param_1);  // 0x69a0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2(undefined4 param_1,undefined4 param_2);  // 0x69c0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess(undefined4 param_1,undefined4 param_2);  // 0x69f0
undefined8 FUN_00006a20(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6a20
undefined8 SET_ENTITY_IS_TARGET_PRIORITY__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6a60
undefined8 FUN_00006a90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6a90
undefined8 IS_WAYPOINT_ACTIVE__guess(void);  // 0x6ad0
undefined8 _GET_BLIP_INFO_ID_ITERATOR__guess(void);  // 0x6ae0
undefined8 GET_FIRST_BLIP_INFO_ID(undefined4 param_1);  // 0x6af0
undefined8 DOES_BLIP_EXIST(undefined4 param_1);  // 0x6b10
bool FUN_00006b30(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x6b30
undefined8 FUN_00006bb0(undefined8 param_1,undefined4 param_2);  // 0x6bb0
undefined8 FUN_00006be0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x6be0
undefined8 IS_BLIP_SHORT_RANGE__guess(undefined4 param_1);  // 0x6c40
undefined8 GET_BLIP_INFO_ID_TYPE__guess(undefined4 param_1);  // 0x6c60
undefined8 GET_BLIP_COLOUR__guess(undefined4 param_1);  // 0x6c80
undefined8 GET_BLIP_INFO_ID_DISPLAY__guess(undefined4 param_1);  // 0x6ca0
undefined8 GET_NEXT_BLIP_INFO_ID__guess(undefined4 param_1);  // 0x6cc0
undefined1 FUN_00006ce0(int param_1);  // 0x6ce0
undefined8 _PED_SKIP_NEXT_RELOADING__guess(undefined4 param_1);  // 0x6d60
undefined8 _0xC098810437312FFF__guess(undefined4 param_1);  // 0x6d80
undefined4 FUN_00006da0(undefined4 param_1,undefined4 param_2);  // 0x6da0
undefined8 DOES_WEAPON_TAKE_WEAPON_COMPONENT__guess(undefined4 param_1,undefined4 param_2);  // 0x6e00
undefined1 FUN_00006e30(undefined4 param_1,undefined4 param_2);  // 0x6e30
undefined8 GIVE_WEAPON_COMPONENT_TO_PED__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x7010
undefined8 SET_PED_WEAPON_TINT_INDEX(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x7040
undefined8 GET_DLC_WEAPON_COMPONENT_DATA__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x7070
int FUN_000070a0(undefined8 param_1,char param_2);  // 0x70a0
undefined8 GET_DLC_WEAPON_DATA__guess(undefined4 param_1,undefined8 param_2);  // 0x70f0
undefined8 FUN_00007120(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x7120
undefined8 FUN_00007180(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11);  // 0x7180
undefined8 FUN_00007200(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x7200
undefined8 FUN_00007250(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x7250
undefined8 FUN_000072a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x72a0
undefined8 FUN_000072f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x72f0
ulong FUN_00007340(void);  // 0x7340
int FUN_000073b0(void);  // 0x73b0
undefined8 FUN_00007400(long *param_1);  // 0x7400
undefined8 FUN_000074b0(long *param_1);  // 0x74b0
undefined8 FUN_00007560(uint param_1);  // 0x7560
undefined8 FUN_000075b0(long *param_1);  // 0x75b0
undefined4 FUN_00007630(void);  // 0x7630
undefined8 FUN_000076e0(undefined4 param_1);  // 0x76e0
undefined8 FUN_00007840(void);  // 0x7840
undefined8 GET_RANDOM_INT_IN_RANGE(undefined4 param_1,undefined4 param_2);  // 0x7890
undefined8 IS_MODEL_IN_CDIMAGE(undefined4 param_1);  // 0x78c0
undefined8 IS_MODEL_VALID(undefined4 param_1);  // 0x78e0
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_3(undefined4 param_1);  // 0x7900
undefined8 FUN_00007920(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x7920
undefined8 SET_VEHICLE_ENGINE_ON(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x7980
undefined8 FUN_000079c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x79c0
undefined8 SET_VEHICLE_OUT_OF_CONTROL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x7a00
undefined8 _NETWORK_HAS_CONTROL_OF_PAVEMENT_STATS__guess(undefined4 param_1);  // 0x7a30
undefined8 FUN_00007a50(undefined4 param_1);  // 0x7a50
undefined8 IS_PED_DEAD_OR_DYING__guess(undefined4 param_1,undefined4 param_2);  // 0x7b30
undefined8 GET_WEAPONTYPE_GROUP__guess(undefined4 param_1);  // 0x7b60
undefined8 IS_PED_IN_ANY_VEHICLE(undefined4 param_1,undefined4 param_2);  // 0x7b80
undefined8 DISABLE_CONTROL_ACTION(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x7bb0
undefined8 IS_DISABLED_CONTROL_PRESSED(undefined4 param_1,undefined4 param_2);  // 0x7be0
undefined8 FUN_00007c10(undefined4 param_1,float *param_2,float *param_3,float *param_4,float *param_5, float *param_6,float *param_7);  // 0x7c10
undefined8 FUN_00007ee0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13);  // 0x7ee0
undefined8 FUN_00007f70(float *param_1,float *param_2,undefined4 *param_3);  // 0x7f70
undefined8 FUN_00008010(undefined8 param_1);  // 0x8010
undefined8 GET_BEST_PED_WEAPON__guess(undefined4 param_1,undefined4 param_2);  // 0x8040
undefined8 FUN_00008070(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x8070
undefined8 FUN_000080d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x80d0
undefined8 GET_SHAPE_TEST_RESULT(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5);  // 0x8140
undefined8 FUN_00008180(undefined8 param_1,undefined4 param_2);  // 0x8180
undefined8 FUN_000081b0(undefined4 param_1);  // 0x81b0
undefined8 FUN_000081e0(undefined4 param_1);  // 0x81e0
undefined8 FUN_00008210(undefined4 param_1);  // 0x8210
undefined8 FUN_00008240(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x8240
undefined1 FUN_00008550(undefined8 param_1,undefined4 param_2);  // 0x8550
float FUN_00008650(void);  // 0x8650
undefined4 FUN_000086b0(void);  // 0x86b0
undefined8 NETWORK_IS_PLAYER_ACTIVE(undefined4 param_1);  // 0x8710
undefined8 GET_PLAYER_PED(undefined4 param_1);  // 0x8730
undefined1 FUN_00008750(int param_1,int param_2);  // 0x8750
undefined8 FUN_00008860(float param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x8860
undefined8 GET_PED_NEARBY_PEDS(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x8980
undefined8 IS_PED_A_PLAYER(undefined4 param_1);  // 0x89b0
undefined8 FUN_000089d0(undefined4 param_1,undefined4 param_2);  // 0x89d0
bool FUN_00008a00(undefined4 param_1,undefined4 param_2);  // 0x8a00
undefined8 FUN_00008a50(float param_1,undefined4 param_2);  // 0x8a50
undefined8 GET_PLAYER_TARGET_ENTITY__guess(undefined4 param_1,undefined8 param_2);  // 0x8ad0
int FUN_00008b00(float param_1,float param_2,undefined4 param_3,int param_4,undefined4 param_5);  // 0x8b00
float FUN_00008ea0(undefined4 param_1,undefined4 param_2);  // 0x8ea0
undefined8 FUN_00008fd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6);  // 0x8fd0
undefined8 FUN_00009020(float param_1,long param_2);  // 0x9020
undefined1 FUN_00009290(undefined4 param_1);  // 0x9290
undefined8 FUN_00009460(float param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x9460
undefined8 IS_PLAYER_FREE_AIMING(undefined4 param_1);  // 0x96f0
float FUN_00009710(float param_1);  // 0x9710
undefined8 FUN_00009780(undefined4 param_1,undefined4 param_2);  // 0x9780
undefined8 FUN_000097b0(undefined4 param_1,undefined4 param_2);  // 0x97b0
float FUN_000097e0(float param_1,float param_2,float param_3);  // 0x97e0
undefined8 FUN_00009850(undefined4 param_1);  // 0x9850
undefined8 GET_GAMEPLAY_CAM_RELATIVE_HEADING__guess(void);  // 0x9880
undefined8 FUN_00009890(undefined4 param_1,undefined4 param_2);  // 0x9890
undefined8 GET_GAMEPLAY_CAM_RELATIVE_PITCH(void);  // 0x98c0
undefined8 IS_PED_SHOOTING(undefined4 param_1);  // 0x98d0
undefined8 IS_CONTROL_PRESSED(undefined4 param_1,undefined4 param_2);  // 0x98f0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY(undefined4 param_1);  // 0x9920
undefined8 GET_VEHICLE_PED_IS_IN(undefined4 param_1,undefined4 param_2);  // 0x9940
undefined8 FUN_00009970(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14,undefined4 param_15);  // 0x9970
undefined8 IS_ENTITY_A_PED__guess(undefined4 param_1);  // 0x9a20
undefined8 IS_ENTITY_DEAD(undefined4 param_1,undefined4 param_2);  // 0x9a40
bool FUN_00009a70(undefined4 param_1,undefined4 param_2);  // 0x9a70
undefined8 HAS_ENTITY_CLEAR_LOS_TO_ENTITY__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x9af0
undefined8 IS_PED_GROUP_MEMBER__guess(undefined4 param_1,undefined4 param_2);  // 0x9b20
undefined8 GET_PLAYER_GROUP(undefined4 param_1);  // 0x9b50
undefined8 GET_RELATIONSHIP_BETWEEN_PEDS__guess(undefined4 param_1,undefined4 param_2);  // 0x9b70
undefined8 REQUEST_WEAPON_ASSET(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x9ba0
undefined8 FUN_00009bd0(void);  // 0x9bd0
undefined8 GET_AMMO_IN_CLIP__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x9bf0
undefined8 FUN_00009c20(undefined4 param_1);  // 0x9c20
undefined8 FUN_00009de0(undefined4 param_1);  // 0x9de0
undefined8 HAS_WEAPON_ASSET_LOADED(undefined4 param_1);  // 0x9e10
undefined8 FUN_00009e30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x9e30
undefined8 CLEAR_FOCUS(void);  // 0x9ea0
undefined1 FUN_00009eb0(undefined4 param_1,undefined4 param_2,float param_3,float *param_4);  // 0x9eb0
undefined8 FUN_0000a1c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6);  // 0xa1c0
undefined8 _0xB56BBBCC2955D9CB__guess_3(void);  // 0xa210
undefined8 _0xB56BBBCC2955D9CB__guess_2(void);  // 0xa220
undefined8 FUN_0000a230(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0xa230
undefined8 invoke_p_s(undefined8 param_1,undefined8 param_2);  // 0xa260
undefined8 pushArg_cstr(undefined8 param_1);  // 0xa2a0
undefined8 getReturn_ptr(void);  // 0xa300
undefined8 invoke_p_ii(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0xa320
undefined8 invoke_p_i(undefined8 param_1,undefined4 param_2);  // 0xa360
undefined8 invoke_p_iii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0xa3a0
undefined8 invoke_i_ipii(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0xa3f0
undefined8 pushArg_intptr(undefined8 param_1);  // 0xa440
undefined8 invoke_i_s(undefined8 param_1,undefined8 param_2);  // 0xa4a0
undefined8 invoke_i_iii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0xa4e0
undefined8 invoke_p_pi(undefined8 param_1,undefined8 param_2);  // 0xa530
undefined8 invoke_i_iffffffiiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13);  // 0xa570
undefined8 pushArg_float(undefined4 param_1);  // 0xa640
undefined8 invoke_i_ifffiiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0xa6a0
undefined8 invoke_i_iffff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6);  // 0xa740
undefined8 invoke_p_fff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0xa7c0
undefined8 invoke_p_ifff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0xa820
undefined8 invoke_v3_i(undefined8 param_1,undefined8 param_2,undefined4 param_3);  // 0xa890
undefined8 * getReturn_vec3(undefined8 *param_1);  // 0xa8e0
undefined8 invoke_p_ffffff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7);  // 0xa910
undefined8 invoke_v3_ii(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0xa9a0
undefined8 invoke_p_iiiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0xa9f0
undefined8 invoke_i_iipi(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0xaa60
undefined8 invoke_i_ii(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0xaab0
undefined8 invoke_p_iiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0xaaf0
undefined8 invoke_i_ipi(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0xab50
undefined8 invoke_p_ffffiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0xaba0
undefined8 invoke_p_ffffiiiiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12);  // 0xac40
undefined8 invoke_p_ffffi(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6);  // 0xad00
undefined8 invoke_p_void(undefined8 param_1);  // 0xad80
undefined8 invoke_i_iffffiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0xadb0
undefined8 invoke_f_f(undefined4 param_1,undefined8 param_2);  // 0xae50
undefined4 getReturn_float(void);  // 0xae90
undefined8 invoke_v3_void(undefined8 param_1,undefined8 param_2);  // 0xaeb0
undefined8 invoke_f_ffffffi(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8);  // 0xaef0
undefined8 invoke_i_ffffffiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0xaf80
undefined8 invoke_i_ipipv3pv3pi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0xb030
undefined8 pushArg_vec3ptr(undefined8 param_1);  // 0xb0a0
undefined8 invoke_p_ffffffiiiiiif(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14);  // 0xb100
undefined8 invoke_p_if(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0xb1e0
undefined8 invoke_v3_iifff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7);  // 0xb230
undefined8 invoke_f_ff(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0xb2b0
undefined8 invoke_p_f(undefined4 param_1,undefined8 param_2);  // 0xb300
undefined8 invoke_f_void(undefined8 param_1);  // 0xb340
undefined8 invoke_p_ff(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0xb370
undefined8 invoke_p_ffffffiiiiiifii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16);  // 0xb3c0
undefined8 invoke_p_ifffifiif(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0xb4b0
undefined8 invoke_i_ipv3(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0xb560
undefined8 invoke_p_ffi(undefined4 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0xb5b0
undefined8 invoke_i_fffpfii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7);  // 0xb610
undefined8 pushArg_floatptr(undefined8 param_1);  // 0xb690
undefined8 invoke_i_iif(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0xb6f0
undefined8 FUN_0000b740(void);  // 0xb740
undefined8 FUN_0000d530(void);  // 0xd530
undefined8 FUN_0000d540(void);  // 0xd540
undefined8 FUN_0000d550(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0xd550
undefined8 FUN_0000d5b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined *param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,int param_10);  // 0xd5b0
float FUN_0000d6e0(int param_1);  // 0xd6e0
float FUN_0000d710(float param_1,float param_2);  // 0xd710
undefined8 FUN_0000d750(float param_1,float param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0xd750
undefined8 SET_TEXT_FONT_0d820(undefined4 param_1);  // 0xd820
undefined8 FUN_0000d840(undefined4 param_1,undefined4 param_2);  // 0xd840
undefined8 SET_TEXT_COLOUR_0d870(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0xd870
undefined8 SET_TEXT_CENTRE_0d8b0(undefined4 param_1);  // 0xd8b0
undefined8 SET_TEXT_RIGHT_JUSTIFY(undefined4 param_1);  // 0xd8d0
undefined8 FUN_0000d8f0(undefined4 param_1,undefined4 param_2);  // 0xd8f0
undefined8 SET_TEXT_DROPSHADOW_0d920(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0xd920
undefined8 SET_TEXT_OUTLINE_0d960(void);  // 0xd960
undefined8 BEGIN_TEXT_COMMAND_DISPLAY_TEXT_0d970(undefined8 param_1);  // 0xd970
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME_0d990(undefined8 param_1);  // 0xd990
undefined8 FUN_0000d9b0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0xd9b0
undefined8 invoke_p_ffffiiiib(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,byte param_10);  // 0xd9f0
undefined8 pushArg_bool(byte param_1);  // 0xdaa0
undefined8 FUN_0000db00(long param_1,long param_2,int param_3);  // 0xdb00
void * FUN_0000dbe0(void *param_1,long param_2,int param_3);  // 0xdbe0
undefined8 FUN_0000dd30(undefined1 *param_1,undefined8 param_2);  // 0xdd30
undefined8 FUN_0000ddd0(long param_1,long param_2);  // 0xddd0
undefined8 FUN_0000de10(void);  // 0xde10
undefined8 FUN_0000de60(void);  // 0xde60
undefined8 FUN_0000def0(void);  // 0xdef0
undefined8 FUN_0000dfa0(void);  // 0xdfa0
bool FUN_0000e2d0(undefined8 param_1);  // 0xe2d0
undefined8 GET_HASH_KEY_0e300(undefined8 param_1);  // 0xe300
undefined8 FUN_0000e320(undefined4 param_1,undefined4 param_2);  // 0xe320
undefined8 FUN_0000e3a0(int param_1,undefined4 param_2);  // 0xe3a0
undefined8 FUN_0000e3f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, long param_5);  // 0xe3f0
undefined8 FUN_0000e460(void);  // 0xe460
undefined1 FUN_0000e480(char *param_1,char *param_2);  // 0xe480
undefined8 FUN_0000e7e0(void);  // 0xe7e0
undefined8 FUN_0000e800(void);  // 0xe800
undefined8 FUN_0000e820(void);  // 0xe820
undefined8 FUN_0000e840(void);  // 0xe840
undefined8 FUN_0000e860(void);  // 0xe860
undefined8 FUN_0000e880(void);  // 0xe880
undefined8 FUN_0000e8a0(void);  // 0xe8a0
undefined8 FUN_0000e8c0(void);  // 0xe8c0
undefined8 FUN_0000e8e0(void);  // 0xe8e0
undefined8 FUN_0000e900(void);  // 0xe900
undefined8 FUN_0000e920(void);  // 0xe920
undefined8 FUN_0000e940(void);  // 0xe940
undefined8 FUN_0000e960(void);  // 0xe960
undefined8 FUN_0000e980(void);  // 0xe980
undefined8 FUN_0000e9a0(void);  // 0xe9a0
undefined8 _0x89023FBBF9200E9F__guess(void);  // 0xe9c0
undefined8 NETWORK_GET_NUM_CONNECTED_PLAYERS__guess(void);  // 0xe9d0
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_0e9e0(undefined4 param_1);  // 0xe9e0
undefined8 FUN_0000ea00(void);  // 0xea00
undefined8 NETWORK_IS_SESSION_STARTED_0ea80(void);  // 0xea80
undefined ** FUN_0000ea90(char *param_1);  // 0xea90
undefined8 _DOES_SCRIPT_WITH_NAME_HASH_EXIST__guess(undefined4 param_1);  // 0xeb20
undefined1 FUN_0000eb40(long param_1,undefined1 *param_2);  // 0xeb40
undefined8 PLAYER_ID_0ecc0(void);  // 0xecc0
undefined8 NETWORK_GET_HOST_OF_SCRIPT__guess(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0xecd0
bool FUN_0000ed00(ulong param_1);  // 0xed00
undefined8 invoke_i_sii(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0xed40
undefined8 FUN_0000ed90(void);  // 0xed90
undefined8 FUN_0000edb0(int param_1,byte param_2);  // 0xedb0
undefined8 FUN_0000efc0(void);  // 0xefc0
undefined8 PLAYER_PED_ID_0f0a0(void);  // 0xf0a0
undefined8 IS_PED_IN_ANY_VEHICLE_0f0b0(undefined4 param_1,undefined4 param_2);  // 0xf0b0
undefined8 GET_VEHICLE_PED_IS_IN_0f0e0(undefined4 param_1,undefined4 param_2);  // 0xf0e0
undefined8 DOES_ENTITY_EXIST_0f110(undefined4 param_1);  // 0xf110
bool FUN_0000f130(void);  // 0xf130
undefined8 FUN_0000f220(undefined4 param_1,int param_2);  // 0xf220
undefined8 FUN_0000f490(void);  // 0xf490
undefined8 FUN_0000f830(void);  // 0xf830
undefined8 FUN_0000f870(int param_1);  // 0xf870
undefined8 FUN_0000f960(undefined4 param_1);  // 0xf960
undefined8 IS_MODEL_IN_CDIMAGE_0fa20(undefined4 param_1);  // 0xfa20
undefined8 IS_MODEL_A_VEHICLE(undefined4 param_1);  // 0xfa40
undefined8 GET_INTERIOR_GROUP_ID__guess_3_0fa60(undefined4 param_1);  // 0xfa60
undefined8 REQUEST_MODEL_0fa80(undefined4 param_1);  // 0xfa80
char * FUN_0000faa0(undefined4 param_1);  // 0xfaa0
bool FUN_0000fb40(void);  // 0xfb40
bool FUN_0000fb70(void);  // 0xfb70
undefined8 FUN_0000fb90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, int param_5);  // 0xfb90
undefined8 GET_HASH_KEY_0fcf0(undefined8 param_1);  // 0xfcf0
undefined8 FUN_0000fd10(int param_1);  // 0xfd10
undefined8 FUN_0000fd90(void);  // 0xfd90
undefined8 FUN_0000fe10(undefined4 param_1);  // 0xfe10
undefined8 GET_ENTITY_MODEL_0fe40(undefined4 param_1);  // 0xfe40
undefined8 FUN_0000fe60(void);  // 0xfe60
undefined8 FUN_0000fea0(void);  // 0xfea0
undefined8 FUN_0000fed0(void);  // 0xfed0
undefined8 FUN_0000ff30(void);  // 0xff30
undefined8 _0x428BACCDF5E26EAD__guess(undefined4 param_1,undefined4 param_2);  // 0xffe0
undefined8 SET_VEHICLE_HAS_BEEN_OWNED_BY_PLAYER__guess(undefined4 param_1,undefined4 param_2);  // 0x10010
undefined8 _0x0CDDA42F9E360CA6__guess(undefined4 param_1,undefined4 param_2);  // 0x10040
undefined8 FUN_00010070(void);  // 0x10070
int FUN_000101e0(int param_1);  // 0x101e0
bool FUN_00010200(int param_1);  // 0x10200
undefined8 FUN_00010280(void);  // 0x10280
int menu_garage_list_count(void);  // 0x10490
undefined * menu_garage_list_options(void);  // 0x104b0
undefined8 FUN_000104d0(void);  // 0x104d0
undefined8 FUN_00010520(void);  // 0x10520
undefined8 FUN_000105f0(int param_1);  // 0x105f0
undefined4 FUN_000108f0(int param_1);  // 0x108f0
undefined8 FUN_00010950(undefined8 *param_1,undefined8 param_2,undefined8 param_3);  // 0x10950
undefined8 FUN_00010a10(void);  // 0x10a10
undefined8 menu_garage_slot_count(void);  // 0x10a30
undefined * menu_garage_slot_options(void);  // 0x10a40
undefined * FUN_00010a50(void);  // 0x10a50
undefined8 menu_garage_spawn_tick(void);  // 0x10a60
undefined8 FUN_00010e40(void);  // 0x10e40
undefined8 FUN_00010fc0(int param_1);  // 0x10fc0
undefined8 FUN_000112c0(void);  // 0x112c0
undefined8 FUN_00011360(char *param_1);  // 0x11360
undefined8 TASK_LEAVE_ANY_VEHICLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x113d0
undefined8 FUN_00011400(undefined4 param_1);  // 0x11400
bool FUN_00011460(int param_1);  // 0x11460
undefined8 SET_VEHICLE_DOORS_LOCKED(undefined4 param_1,undefined4 param_2);  // 0x114f0
undefined8 SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x11520
undefined8 PLAYER_ID_11550(void);  // 0x11550
undefined8 GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess(undefined4 param_1,undefined4 param_2);  // 0x11560
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_11590(undefined4 param_1);  // 0x11590
undefined8 IS_PED_IN_VEHICLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x115b0
undefined8 FUN_000115e0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x115e0
undefined8 FUN_00011610(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x11610
undefined8 SET_PED_INTO_VEHICLE(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x11650
undefined8 TASK_WARP_PED_INTO_VEHICLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x11680
undefined8 IS_PED_GETTING_INTO_A_VEHICLE__guess(undefined4 param_1);  // 0x116b0
undefined8 SET_VEHICLE_ENGINE_ON_116d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x116d0
undefined8 FUN_00011710(void);  // 0x11710
bool menu_garage_ready(void);  // 0x11720
undefined4 FUN_00011750(void);  // 0x11750
undefined8 FUN_00011760(undefined4 param_1);  // 0x11760
byte FUN_00011780(undefined4 param_1);  // 0x11780
bool FUN_000117a0(undefined4 param_1);  // 0x117a0
undefined8 FUN_00011810(undefined4 param_1);  // 0x11810
byte FUN_00011830(void);  // 0x11830
undefined4 FUN_00011840(void);  // 0x11840
int FUN_00011890(void);  // 0x11890
undefined8 FUN_000118e0(uint param_1);  // 0x118e0
undefined8 DECOR_EXIST_ON__guess(undefined4 param_1,undefined8 param_2);  // 0x11a50
undefined8 DECOR_GET_INT__guess(undefined4 param_1,undefined8 param_2);  // 0x11a80
int FUN_00011ab0(int param_1);  // 0x11ab0
undefined8 GET_VEHICLE_NUMBER_PLATE_TEXT(undefined4 param_1);  // 0x11d10
undefined8 GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX__guess(undefined4 param_1);  // 0x11d30
undefined1 FUN_00011d50(int param_1,undefined8 param_2,int param_3);  // 0x11d50
undefined8 FUN_00011e00(undefined4 param_1);  // 0x11e00
undefined4 FUN_00011e40(int param_1);  // 0x11e40
undefined8 FUN_00011ea0(undefined4 param_1);  // 0x11ea0
undefined8 FUN_00011ec0(int param_1);  // 0x11ec0
undefined8 FUN_00011f30(int param_1);  // 0x11f30
undefined8 FUN_00012000(undefined4 param_1);  // 0x12000
undefined4 FUN_000120a0(void);  // 0x120a0
undefined8 FUN_000120b0(int param_1,undefined1 *param_2,int param_3);  // 0x120b0
undefined1 FUN_00012210(char *param_1,char *param_2);  // 0x12210
undefined8 FUN_00012410(int param_1,char *param_2);  // 0x12410
undefined1 FUN_00012480(int param_1,int param_2);  // 0x12480
bool FUN_00012510(undefined4 param_1,undefined4 param_2);  // 0x12510
undefined8 FUN_000125c0(uint param_1,undefined4 param_2);  // 0x125c0
undefined1 FUN_00012640(int param_1);  // 0x12640
bool FUN_000126e0(undefined4 param_1);  // 0x126e0
int FUN_00012720(int param_1);  // 0x12720
bool FUN_000127b0(int param_1,int param_2);  // 0x127b0
int FUN_00012980(int param_1);  // 0x12980
int FUN_00012c60(int param_1);  // 0x12c60
int FUN_00012e10(int param_1);  // 0x12e10
undefined8 _0xBED9F5693F34ED17__guess_2(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x12eb0
undefined8 _STAT_SET_PROFILE_SETTING__guess_2(undefined4 param_1,undefined4 param_2);  // 0x12ee0
undefined8 FUN_00012f10(void);  // 0x12f10
byte FUN_00012ff0(undefined4 param_1,undefined4 param_2);  // 0x12ff0
undefined1 FUN_00013020(int param_1,int param_2,int param_3);  // 0x13020
undefined8 FUN_00013160(undefined4 param_1,undefined4 param_2);  // 0x13160
undefined8 FUN_000132c0(void);  // 0x132c0
undefined8 _NULLIFY__guess(undefined4 param_1,undefined4 param_2);  // 0x13310
int FUN_00013340(void);  // 0x13340
undefined8 FUN_000133f0(undefined4 param_1);  // 0x133f0
undefined8 SET_ENTITY_AS_MISSION_ENTITY_13410(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x13410
undefined8 DELETE_VEHICLE_13440(undefined8 param_1);  // 0x13440
bool FUN_00013460(int param_1,int param_2);  // 0x13460
undefined8 FUN_00013580(int param_1,int param_2);  // 0x13580
undefined1 FUN_00013680(void);  // 0x13680
undefined8 FUN_00013770(void);  // 0x13770
bool FUN_000137c0(int param_1);  // 0x137c0
bool FUN_000137f0(int param_1);  // 0x137f0
undefined8 GET_VEHICLE_COLOURS__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x13850
undefined8 GET_VEHICLE_EXTRA_COLOURS__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x13880
undefined8 GET_VEHICLE_WHEEL_TYPE__guess(undefined4 param_1);  // 0x138b0
undefined8 GET_VEHICLE_WINDOW_TINT__guess(undefined4 param_1);  // 0x138d0
undefined8 IS_TOGGLE_MOD_ON__guess(undefined4 param_1,undefined4 param_2);  // 0x138f0
undefined8 GET_VEHICLE_MOD__guess(undefined4 param_1,undefined4 param_2);  // 0x13920
int FUN_00013950(void);  // 0x13950
undefined8 GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(undefined4 param_1);  // 0x139f0
undefined8 _GET_LABEL_TEXT__guess(undefined8 param_1);  // 0x13a10
undefined8 FUN_00013a30(void);  // 0x13a30
undefined8 IS_INTERIOR_SCENE__guess(void);  // 0x13e80
undefined8 HAS_MODEL_LOADED_13e90(undefined4 param_1);  // 0x13e90
undefined8 FUN_00013eb0(undefined4 param_1,undefined4 param_2);  // 0x13eb0
undefined8 GET_ENTITY_HEADING(undefined4 param_1);  // 0x14040
undefined8 FUN_00014060(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x14060
undefined8 FUN_000140c0(undefined4 param_1,undefined4 param_2);  // 0x140c0
undefined8 SET_VEHICLE_NEEDS_TO_BE_HOTWIRED__guess(undefined4 param_1,undefined4 param_2);  // 0x140f0
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_14120(undefined4 param_1);  // 0x14120
undefined8 FUN_00014140(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x14140
undefined8 _0x405DC2AEF6AF95B9__guess(undefined4 param_1);  // 0x14180
undefined8 SET_INTERIOR_ACTIVE__guess(undefined4 param_1,undefined4 param_2);  // 0x141a0
undefined1 FUN_000141d0(int param_1);  // 0x141d0
undefined8 NETWORK_HANDLE_FROM_USER_ID__guess(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x142e0
undefined8 STAT_GET_INT_14310(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x14310
undefined8 STAT_SET_INT_14340(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x14340
undefined8 invoke_p_ipipi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4);  // 0x14370
undefined8 invoke_s_i(undefined8 param_1,undefined4 param_2);  // 0x143c0
undefined8 getReturn_cstr(void);  // 0x14400
undefined8 invoke_s_s(undefined8 param_1,undefined8 param_2);  // 0x14420
undefined8 invoke_f_i(undefined8 param_1,undefined4 param_2);  // 0x14460
undefined8 invoke_i_if(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x144a0
undefined8 invoke_i_fff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0x144f0
undefined8 invoke_i_is(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0x14550
undefined8 invoke_p_ipii(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0x145a0
byte menu_is_open(void);  // 0x145f0
undefined4 menu_current_id(void);  // 0x14610
char * menu_title(void);  // 0x14620
undefined ** FUN_000148b0(void);  // 0x148b0
undefined4 menu_current_option(void);  // 0x148d0
int menu_option_count(void);  // 0x148e0
undefined4 FUN_00014930(void);  // 0x14930
undefined ** FUN_00014f40(void);  // 0x14f40
undefined ** menu_options(void);  // 0x155b0
byte menu_option_press(void);  // 0x15600
undefined8 FUN_00015620(void);  // 0x15620
undefined8 menu_force_close(void);  // 0x15630
undefined8 FUN_00015660(void);  // 0x15660
undefined8 menu_session_guard_tick(void);  // 0x156f0
undefined8 NETWORK_IS_SESSION_STARTED_15810(void);  // 0x15810
undefined8 NETWORK_IS_GAME_IN_PROGRESS_15820(void);  // 0x15820
undefined8 _0xF434A10BA01C37D0__guess(undefined4 param_1);  // 0x15830
undefined8 _0x22A249A53034450A__guess(undefined4 param_1);  // 0x15850
undefined8 SET_FRONTEND_ACTIVE__guess(undefined4 param_1);  // 0x15870
undefined8 ENABLE_ALL_CONTROL_ACTIONS__guess(undefined4 param_1);  // 0x15890
undefined8 SET_PLAYER_CONTROL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x158b0
undefined8 PLAYER_ID_158e0(void);  // 0x158e0
undefined8 FUN_000158f0(undefined4 param_1);  // 0x158f0
undefined8 FUN_00015910(uint param_1);  // 0x15910
undefined8 FUN_00015e20(long param_1,int param_2,int param_3,undefined8 param_4);  // 0x15e20
undefined8 _0x3ED1438C1F5C6612__guess(void);  // 0x15f20
undefined8 FUN_00015f30(void);  // 0x15f30
undefined8 FUN_00015f80(undefined1 *param_1,int param_2,long param_3,int param_4);  // 0x15f80
undefined8 FUN_00016050(void);  // 0x16050
undefined8 DISPLAY_ONSCREEN_KEYBOARD(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined4 param_8);  // 0x16070
undefined8 menu_monitor_buttons(void);  // 0x160e0
undefined8 BEGIN_TEXT_COMMAND_DISPLAY_HELP(undefined8 param_1);  // 0x16720
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME_16740(undefined8 param_1);  // 0x16740
undefined8 END_TEXT_COMMAND_DISPLAY_HELP(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x16760
undefined8 FUN_000167a0(void);  // 0x167a0
undefined8 FUN_00016840(void);  // 0x16840
undefined1 FUN_000168a0(void);  // 0x168a0
undefined8 FUN_00016cf0(void);  // 0x16cf0
bool FUN_00016e20(undefined4 param_1);  // 0x16e20
undefined8 FUN_00016e50(void);  // 0x16e50
undefined8 FUN_00016fc0(void);  // 0x16fc0
undefined1 FUN_000174b0(long *param_1);  // 0x174b0
undefined8 FUN_00017550(undefined8 param_1);  // 0x17550
undefined8 FUN_00017580(void);  // 0x17580
undefined8 FUN_000177d0(void);  // 0x177d0
undefined8 FUN_00017830(void);  // 0x17830
undefined1 FUN_00017890(int param_1,byte param_2);  // 0x17890
bool FUN_00017d40(undefined4 param_1);  // 0x17d40
undefined8 FUN_00017d70(void);  // 0x17d70
ulong FUN_00017da0(undefined4 param_1);  // 0x17da0
undefined8 FUN_00017e50(void);  // 0x17e50
undefined8 CLEAR_HELP__guess(undefined4 param_1);  // 0x18110
undefined8 UPDATE_ONSCREEN_KEYBOARD(void);  // 0x18130
undefined8 GET_ONSCREEN_KEYBOARD_RESULT(void);  // 0x18140
undefined4 FUN_00018150(char *param_1,undefined1 *param_2);  // 0x18150
float FUN_00018320(char *param_1,undefined1 *param_2);  // 0x18320
undefined8 DISABLE_CONTROL_ACTION_18540(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x18540
undefined8 SET_INPUT_EXCLUSIVE(undefined4 param_1,undefined4 param_2);  // 0x18570
undefined8 IS_DISABLED_CONTROL_JUST_PRESSED(undefined4 param_1,undefined4 param_2);  // 0x185a0
undefined8 PLAY_SOUND_FRONTEND(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4);  // 0x185d0
int FUN_00018610(int param_1,int param_2);  // 0x18610
int FUN_000186a0(float param_1,float param_2);  // 0x186a0
undefined8 FUN_000187b0(int param_1,undefined8 param_2,ulong param_3);  // 0x187b0
bool FUN_00018800(void);  // 0x18800
undefined8 IS_DISABLED_CONTROL_PRESSED_18890(undefined4 param_1,undefined4 param_2);  // 0x18890
undefined8 invoke_p_issssssi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, undefined4 param_9);  // 0x188c0
undefined8 invoke_s_void(undefined8 param_1);  // 0x18950
undefined8 invoke_p_issi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined4 param_5);  // 0x18980
undefined8 FUN_000189e0(void);  // 0x189e0
undefined8 FUN_000189f0(undefined8 param_1);  // 0x189f0
int FUN_00018c30(undefined *param_1);  // 0x18c30
undefined8 FUN_00018ca0(long param_1);  // 0x18ca0
undefined8 FUN_00018cf0(long param_1);  // 0x18cf0
undefined8 FUN_00018d40(byte param_1);  // 0x18d40
undefined8 PLAYER_PED_ID_18e80(void);  // 0x18e80
undefined8 DOES_ENTITY_EXIST_18e90(undefined4 param_1);  // 0x18e90
undefined8 FREEZE_ENTITY_POSITION(undefined4 param_1,undefined4 param_2);  // 0x18eb0
undefined8 menu_ipl_tick(void);  // 0x18ee0
int FUN_00018fe0(long param_1);  // 0x18fe0
undefined8 _LOAD_INTERIOR__guess(undefined4 param_1);  // 0x19070
undefined8 FUN_00019090(long param_1);  // 0x19090
undefined8 FUN_000192c0(long param_1);  // 0x192c0
undefined * menu_ipl_options(void);  // 0x19360
undefined8 FUN_00019380(void);  // 0x19380
undefined8 menu_ipl_count(void);  // 0x19470
undefined8 IS_IPL_ACTIVE__guess(undefined8 param_1);  // 0x19480
undefined8 REQUEST_IPL(undefined8 param_1);  // 0x194a0
undefined8 _0x95A7DABDDBB78AE7__guess(undefined8 param_1,undefined4 param_2);  // 0x194c0
undefined8 SET_WIDESCREEN_FORMAT__guess(undefined4 param_1);  // 0x194f0
undefined8 SET_GAME_PAUSES_FOR_STREAMING__guess(undefined4 param_1);  // 0x19510
undefined8 FUN_00019530(undefined4 param_1);  // 0x19530
undefined8 _0x228E5C6AD4D74BFD__guess(undefined4 param_1);  // 0x19560
undefined8 SET_SCENARIO_GROUP_ENABLED__guess(undefined8 param_1,undefined4 param_2);  // 0x19580
undefined8 SET_AUDIO_FLAG__guess(undefined8 param_1,undefined4 param_2);  // 0x195b0
undefined8 SET_AMBIENT_ZONE_LIST_STATE_PERSISTENT__guess(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x195e0
undefined8 SET_ZONE_ENABLED__guess(undefined4 param_1,undefined4 param_2);  // 0x19610
undefined8 GET_ZONE_FROM_NAME_ID__guess(undefined8 param_1);  // 0x19640
undefined8 _RESET_CURRENT_INTENSITY__guess(void);  // 0x19660
undefined8 FUN_00019670(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x19670
undefined8 REFRESH_INTERIOR__guess_2(undefined4 param_1);  // 0x196b0
undefined8 _IS_INTERIOR_PROP_ENABLED__guess(undefined4 param_1,undefined4 param_2);  // 0x196d0
undefined8 DISABLE_INTERIOR__guess(undefined4 param_1,undefined4 param_2);  // 0x19700
undefined8 _0x405DC2AEF6AF95B9__guess_19730(undefined4 param_1);  // 0x19730
undefined8 SET_INTERIOR_ACTIVE__guess_19750(undefined4 param_1,undefined4 param_2);  // 0x19750
undefined8 FUN_00019780(int param_1,long param_2,int param_3);  // 0x19780
undefined8 _ENABLE_INTERIOR_PROP__guess(undefined4 param_1,undefined8 param_2);  // 0x19820
undefined8 REFRESH_INTERIOR__guess(undefined4 param_1);  // 0x19850
undefined8 FUN_00019870(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x19870
undefined8 SET_ENTITY_IS_TARGET_PRIORITY__guess_198b0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x198b0
undefined8 FUN_000198e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x198e0
undefined8 invoke_p_si(undefined8 param_1,undefined8 param_2,undefined4 param_3);  // 0x19920
undefined8 invoke_p_sii(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x19970
undefined8 invoke_p_is(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0x199c0
undefined4 menu_maps_count(void);  // 0x19a10
undefined * menu_maps_options(void);  // 0x19a20
undefined8 FUN_00019a30(void);  // 0x19a30
undefined8 FUN_00019a40(void);  // 0x19a40
undefined8 menu_maps_unload(void);  // 0x19ae0
undefined8 FUN_00019b80(void);  // 0x19b80
undefined8 DOES_ENTITY_EXIST_19bd0(undefined4 param_1);  // 0x19bd0
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY(undefined4 param_1);  // 0x19bf0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_19c10(undefined4 param_1);  // 0x19c10
undefined8 SET_ENTITY_AS_MISSION_ENTITY_19c30(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x19c30
undefined8 DELETE_OBJECT_19c60(undefined8 param_1);  // 0x19c60
undefined8 menu_maps_load(char *param_1);  // 0x19c80
char * FUN_00019f20(char *param_1,char *param_2);  // 0x19f20
bool FUN_0001a080(char *param_1);  // 0x1a080
undefined1 FUN_0001a180(long param_1,undefined *param_2);  // 0x1a180
undefined8 FUN_0001a7d0(void);  // 0x1a7d0
undefined8 menu_maps_tick(void);  // 0x1abe0
undefined8 IS_MODEL_IN_CDIMAGE_1ae40(undefined4 param_1);  // 0x1ae40
undefined8 IS_MODEL_VALID_1ae60(undefined4 param_1);  // 0x1ae60
undefined8 REQUEST_MODEL_1ae80(undefined4 param_1);  // 0x1ae80
undefined8 HAS_MODEL_LOADED_1aea0(undefined4 param_1);  // 0x1aea0
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_1aec0(undefined4 param_1);  // 0x1aec0
undefined8 FUN_0001aee0(undefined4 *param_1);  // 0x1aee0
undefined8 FUN_0001b0b0(void);  // 0x1b0b0
undefined1 FUN_0001b0f0(undefined8 param_1);  // 0x1b0f0
undefined8 FUN_0001b220(char *param_1,char *param_2);  // 0x1b220
undefined8 FUN_0001b260(undefined8 param_1,char *param_2);  // 0x1b260
undefined1 FUN_0001b410(undefined8 param_1,undefined8 param_2,undefined4 *param_3);  // 0x1b410
undefined1 FUN_0001b4a0(undefined8 param_1,undefined8 param_2,undefined4 *param_3);  // 0x1b4a0
bool FUN_0001b530(long param_1,long param_2,void *param_3,int param_4);  // 0x1b530
undefined4 FUN_0001b7f0(char *param_1);  // 0x1b7f0
undefined1 FUN_0001b880(undefined8 param_1,undefined8 param_2,undefined1 *param_3);  // 0x1b880
undefined8 GET_HASH_KEY_1b970(undefined8 param_1);  // 0x1b970
undefined8 FUN_0001b990(void);  // 0x1b990
undefined8 FUN_0001ba10(void);  // 0x1ba10
undefined8 FUN_0001ba70(void);  // 0x1ba70
undefined8 FUN_0001bac0(void);  // 0x1bac0
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess(undefined4 param_1);  // 0x1bb10
undefined8 FUN_0001bb30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1bb30
undefined8 FUN_0001bb80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1bb80
undefined8 PED_TO_NET__guess_1bbd0(undefined4 param_1);  // 0x1bbd0
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_1bbf0(undefined4 param_1);  // 0x1bbf0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2_1bc10(undefined4 param_1,undefined4 param_2);  // 0x1bc10
undefined8 FUN_0001bc40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1bc40
undefined8 SET_ENTITY_VISIBLE(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x1bc90
undefined8 FREEZE_ENTITY_POSITION_1bcc0(undefined4 param_1,undefined4 param_2);  // 0x1bcc0
undefined8 SET_OBJECT_TINT_INDEX(undefined4 param_1,undefined4 param_2);  // 0x1bcf0
undefined8 FUN_0001bd20(undefined4 param_1);  // 0x1bd20
undefined8 invoke_i_ifffiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x1be00
undefined8 invoke_p_ifffii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1be90
undefined8 FUN_0001bf10(void);  // 0x1bf10
undefined8 FUN_0001c070(void);  // 0x1c070
long FUN_0001c980(undefined8 param_1);  // 0x1c980
bool FUN_0001cb60(char *param_1);  // 0x1cb60
undefined8 menu_netevents_tick(void);  // 0x1cc10
undefined8 FUN_0001cdd0(void);  // 0x1cdd0
undefined8 NETWORK_IS_PLAYER_ACTIVE_1cf60(undefined4 param_1);  // 0x1cf60
undefined8 GET_PLAYER_NAME(undefined4 param_1);  // 0x1cf80
undefined8 FUN_0001cfa0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1cfa0
undefined8 FUN_0001cff0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1cff0
undefined8 FUN_0001d040(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d040
undefined8 FUN_0001d0a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d0a0
undefined8 FUN_0001d100(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d100
undefined8 FUN_0001d160(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d160
undefined8 FUN_0001d1c0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d1c0
undefined8 FUN_0001d220(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d220
undefined8 FUN_0001d280(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d280
undefined8 FUN_0001d2e0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d2e0
undefined8 FUN_0001d340(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d340
undefined8 FUN_0001d3a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d3a0
undefined8 FUN_0001d400(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d400
undefined8 FUN_0001d460(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d460
undefined8 FUN_0001d4c0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d4c0
undefined8 FUN_0001d520(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d520
undefined8 FUN_0001d580(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x1d580
uint FUN_0001d6e0(long param_1);  // 0x1d6e0
undefined1 FUN_0001d740(long param_1);  // 0x1d740
undefined8 FUN_0001d7f0(long param_1,undefined4 param_2);  // 0x1d7f0
undefined1 FUN_0001d850(short param_1);  // 0x1d850
undefined8 FUN_0001d900(long param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1d900
long FUN_0001db30(char *param_1);  // 0x1db30
undefined8 FUN_0001dc30(void);  // 0x1dc30
undefined8 FUN_0001dc40(void);  // 0x1dc40
undefined8 PLAYER_PED_ID_1dc50(void);  // 0x1dc50
undefined8 DOES_ENTITY_EXIST_1dc60(undefined4 param_1);  // 0x1dc60
undefined8 PLAYER_ID_1dc80(void);  // 0x1dc80
undefined8 IS_PED_IN_ANY_VEHICLE_1dc90(undefined4 param_1,undefined4 param_2);  // 0x1dc90
undefined8 NETWORK_GET_ENTITY_FROM_NETWORK_ID__guess(undefined4 param_1);  // 0x1dcc0
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_1dce0(undefined4 param_1);  // 0x1dce0
undefined8 GET_VEHICLE_PED_IS_IN_1dd00(undefined4 param_1,undefined4 param_2);  // 0x1dd00
undefined8 menu_objects_spawn_count(void);  // 0x1dd30
undefined * menu_objects_spawn_options(void);  // 0x1dd40
undefined4 menu_objects_manage_count(void);  // 0x1dd50
undefined * menu_objects_manage_options(void);  // 0x1dd60
undefined8 FUN_0001dd70(void);  // 0x1dd70
undefined8 FUN_0001dd80(void);  // 0x1dd80
undefined4 menu_objects_edit_count(void);  // 0x1e170
undefined * menu_objects_edit_options(void);  // 0x1e180
char * FUN_0001e190(void);  // 0x1e190
undefined8 FUN_0001e1a0(int param_1);  // 0x1e1a0
undefined8 FUN_0001e210(void);  // 0x1e210
undefined8 FUN_0001e330(void);  // 0x1e330
undefined8 FUN_0001e440(void);  // 0x1e440
undefined8 FUN_0001e5c0(undefined1 *param_1);  // 0x1e5c0
undefined4 FUN_0001e640(void);  // 0x1e640
undefined8 FUN_0001e6a0(undefined4 param_1);  // 0x1e6a0
undefined8 FREEZE_ENTITY_POSITION_1e6e0(undefined4 param_1,undefined4 param_2);  // 0x1e6e0
undefined8 FUN_0001e710(void);  // 0x1e710
undefined8 FUN_0001e720(void);  // 0x1e720
undefined8 menu_spawn_object(char *param_1);  // 0x1e800
undefined8 GET_HASH_KEY_1e8c0(undefined8 param_1);  // 0x1e8c0
undefined8 IS_MODEL_IN_CDIMAGE_1e8e0(undefined4 param_1);  // 0x1e8e0
undefined8 IS_MODEL_VALID_1e900(undefined4 param_1);  // 0x1e900
undefined8 REQUEST_MODEL_1e920(undefined4 param_1);  // 0x1e920
undefined8 menu_spawn_object_tick(void);  // 0x1e940
undefined8 HAS_MODEL_LOADED_1ebd0(undefined4 param_1);  // 0x1ebd0
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_1ebf0(undefined4 param_1);  // 0x1ebf0
undefined8 PLAYER_PED_ID_1ec10(void);  // 0x1ec10
undefined8 DOES_ENTITY_EXIST_1ec20(undefined4 param_1);  // 0x1ec20
undefined8 FUN_0001ec40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x1ec40
undefined8 GET_ENTITY_HEADING_1ec90(undefined4 param_1);  // 0x1ec90
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_1ecb0(undefined4 param_1);  // 0x1ecb0
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_4(undefined4 param_1);  // 0x1ecd0
undefined8 FUN_0001ecf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1ecf0
undefined8 FUN_0001ed40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1ed40
undefined8 PED_TO_NET__guess_1ed90(undefined4 param_1);  // 0x1ed90
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_1edb0(undefined4 param_1);  // 0x1edb0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2_1edd0(undefined4 param_1,undefined4 param_2);  // 0x1edd0
undefined8 SET_ENTITY_AS_MISSION_ENTITY_1ee00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x1ee00
undefined8 FUN_0001ee30(undefined4 param_1,undefined4 param_2);  // 0x1ee30
undefined8 PLACE_OBJECT_ON_GROUND_PROPERLY__guess(undefined4 param_1);  // 0x1ee60
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_1ee80(undefined4 param_1);  // 0x1ee80
undefined8 FUN_0001eea0(undefined4 param_1,char *param_2);  // 0x1eea0
char * FUN_0001f060(char *param_1);  // 0x1f060
undefined8 FUN_0001f160(void);  // 0x1f160
undefined8 FUN_0001f1c0(void);  // 0x1f1c0
undefined8 DELETE_OBJECT_1f270(undefined8 param_1);  // 0x1f270
undefined8 FUN_0001f290(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x1f290
undefined8 FUN_0001f2c0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x1f2c0
undefined8 FUN_0001f350(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7);  // 0x1f350
undefined8 FUN_0001f410(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x1f410
undefined8 FUN_0001f4a0(void);  // 0x1f4a0
undefined8 FUN_0001f4e0(void);  // 0x1f4e0
undefined8 FUN_0001f5b0(void);  // 0x1f5b0
undefined8 FUN_0001f610(void);  // 0x1f610
undefined8 FUN_0001f680(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x1f680
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_1f6d0(undefined4 param_1);  // 0x1f6d0
bool FUN_0001f6f0(char *param_1,char *param_2);  // 0x1f6f0
undefined8 invoke_p_ifffiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x1f830
undefined8 invoke_v3_ifff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined4 param_6);  // 0x1f8c0
undefined4 menu_peds_spawn_count(void);  // 0x1f940
undefined8 FUN_0001f960(void);  // 0x1f960
undefined8 * menu_peds_spawn_options(void);  // 0x1fa90
undefined4 menu_peds_manage_count(void);  // 0x1fab0
undefined * menu_peds_manage_options(void);  // 0x1fac0
undefined8 FUN_0001fad0(void);  // 0x1fad0
undefined8 FUN_0001fae0(void);  // 0x1fae0
undefined4 menu_peds_edit_count(void);  // 0x1fed0
undefined * menu_peds_edit_options(void);  // 0x1fee0
undefined * FUN_0001fef0(void);  // 0x1fef0
undefined8 FUN_0001ff00(int param_1);  // 0x1ff00
undefined8 FUN_00020020(void);  // 0x20020
undefined8 FUN_000201d0(void);  // 0x201d0
undefined8 FUN_00020370(undefined1 *param_1);  // 0x20370
undefined4 FUN_00020490(void);  // 0x20490
undefined8 FUN_000204f0(undefined4 param_1,byte param_2);  // 0x204f0
undefined8 FUN_000205c0(undefined4 param_1);  // 0x205c0
undefined8 FREEZE_ENTITY_POSITION_20600(undefined4 param_1,undefined4 param_2);  // 0x20600
undefined8 FUN_00020630(undefined4 param_1);  // 0x20630
undefined8 FUN_00020760(undefined4 param_1);  // 0x20760
undefined8 menu_spawn_ped(char *param_1);  // 0x207c0
undefined8 GET_HASH_KEY_20880(undefined8 param_1);  // 0x20880
undefined8 IS_MODEL_IN_CDIMAGE_208a0(undefined4 param_1);  // 0x208a0
undefined8 IS_MODEL_VALID_208c0(undefined4 param_1);  // 0x208c0
undefined8 REQUEST_MODEL_208e0(undefined4 param_1);  // 0x208e0
undefined8 menu_spawn_ped_tick(void);  // 0x20900
undefined8 HAS_MODEL_LOADED_20b80(undefined4 param_1);  // 0x20b80
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_20ba0(undefined4 param_1);  // 0x20ba0
undefined8 PLAYER_PED_ID_20bc0(void);  // 0x20bc0
undefined8 DOES_ENTITY_EXIST_20bd0(undefined4 param_1);  // 0x20bd0
undefined8 FUN_00020bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x20bf0
undefined8 GET_ENTITY_HEADING_20c40(undefined4 param_1);  // 0x20c40
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_2(undefined4 param_1);  // 0x20c60
undefined8 CAN_REGISTER_MISSION_OBJECTS__guess(undefined4 param_1);  // 0x20c80
undefined8 FUN_00020ca0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x20ca0
undefined8 VEH_TO_NET__guess(undefined4 param_1);  // 0x20d00
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_20d20(undefined4 param_1);  // 0x20d20
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2_20d40(undefined4 param_1,undefined4 param_2);  // 0x20d40
undefined8 SET_ENTITY_AS_MISSION_ENTITY_20d70(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x20d70
undefined8 SET_PED_DEFAULT_COMPONENT_VARIATION__guess(undefined4 param_1);  // 0x20da0
undefined8 SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(undefined4 param_1,undefined4 param_2);  // 0x20dc0
undefined8 SET_PED_KEEP_TASK__guess(undefined4 param_1,undefined4 param_2);  // 0x20df0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_20e20(undefined4 param_1);  // 0x20e20
undefined8 FUN_00020e40(undefined4 param_1,undefined *param_2);  // 0x20e40
char * FUN_00021080(char *param_1);  // 0x21080
undefined8 menu_peds_tick(void);  // 0x21270
undefined8 FUN_00021300(void);  // 0x21300
undefined8 FUN_00021360(void);  // 0x21360
undefined8 DELETE_PED_21410(undefined8 param_1);  // 0x21410
undefined8 IS_ENTITY_DEAD_21430(undefined4 param_1,undefined4 param_2);  // 0x21430
undefined8 IS_PED_DEAD_OR_DYING__guess_21460(undefined4 param_1,undefined4 param_2);  // 0x21460
undefined8 FUN_00021490(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x21490
undefined8 FUN_00021520(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x21520
undefined8 FUN_000215b0(void);  // 0x215b0
undefined8 FUN_00021660(void);  // 0x21660
undefined8 FUN_000216d0(void);  // 0x216d0
undefined8 FUN_00021730(void);  // 0x21730
undefined8 FUN_00021780(void);  // 0x21780
undefined8 FUN_000217d0(void);  // 0x217d0
undefined8 FUN_00021820(void);  // 0x21820
undefined8 FUN_00021870(void);  // 0x21870
undefined8 FUN_000218c0(void);  // 0x218c0
undefined8 FUN_00021910(void);  // 0x21910
undefined8 FUN_00021960(void);  // 0x21960
undefined8 FUN_000219d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x219d0
undefined8 FUN_00021a20(undefined4 param_1,undefined4 param_2);  // 0x21a20
undefined8 CLEAR_PED_TASKS_IMMEDIATELY(undefined4 param_1);  // 0x21a50
undefined8 TASK_STAND_STILL(undefined4 param_1,undefined4 param_2);  // 0x21a70
undefined8 CLEAR_PED_TASKS(undefined4 param_1);  // 0x21aa0
undefined8 FUN_00021ac0(undefined4 param_1,long param_2);  // 0x21ac0
undefined8 GIVE_WEAPON_TO_PED_21b40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x21b40
undefined8 SET_CURRENT_PED_WEAPON_21b80(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x21b80
undefined8 SET_ENTITY_INVINCIBLE(undefined4 param_1,undefined4 param_2);  // 0x21bb0
undefined8 SET_ENTITY_PROOFS(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x21be0
undefined8 SET_ENTITY_CAN_BE_DAMAGED__guess(undefined4 param_1,undefined4 param_2);  // 0x21c50
undefined8 SET_PED_CAN_RAGDOLL(undefined4 param_1,undefined4 param_2);  // 0x21c80
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_21cb0(undefined4 param_1);  // 0x21cb0
undefined8 PLAYER_ID_21cd0(void);  // 0x21cd0
undefined8 GET_PLAYER_GROUP_21ce0(undefined4 param_1);  // 0x21ce0
undefined8 SET_PED_AS_GROUP_MEMBER(undefined4 param_1,undefined4 param_2);  // 0x21d00
undefined8 SET_PED_NEVER_LEAVES_GROUP(undefined4 param_1,undefined4 param_2);  // 0x21d30
undefined8 SET_PED_CAN_BE_TARGETTED_BY_PLAYER__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x21d60
undefined8 SET_PED_COMBAT_ABILITY(undefined4 param_1,undefined4 param_2);  // 0x21d90
undefined8 SET_PED_COMBAT_RANGE__guess(undefined4 param_1,undefined4 param_2);  // 0x21dc0
undefined8 SET_PED_COMBAT_MOVEMENT__guess(undefined4 param_1,undefined4 param_2);  // 0x21df0
undefined8 SET_PED_COMBAT_ATTRIBUTES__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x21e20
undefined8 SET_PED_RELATIONSHIP_GROUP_HASH(undefined4 param_1,undefined4 param_2);  // 0x21e50
undefined8 GET_PED_RELATIONSHIP_GROUP_HASH(undefined4 param_1);  // 0x21e80
undefined8 ADD_ARMOUR_TO_PED__guess(undefined4 param_1,undefined4 param_2);  // 0x21ea0
undefined8 FUN_00021ed0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x21ed0
undefined8 REMOVE_PED_FROM_GROUP(undefined4 param_1);  // 0x21f00
undefined8 invoke_p_iiiiiiiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0x21f20
undefined8 invoke_p_ifi(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x21fb0
undefined8 invoke_i_iiffffii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x22000
undefined8 FUN_000220a0(void);  // 0x220a0
undefined8 NETWORK_IS_PLAYER_ACTIVE_222a0(undefined4 param_1);  // 0x222a0
undefined8 GET_PLAYER_NAME_222c0(undefined4 param_1);  // 0x222c0
undefined8 FUN_000222e0(char *param_1,int param_2,int param_3,char *param_4);  // 0x222e0
undefined8 FUN_000225e0(long param_1,int param_2,long param_3);  // 0x225e0
undefined4 menu_player_list_count(void);  // 0x22690
undefined * menu_player_list_options(void);  // 0x226a0
undefined4 menu_selected_player(void);  // 0x226b0
undefined8 FUN_00022710(int param_1);  // 0x22710
undefined4 menu_player_target(void);  // 0x227b0
char * FUN_000227c0(void);  // 0x227c0
undefined8 menu_player_selected_count(void);  // 0x227d0
undefined ** menu_player_selected_options(void);  // 0x227e0
undefined * FUN_000227f0(void);  // 0x227f0
undefined8 menu_players_tick(void);  // 0x22850
undefined8 FUN_00022890(void);  // 0x22890
undefined8 FUN_00022f00(void);  // 0x22f00
undefined8 FUN_00023190(void);  // 0x23190
undefined8 FUN_00023430(void);  // 0x23430
undefined8 FUN_000235b0(void);  // 0x235b0
undefined8 FUN_000237d0(void);  // 0x237d0
undefined8 FUN_00023a70(void);  // 0x23a70
undefined8 FUN_00023b50(void);  // 0x23b50
undefined * menu_player_drop_options(void);  // 0x23b60
undefined8 FUN_00023b70(void);  // 0x23b70
undefined * menu_player_vehicle_options(void);  // 0x23b80
undefined8 FUN_00023b90(void);  // 0x23b90
undefined ** menu_player_friendly_options(void);  // 0x23ba0
undefined8 FUN_00023bb0(void);  // 0x23bb0
undefined ** FUN_00023bc0(void);  // 0x23bc0
undefined8 FUN_00023bd0(void);  // 0x23bd0
undefined ** menu_player_kick_options(void);  // 0x23be0
undefined8 FUN_00023bf0(void *param_1,int param_2,undefined4 param_3);  // 0x23bf0
undefined8 FUN_00023d40(long param_1,int param_2,undefined4 param_3);  // 0x23d40
undefined8 FUN_00023dc0(int param_1,int param_2);  // 0x23dc0
undefined8 PLAYER_ID_23ef0(void);  // 0x23ef0
undefined4 FUN_00023f00(int param_1);  // 0x23f00
undefined8 FUN_00023f50(void);  // 0x23f50
undefined8 FUN_00024630(int param_1,char *param_2,char *param_3);  // 0x24630
undefined8 FUN_00025020(void);  // 0x25020
undefined8 FUN_00025030(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x25030
undefined8 FUN_00025090(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined *param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,int param_10);  // 0x25090
undefined8 FUN_000251c0(void);  // 0x251c0
undefined8 NETWORK_GET_HOST_PLAYER_INDEX(void);  // 0x251d0
undefined8 NETWORK_GET_HOST_OF_SCRIPT__guess_251e0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x251e0
undefined8 NETWORK_IS_HOST(void);  // 0x25210
undefined8 FUN_00025220(void);  // 0x25220
undefined8 FUN_000252c0(void);  // 0x252c0
undefined8 FUN_000253e0(void);  // 0x253e0
undefined4 FUN_00025510(void);  // 0x25510
undefined8 FUN_00025590(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x25590
undefined8 PLAYER_PED_ID_255c0(void);  // 0x255c0
undefined8 DOES_ENTITY_EXIST_255d0(undefined4 param_1);  // 0x255d0
undefined8 FUN_000255f0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x255f0
undefined8 FUN_00025630(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x25630
undefined8 GET_PLAYER_PED_25670(undefined4 param_1);  // 0x25670
undefined8 IS_PED_IN_ANY_VEHICLE_25690(undefined4 param_1,undefined4 param_2);  // 0x25690
undefined8 GET_VEHICLE_PED_IS_IN_256c0(undefined4 param_1,undefined4 param_2);  // 0x256c0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_256f0(undefined4 param_1);  // 0x256f0
undefined8 IS_VEHICLE_SEAT_FREE(undefined4 param_1,undefined4 param_2);  // 0x25710
undefined8 SET_PED_INTO_VEHICLE_25740(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25740
undefined8 FUN_00025770(undefined4 param_1);  // 0x25770
undefined8 GET_GAME_TIMER(void);  // 0x257d0
undefined8 FUN_000257e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x257e0
undefined8 GET_ENTITY_HEADING_25830(undefined4 param_1);  // 0x25830
undefined8 FUN_00025850(undefined8 param_1);  // 0x25850
undefined8 FUN_00025880(undefined4 param_1);  // 0x25880
undefined8 REQUEST_MODEL_258f0(undefined4 param_1);  // 0x258f0
undefined8 HAS_MODEL_LOADED_25910(undefined4 param_1);  // 0x25910
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_3_25930(undefined4 param_1);  // 0x25930
undefined8 CAN_REGISTER_MISSION_PEDS__guess(undefined4 param_1);  // 0x25950
undefined8 FUN_00025970(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x25970
undefined8 SET_ENTITY_AS_MISSION_ENTITY_259d0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x259d0
undefined8 SET_ENTITY_VISIBLE_25a00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25a00
undefined8 SET_ENTITY_COLLISION(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25a30
undefined8 FREEZE_ENTITY_POSITION_25a60(undefined4 param_1,undefined4 param_2);  // 0x25a60
undefined8 NETWORK_REGISTER_ENTITY_AS_NETWORKED__guess(undefined4 param_1);  // 0x25a90
undefined8 NETWORK_GET_ENTITY_FROM_NETWORK_ID__guess_25ab0(undefined4 param_1);  // 0x25ab0
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_25ad0(undefined4 param_1);  // 0x25ad0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_25af0(undefined4 param_1,undefined4 param_2);  // 0x25af0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2_25b20(undefined4 param_1,undefined4 param_2);  // 0x25b20
undefined8 _SET_NETWORK_ID_SYNC_TO_PLAYER__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25b50
undefined8 _SET_ENTITY_SOMETHING__guess(undefined4 param_1,undefined4 param_2);  // 0x25b80
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_25bb0(undefined4 param_1);  // 0x25bb0
undefined8 FUN_00025bd0(undefined4 param_1);  // 0x25bd0
undefined8 TASK_WARP_PED_INTO_VEHICLE__guess_25c40(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25c40
undefined8 GET_VEHICLE_MAX_NUMBER_OF_PASSENGERS__guess(undefined4 param_1);  // 0x25c70
undefined8 IS_VEHICLE_SEAT_FREE_25c90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x25c90
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_25cc0(undefined4 param_1);  // 0x25cc0
undefined8 FUN_00025ce0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x25ce0
undefined8 FUN_00025d30(undefined4 param_1,undefined4 param_2);  // 0x25d30
bool FUN_00025d60(undefined4 param_1);  // 0x25d60
undefined8 FUN_00025df0(byte param_1);  // 0x25df0
undefined8 FUN_00025eb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x25eb0
undefined8 NETWORK_REQUEST_CONTROL_OF_NETWORK_ID__guess(undefined4 param_1);  // 0x25f10
undefined8 FUN_00025f30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x25f30
undefined8 SET_OBJECT_AS_NO_LONGER_NEEDED__guess(undefined8 param_1);  // 0x25f90
undefined8 CLEAR_FOCUS_25fb0(void);  // 0x25fb0
undefined8 FUN_00025fc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x25fc0
undefined8 GET_HASH_KEY_26010(undefined8 param_1);  // 0x26010
int FUN_00026030(int param_1);  // 0x26030
undefined8 FUN_00026070(void);  // 0x26070
undefined8 FUN_000260b0(void);  // 0x260b0
undefined4 FUN_000260f0(void);  // 0x260f0
int FUN_00026260(void);  // 0x26260
undefined4 FUN_000262f0(void);  // 0x262f0
int FUN_000264b0(int param_1);  // 0x264b0
undefined8 FUN_00026500(void);  // 0x26500
int FUN_00026520(long param_1);  // 0x26520
undefined8 GET_WEAPONTYPE_MODEL__guess(undefined4 param_1);  // 0x265d0
undefined8 DOES_PICKUP_EXIST__guess_265f0(undefined4 param_1);  // 0x265f0
undefined8 DOES_PICKUP_OBJECT_EXIST__guess_26610(undefined4 param_1);  // 0x26610
undefined8 SET_TEAM_PICKUP_OBJECT__guess_26630(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x26630
undefined4 FUN_00026660(undefined4 param_1,undefined4 param_2,undefined4 param_3,float param_4);  // 0x26660
undefined8 REMOVE_PICKUP__guess(undefined4 param_1);  // 0x26770
undefined8 FUN_00026790(int param_1);  // 0x26790
int FUN_00026810(void);  // 0x26810
undefined8 NETWORK_GET_PLAYER_INDEX_FROM_PED__guess(undefined4 param_1);  // 0x26890
undefined1 FUN_000268b0(void);  // 0x268b0
undefined8 FUN_00026980(void);  // 0x26980
undefined8 FUN_000269c0(void);  // 0x269c0
undefined1 FUN_00026a80(void);  // 0x26a80
undefined8 FUN_00026b10(undefined4 param_1,int param_2);  // 0x26b10
undefined8 FUN_00026ca0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x26ca0
undefined8 FUN_00026cd0(void);  // 0x26cd0
undefined8 FUN_00026da0(void);  // 0x26da0
undefined8 _0x78857FC65CADB909__guess(undefined4 param_1);  // 0x26e30
undefined8 FUN_00026e50(undefined4 param_1);  // 0x26e50
undefined8 FUN_00026e80(undefined4 param_1);  // 0x26e80
undefined8 FUN_00026eb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4);  // 0x26eb0
undefined8 IS_PED_DEAD_OR_DYING__guess_26fe0(undefined4 param_1,undefined4 param_2);  // 0x26fe0
undefined8 IS_PLAYER_DEAD__guess(undefined4 param_1);  // 0x27010
undefined8 GET_ENTITY_HEALTH(undefined4 param_1);  // 0x27030
undefined8 HAS_ENTITY_BEEN_DAMAGED_BY_ANY_PED__guess(undefined4 param_1);  // 0x27050
undefined8 HAS_ENTITY_BEEN_DAMAGED_BY_ANY_VEHICLE__guess(undefined4 param_1);  // 0x27070
undefined8 HAS_PED_BEEN_DAMAGED_BY_WEAPON__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x27090
undefined8 CLEAR_ENTITY_LAST_DAMAGE_ENTITY__guess(undefined4 param_1);  // 0x270c0
undefined8 FUN_000270e0(void);  // 0x270e0
undefined8 FUN_000270f0(void);  // 0x270f0
undefined1 FUN_00027100(byte param_1);  // 0x27100
undefined1 FUN_00027260(undefined4 *param_1,undefined4 *param_2,float *param_3);  // 0x27260
undefined8 FUN_00027310(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, int param_5,undefined4 param_6,byte param_7,byte param_8);  // 0x27310
undefined1 FUN_000273f0(byte param_1);  // 0x273f0
undefined8 FUN_00027590(void);  // 0x27590
undefined8 FUN_000275e0(void);  // 0x275e0
undefined8 FUN_00027630(void);  // 0x27630
undefined8 FUN_00027680(void);  // 0x27680
undefined4 FUN_000276d0(void);  // 0x276d0
undefined8 FUN_00027750(void);  // 0x27750
undefined8 FUN_000277a0(void);  // 0x277a0
undefined8 FUN_000277f0(void);  // 0x277f0
undefined8 FUN_00027840(void);  // 0x27840
undefined8 FUN_00027880(int param_1);  // 0x27880
undefined8 FUN_00027900(void);  // 0x27900
undefined8 FUN_00027980(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x27980
undefined8 FUN_000279f0(void);  // 0x279f0
undefined8 FUN_00027a90(void);  // 0x27a90
undefined8 FUN_00027bc0(void);  // 0x27bc0
undefined8 FUN_00027c50(void);  // 0x27c50
undefined8 FUN_00027c90(void);  // 0x27c90
bool FUN_00027cd0(void);  // 0x27cd0
undefined8 _NETWORK_SESSION_IS_PLAYER_VOTED_TO_KICK__guess(undefined4 param_1);  // 0x27d30
undefined4 FUN_00027d50(int param_1);  // 0x27d50
undefined8 FUN_00027da0(int param_1,long param_2,int param_3);  // 0x27da0
undefined1 FUN_00027e60(int *param_1);  // 0x27e60
undefined8 FUN_00027ef0(undefined4 param_1,int param_2,undefined8 param_3);  // 0x27ef0
undefined8 GET_EVENT_DATA__guess_2(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x27f70
long FUN_00027fb0(void);  // 0x27fb0
bool FUN_00028150(char *param_1);  // 0x28150
undefined8 GET_ENTITY_MAX_HEALTH_28200(undefined4 param_1);  // 0x28200
undefined8 GET_ENTITY_HEIGHT_ABOVE_GROUND(undefined4 param_1);  // 0x28220
undefined8 FUN_00028240(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x28240
undefined4 FUN_000282a0(undefined8 param_1);  // 0x282a0
undefined8 FUN_00028300(int param_1,undefined8 param_2,ulong param_3);  // 0x28300
undefined8 STAT_GET_INT_28420(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x28420
undefined8 STAT_GET_FLOAT__guess(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x28450
undefined4 FUN_00028480(undefined4 param_1,undefined4 param_2);  // 0x28480
undefined4 FUN_000284e0(undefined4 param_1,undefined4 param_2);  // 0x284e0
bool FUN_00028570(float param_1);  // 0x28570
undefined8 NETWORK_GET_VC_WALLET_BALANCE(undefined4 param_1);  // 0x285d0
undefined8 NETWORK_GET_VC_BANK_BALANCE(void);  // 0x285f0
undefined8 FUN_00028600(char *param_1,int param_2,undefined8 param_3,uint param_4,byte param_5);  // 0x28600
undefined8 GET_PLAYER_WANTED_LEVEL(undefined4 param_1);  // 0x287b0
undefined8 GET_ENTITY_MODEL_287d0(undefined4 param_1);  // 0x287d0
char * FUN_000287f0(byte param_1);  // 0x287f0
undefined1 FUN_00028820(int param_1,undefined4 param_2,byte param_3);  // 0x28820
undefined8 IS_PED_ARMED__guess(undefined4 param_1,undefined4 param_2);  // 0x289d0
undefined8 FUN_00028a00(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x28a00
char * FUN_00028ac0(char *param_1);  // 0x28ac0
undefined8 FUN_00028b90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x28b90
undefined8 FUN_00028bd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5);  // 0x28bd0
undefined8 GET_STREET_NAME_FROM_HASH_KEY__guess(undefined4 param_1);  // 0x28c20
undefined8 NETWORK_PLAYER_HAS_HEADSET(undefined4 param_1);  // 0x28c40
int FUN_00028c60(void);  // 0x28c60
int FUN_00028cb0(int param_1,int param_2);  // 0x28cb0
int FUN_00028d10(void);  // 0x28d10
undefined8 GET_PLAYER_INVINCIBLE__guess(undefined4 param_1);  // 0x28e20
undefined8 NETWORK_IS_PLAYER_IN_MP_CUTSCENE__guess(undefined4 param_1);  // 0x28e40
undefined8 SET_OBJECT_AS_NO_LONGER_NEEDED__guess_2(undefined4 param_1);  // 0x28e60
undefined8 SET_ENTITY_QUATERNION__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, undefined8 param_9);  // 0x28e80
undefined8 GET_DISPLAY_NAME_FROM_VEHICLE_MODEL_28f00(undefined4 param_1);  // 0x28f00
undefined8 DOES_TEXT_LABEL_EXIST__guess(undefined8 param_1);  // 0x28f20
undefined8 _GET_LABEL_TEXT__guess_28f40(undefined8 param_1);  // 0x28f40
undefined8 SET_TEXT_FONT_28f60(undefined4 param_1);  // 0x28f60
undefined8 FUN_00028f80(undefined4 param_1,undefined4 param_2);  // 0x28f80
undefined8 SET_TEXT_COLOUR_28fb0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x28fb0
undefined8 SET_TEXT_CENTRE_28ff0(undefined4 param_1);  // 0x28ff0
undefined8 SET_TEXT_RIGHT_JUSTIFY_29010(undefined4 param_1);  // 0x29010
undefined8 FUN_00029030(undefined4 param_1,undefined4 param_2);  // 0x29030
undefined8 SET_TEXT_DROPSHADOW_29060(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x29060
undefined8 SET_TEXT_OUTLINE_290a0(void);  // 0x290a0
undefined8 BEGIN_TEXT_COMMAND_DISPLAY_TEXT_290b0(undefined8 param_1);  // 0x290b0
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME_290d0(undefined8 param_1);  // 0x290d0
undefined8 FUN_000290f0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x290f0
undefined8 invoke_i_iib(undefined8 param_1,undefined4 param_2,undefined4 param_3,byte param_4);  // 0x29130
undefined8 invoke_f_ffffff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7);  // 0x29190
undefined8 invoke_p_ipiii(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5);  // 0x29220
undefined8 invoke_i_ipfi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0x29280
undefined8 invoke_i_ipipipipipipipipi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, undefined8 param_9,undefined8 param_10);  // 0x292d0
undefined8 invoke_s_fff(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0x29370
undefined8 invoke_p_fffpipi(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0x293d0
int menu_properties_list_count(void);  // 0x29450
undefined8 FUN_00029470(void);  // 0x29470
undefined * menu_properties_list_options(void);  // 0x296d0
undefined8 FUN_000296f0(void);  // 0x296f0
undefined8 FUN_00029700(undefined4 param_1);  // 0x29700
undefined8 FUN_00029730(void);  // 0x29730
int menu_properties_garage_count(void);  // 0x29dc0
undefined * menu_properties_garage_options(void);  // 0x29de0
undefined * FUN_00029e00(void);  // 0x29e00
undefined8 FUN_00029e10(int param_1);  // 0x29e10
byte FUN_00029f00(void);  // 0x29f00
undefined8 FUN_00029f20(void);  // 0x29f20
byte FUN_00029f30(void);  // 0x29f30
undefined8 FUN_00029f50(void);  // 0x29f50
undefined1 FUN_00029f60(char *param_1);  // 0x29f60
undefined8 GET_HASH_KEY_2a120(undefined8 param_1);  // 0x2a120
undefined8 IS_MODEL_IN_CDIMAGE_2a140(undefined4 param_1);  // 0x2a140
undefined8 IS_MODEL_A_VEHICLE_2a160(undefined4 param_1);  // 0x2a160
undefined1 FUN_0002a180(void);  // 0x2a180
undefined8 FUN_0002a2b0(void);  // 0x2a2b0
undefined8 FUN_0002a2c0(undefined4 param_1);  // 0x2a2c0
undefined8 FUN_0002a300(void);  // 0x2a300
undefined8 FUN_0002a310(void);  // 0x2a310
undefined8 FUN_0002a320(void);  // 0x2a320
undefined8 FUN_0002a440(void);  // 0x2a440
int FUN_0002a7f0(void);  // 0x2a7f0
undefined8 FUN_0002a860(int param_1,undefined4 param_2,int param_3);  // 0x2a860
undefined8 FUN_0002a8e0(int param_1,undefined4 param_2,int param_3);  // 0x2a8e0
undefined8 FUN_0002a930(uint param_1,long param_2,undefined4 param_3);  // 0x2a930
undefined4 FUN_0002a9c0(int param_1,int param_2);  // 0x2a9c0
undefined8 FUN_0002aa50(void);  // 0x2aa50
undefined8 FUN_0002ab70(void);  // 0x2ab70
bool FUN_0002ab80(int param_1);  // 0x2ab80
int FUN_0002aba0(int param_1);  // 0x2aba0
int FUN_0002ad70(undefined4 param_1);  // 0x2ad70
int FUN_0002aeb0(int param_1);  // 0x2aeb0
char * FUN_0002b080(undefined4 param_1);  // 0x2b080
undefined * FUN_0002b2e0(int param_1);  // 0x2b2e0
int FUN_0002b360(undefined4 param_1,undefined4 param_2,int param_3,int param_4);  // 0x2b360
undefined8 FUN_0002b4c0(int param_1,char *param_2,undefined4 param_3,int param_4,undefined4 param_5, byte param_6);  // 0x2b4c0
undefined1 FUN_0002b8d0(void);  // 0x2b8d0
undefined1 FUN_0002b930(int param_1);  // 0x2b930
undefined4 FUN_0002b990(void);  // 0x2b990
undefined8 FUN_0002ba90(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x2ba90
undefined4 FUN_0002bb60(long param_1);  // 0x2bb60
undefined4 FUN_0002bc00(int param_1);  // 0x2bc00
undefined8 STAT_GET_INT_2bc50(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x2bc50
int FUN_0002bc80(void);  // 0x2bc80
undefined8 PLAYER_ID_2bcd0(void);  // 0x2bcd0
int FUN_0002bce0(int param_1);  // 0x2bce0
int FUN_0002beb0(void);  // 0x2beb0
int FUN_0002bf80(int param_1);  // 0x2bf80
undefined1 FUN_0002c0e0(void);  // 0x2c0e0
int FUN_0002c1e0(int param_1);  // 0x2c1e0
char * FUN_0002c270(undefined4 param_1);  // 0x2c270
bool FUN_0002c4d0(int param_1);  // 0x2c4d0
bool FUN_0002c500(int param_1);  // 0x2c500
bool FUN_0002c520(int param_1);  // 0x2c520
int FUN_0002c5a0(undefined4 param_1);  // 0x2c5a0
int FUN_0002c5f0(undefined4 param_1);  // 0x2c5f0
undefined4 FUN_0002c690(int param_1);  // 0x2c690
undefined1 FUN_0002c710(int param_1);  // 0x2c710
undefined1 FUN_0002c810(int param_1);  // 0x2c810
byte FUN_0002c890(int param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5);  // 0x2c890
byte FUN_0002c920(float param_1,float param_2);  // 0x2c920
undefined8 FUN_0002c980(undefined8 *param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4);  // 0x2c980
undefined1 FUN_0002ca50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2ca50
int FUN_0002ccc0(undefined4 param_1,int param_2);  // 0x2ccc0
byte FUN_0002cd30(int param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x2cd30
int FUN_0002cff0(int param_1,int param_2,int param_3);  // 0x2cff0
undefined4 FUN_0002d070(int param_1);  // 0x2d070
undefined8 STAT_SAVE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2d0f0
undefined1 FUN_0002d120(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d120
undefined1 FUN_0002d250(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d250
undefined1 FUN_0002d3e0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d3e0
undefined1 FUN_0002d680(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d680
undefined1 FUN_0002d840(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d840
undefined1 FUN_0002d9d0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2d9d0
undefined1 FUN_0002db20(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x2db20
undefined1 FUN_0002dc30(int param_1,undefined4 *param_2,undefined4 *param_3,float *param_4);  // 0x2dc30
undefined1 FUN_0002dd40(float param_1,float param_2,float param_3);  // 0x2dd40
undefined8 FUN_0002de30(long param_1,undefined4 param_2);  // 0x2de30
undefined8 STAT_SET_INT_2dea0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2dea0
undefined8 _0xBED9F5693F34ED17__guess_2_2ded0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2ded0
undefined8 menu_anti_lockon_tick(void);  // 0x2df00
undefined8 PLAYER_PED_ID_2df50(void);  // 0x2df50
undefined8 DOES_ENTITY_EXIST_2df60(undefined4 param_1);  // 0x2df60
undefined8 FUN_0002df80(undefined4 param_1);  // 0x2df80
undefined8 FUN_0002e010(int param_1);  // 0x2e010
undefined8 menu_protections_tick(void);  // 0x2e050
undefined8 FUN_0002e120(void);  // 0x2e120
undefined8 IS_ENTITY_DEAD_2e1f0(undefined4 param_1,undefined4 param_2);  // 0x2e1f0
undefined8 FUN_0002e220(void);  // 0x2e220
undefined8 FUN_0002e8d0(undefined4 param_1);  // 0x2e8d0
undefined8 FUN_0002eb50(undefined4 param_1);  // 0x2eb50
undefined8 FUN_0002ebe0(undefined4 param_1);  // 0x2ebe0
undefined8 FUN_0002ec90(void);  // 0x2ec90
undefined8 FUN_0002ed70(int param_1);  // 0x2ed70
undefined8 FUN_0002ef00(undefined4 param_1);  // 0x2ef00
undefined8 FUN_0002f260(undefined4 param_1);  // 0x2f260
undefined8 FUN_0002f460(undefined4 param_1);  // 0x2f460
undefined8 FUN_0002f5e0(undefined4 param_1);  // 0x2f5e0
undefined8 SET_PED_CAN_BE_TARGETTED(undefined4 param_1,undefined4 param_2);  // 0x2f900
undefined8 SET_PED_CONFIG_FLAG(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2f930
undefined8 FUN_0002f960(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x2f960
undefined8 IS_PED_IN_ANY_VEHICLE_2f990(undefined4 param_1,undefined4 param_2);  // 0x2f990
undefined8 GET_VEHICLE_PED_IS_IN_2f9c0(undefined4 param_1,undefined4 param_2);  // 0x2f9c0
undefined8 SET_VEHICLE_CAN_BE_TARGETTED__guess(undefined4 param_1,undefined4 param_2);  // 0x2f9f0
undefined8 GET_HASH_KEY_2fa20(undefined8 param_1);  // 0x2fa20
undefined8 FUN_0002fa40(long param_1,int *param_2,int param_3,char *param_4);  // 0x2fa40
bool FUN_0002fae0(void);  // 0x2fae0
undefined8 FUN_0002fb60(int param_1);  // 0x2fb60
undefined8 GET_NUMBER_OF_EVENTS__guess(undefined4 param_1);  // 0x2fc20
int FUN_0002fc40(void);  // 0x2fc40
undefined4 FUN_0002fcc0(void);  // 0x2fcc0
undefined8 PLAYER_ID_2fd20(void);  // 0x2fd20
undefined8 GET_EVENT_AT_INDEX__guess(undefined4 param_1,undefined4 param_2);  // 0x2fd30
undefined8 GET_EVENT_DATA__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0x2fd60
undefined1 FUN_0002fda0(int param_1);  // 0x2fda0
undefined8 NETWORK_IS_PLAYER_ACTIVE_2fe00(undefined4 param_1);  // 0x2fe00
undefined8 FUN_0002fe20(char *param_1,int param_2);  // 0x2fe20
undefined8 NETWORK_IS_SESSION_STARTED_2ff00(void);  // 0x2ff00
undefined8 NETWORK_IS_GAME_IN_PROGRESS_2ff10(void);  // 0x2ff10
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_2ff20(undefined4 param_1);  // 0x2ff20
char * FUN_0002ff40(int param_1);  // 0x2ff40
undefined8 GET_PLAYER_NAME_2ffe0(undefined4 param_1);  // 0x2ffe0
undefined8 NETWORK_GET_ENTITY_FROM_NETWORK_ID__guess_30000(undefined4 param_1);  // 0x30000
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_30020(undefined4 param_1);  // 0x30020
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_30040(undefined4 param_1,undefined4 param_2);  // 0x30040
undefined8 NETWORK_HAS_CONTROL_OF_NETWORK_ID__guess(undefined4 param_1);  // 0x30070
undefined8 NETWORK_REQUEST_CONTROL_OF_NETWORK_ID__guess_30090(undefined4 param_1);  // 0x30090
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_300b0(undefined4 param_1);  // 0x300b0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_300d0(undefined4 param_1);  // 0x300d0
undefined8 _0x7D6F9A3EF26136A0__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x300f0
undefined8 _0x7D6F9A3EF26136A0__guess_2(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30120
undefined8 FUN_00030150(undefined4 param_1);  // 0x30150
undefined8 SET_PED_CAN_BE_TARGETTED_BY_PLAYER__guess_30240(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30240
undefined8 FUN_00030270(void);  // 0x30270
undefined8 FUN_00030280(undefined4 param_1);  // 0x30280
undefined8 DESTROY_MOBILE_PHONE__guess(void);  // 0x302a0
bool FUN_000302b0(undefined4 param_1);  // 0x302b0
undefined8 IS_ENTITY_ATTACHED_TO_ANY_PED__guess(undefined4 param_1);  // 0x30310
undefined8 GET_ENTITY_ATTACHED_TO__guess(undefined4 param_1);  // 0x30330
undefined8 GET_ENTITY_TYPE__guess_30350(undefined4 param_1);  // 0x30350
undefined8 NETWORK_GET_PLAYER_INDEX_FROM_PED__guess_30370(undefined4 param_1);  // 0x30370
undefined8 FUN_00030390(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x30390
undefined8 FUN_000303c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x303c0
undefined8 DETACH_ENTITY(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30420
undefined8 IS_PED_IN_PARACHUTE_FREE_FALL__guess(undefined4 param_1);  // 0x30450
undefined8 GET_PED_PARACHUTE_STATE(undefined4 param_1);  // 0x30470
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_2_30490(void);  // 0x30490
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_304a0(void);  // 0x304a0
undefined8 GET_ENTITY_SPEED(undefined4 param_1);  // 0x304b0
undefined8 FUN_000304d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x304d0
undefined8 FUN_00030520(undefined4 param_1);  // 0x30520
undefined8 FUN_000305c0(float param_1,undefined4 param_2,undefined4 *param_3,long param_4,int param_5, byte param_6);  // 0x305c0
undefined8 IS_ENTITY_ATTACHED_TO_ANY_OBJECT__guess(undefined4 param_1);  // 0x30910
int FUN_00030930(undefined4 param_1);  // 0x30930
bool FUN_00030a30(undefined4 param_1);  // 0x30a30
undefined8 HAS_PLAYER_LEFT_THE_WORLD__guess(undefined4 param_1);  // 0x30bb0
undefined8 HAS_PLAYER_LEFT_THE_WORLD__guess_2(undefined4 param_1);  // 0x30bd0
undefined1 FUN_00030bf0(int param_1);  // 0x30bf0
undefined8 CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE__guess(undefined4 param_1);  // 0x30cb0
undefined8 CLEAR_PLAYER_PARACHUTE_VARIATION_OVERRIDE__guess_2(undefined4 param_1);  // 0x30cd0
undefined8 CLEAR_PLAYER_PARACHUTE_MODEL_OVERRIDE__guess(undefined4 param_1);  // 0x30cf0
undefined8 IS_PLAYER_RIDING_TRAIN__guess(undefined4 param_1);  // 0x30d10
undefined8 IS_MODEL_VALID_30d30(undefined4 param_1);  // 0x30d30
undefined8 IS_MODEL_IN_CDIMAGE_30d50(undefined4 param_1);  // 0x30d50
undefined1 FUN_00030d70(int param_1,long param_2,int param_3);  // 0x30d70
undefined8 FUN_00030e00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x30e00
undefined8 IS_ENTITY_TOUCHING_MODEL__guess(undefined4 param_1,undefined4 param_2);  // 0x30e60
undefined8 IS_ENTITY_ATTACHED_TO_ENTITY(undefined4 param_1,undefined4 param_2);  // 0x30e90
undefined8 IS_ENTITY_TOUCHING_ENTITY__guess(undefined4 param_1,undefined4 param_2);  // 0x30ec0
undefined8 NETWORK_GET_ENTITY_IS_NETWORKED(undefined4 param_1);  // 0x30ef0
undefined8 IS_ENTITY_A_MISSION_ENTITY__guess(undefined4 param_1);  // 0x30f10
undefined8 GET_NEAREST_PLAYER_TO_ENTITY__guess(undefined4 param_1);  // 0x30f30
undefined8 SET_ENTITY_COLLISION_30f50(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30f50
undefined8 _SET_ENTITY_COLLISION_2__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30f80
undefined8 FREEZE_ENTITY_POSITION_30fb0(undefined4 param_1,undefined4 param_2);  // 0x30fb0
undefined8 SET_ENTITY_VISIBLE_30fe0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x30fe0
undefined8 SET_ENTITY_AS_MISSION_ENTITY_31010(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x31010
undefined8 DELETE_OBJECT_31040(undefined8 param_1);  // 0x31040
undefined8 DELETE_ENTITY_31060(undefined8 param_1);  // 0x31060
undefined8 SET_ENTITY_PROOFS_31080(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x31080
undefined8 SET_ENTITY_INVINCIBLE_310f0(undefined4 param_1,undefined4 param_2);  // 0x310f0
undefined8 SET_PLAYER_INVINCIBLE(undefined4 param_1,undefined4 param_2);  // 0x31120
undefined8 SET_ENTITY_CAN_BE_DAMAGED__guess_31150(undefined4 param_1,undefined4 param_2);  // 0x31150
undefined8 SET_ENTITY_QUATERNION__guess_31180(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, undefined8 param_9);  // 0x31180
undefined8 invoke_p_iif(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x31200
undefined8 invoke_i_iipii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x31250
undefined8 invoke_i_ffffiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x312b0
undefined8 FUN_00031350(void);  // 0x31350
int FUN_00031360(void);  // 0x31360
undefined8 FUN_000313d0(char *param_1,undefined4 param_2);  // 0x313d0
undefined8 FUN_00031420(uint param_1,undefined8 param_2,undefined4 param_3);  // 0x31420
undefined8 FUN_00031480(char *param_1,byte param_2);  // 0x31480
undefined8 FUN_000314d0(uint param_1,undefined8 param_2,byte param_3);  // 0x314d0
undefined8 menu_recovery_mp_save(void);  // 0x31540
undefined8 FUN_00031550(void);  // 0x31550
undefined8 FUN_00031590(void);  // 0x31590
undefined8 FUN_000315a0(void);  // 0x315a0
undefined8 FUN_000315b0(void);  // 0x315b0
undefined8 FUN_000315c0(void);  // 0x315c0
undefined8 FUN_00031620(void);  // 0x31620
undefined8 menu_recovery_tick(void);  // 0x31660
bool FUN_000328c0(void);  // 0x328c0
undefined8 NETWORK_IS_SESSION_STARTED_32900(void);  // 0x32900
undefined8 NETWORK_IS_GAME_IN_PROGRESS_32910(void);  // 0x32910
undefined8 FUN_00032920(void);  // 0x32920
undefined8 FUN_00032940(void);  // 0x32940
undefined8 FUN_00032970(void);  // 0x32970
undefined8 FUN_00032c70(void);  // 0x32c70
undefined8 FUN_00032de0(void);  // 0x32de0
undefined8 FUN_00032f90(void);  // 0x32f90
undefined8 FUN_00032fe0(void);  // 0x32fe0
undefined8 FUN_00033010(void);  // 0x33010
undefined8 FUN_00033030(void);  // 0x33030
undefined8 FUN_00033110(void);  // 0x33110
undefined8 FUN_00033410(void);  // 0x33410
undefined8 FUN_00033510(void);  // 0x33510
byte FUN_00033530(void);  // 0x33530
undefined8 FUN_00033580(undefined4 param_1,byte param_2);  // 0x33580
undefined8 FUN_00033640(uint param_1,undefined8 param_2,undefined4 param_3);  // 0x33640
undefined8 FUN_000336a0(undefined4 param_1,undefined4 param_2);  // 0x336a0
undefined8 PLAYER_ID_336d0(void);  // 0x336d0
undefined4 FUN_000336e0(uint param_1,undefined8 param_2);  // 0x336e0
undefined4 FUN_00033740(uint param_1,undefined8 param_2);  // 0x33740
undefined8 FUN_000337a0(void);  // 0x337a0
undefined8 FUN_00033940(undefined4 param_1);  // 0x33940
byte FUN_000339f0(undefined8 param_1);  // 0x339f0
undefined8 FUN_00033a70(char *param_1);  // 0x33a70
bool FUN_00033ae0(long param_1,int param_2,int *param_3);  // 0x33ae0
bool FUN_00033be0(long param_1,int param_2,int *param_3);  // 0x33be0
bool FUN_00033ce0(long param_1,int param_2,int *param_3);  // 0x33ce0
bool FUN_00033dd0(long param_1,int param_2,int *param_3);  // 0x33dd0
bool FUN_00033ec0(int *param_1);  // 0x33ec0
bool FUN_00033f80(int *param_1);  // 0x33f80
undefined8 FUN_00034040(undefined4 param_1,byte param_2);  // 0x34040
undefined8 FUN_00034360(void);  // 0x34360
undefined8 FUN_000343a0(int *param_1);  // 0x343a0
undefined8 FUN_000344f0(undefined4 param_1,byte param_2);  // 0x344f0
undefined8 PLAYER_PED_ID_34630(void);  // 0x34630
undefined8 DOES_ENTITY_EXIST_34640(undefined4 param_1);  // 0x34640
undefined8 GET_NUM_DLC_WEAPONS__guess_34660(void);  // 0x34660
undefined4 FUN_00034670(undefined4 param_1);  // 0x34670
undefined8 GIVE_WEAPON_TO_PED_346d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x346d0
undefined8 FUN_00034710(undefined4 param_1,byte param_2);  // 0x34710
undefined1 FUN_00034a60(long param_1,int param_2,int *param_3);  // 0x34a60
undefined8 FUN_00034b50(undefined4 param_1,byte param_2);  // 0x34b50
undefined8 FUN_00034d00(undefined4 param_1,long param_2,int param_3,byte param_4);  // 0x34d00
undefined8 FUN_00034d80(byte param_1);  // 0x34d80
undefined8 FUN_00034e30(byte param_1);  // 0x34e30
undefined8 FUN_00034f00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x34f00
undefined8 FUN_00034f40(undefined4 param_1,byte param_2);  // 0x34f40
undefined4 FUN_00034fe0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x34fe0
undefined8 _STAT_SET_PROFILE_SETTING__guess(undefined4 param_1,undefined4 param_2);  // 0x35040
undefined8 FUN_00035070(void);  // 0x35070
byte FUN_000350e0(undefined8 param_1);  // 0x350e0
undefined8 FUN_00035110(undefined4 param_1);  // 0x35110
undefined8 FUN_000351a0(undefined4 param_1);  // 0x351a0
undefined8 FUN_00035260(void);  // 0x35260
int FUN_00035570(int param_1,undefined8 param_2);  // 0x35570
undefined8 STAT_GET_INT_35660(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x35660
undefined8 GET_HASH_KEY_35690(undefined8 param_1);  // 0x35690
undefined8 FUN_000356b0(void);  // 0x356b0
undefined1 FUN_00035730(uint param_1,int *param_2,int *param_3,int *param_4);  // 0x35730
undefined1 FUN_00035870(uint param_1,int *param_2,uint *param_3,uint *param_4);  // 0x35870
undefined8 FUN_00035980(int param_1,int *param_2,uint *param_3,int *param_4);  // 0x35980
undefined8 FUN_00035b40(void);  // 0x35b40
bool FUN_00035b80(void);  // 0x35b80
undefined8 FUN_00035ba0(int param_1,byte param_2);  // 0x35ba0
undefined8 FUN_00035c60(void);  // 0x35c60
undefined8 FUN_00035cd0(void);  // 0x35cd0
undefined8 FUN_00035cf0(void);  // 0x35cf0
undefined8 FUN_00035d30(void);  // 0x35d30
undefined8 FUN_00035d50(void);  // 0x35d50
undefined8 FUN_00035d80(long param_1,int param_2);  // 0x35d80
undefined8 FUN_00035de0(void);  // 0x35de0
undefined8 FUN_00035e20(undefined4 param_1,byte param_2);  // 0x35e20
undefined8 FUN_00035f40(void);  // 0x35f40
undefined8 FUN_00035f70(void);  // 0x35f70
undefined8 FUN_00035fa0(void);  // 0x35fa0
undefined8 FUN_00035fd0(void);  // 0x35fd0
undefined8 FUN_00036010(void);  // 0x36010
undefined8 FUN_00036070(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8);  // 0x36070
undefined8 FUN_000360e0(void);  // 0x360e0
undefined8 FUN_00036110(void);  // 0x36110
undefined8 FUN_00036170(void);  // 0x36170
undefined8 FUN_000361e0(undefined4 param_1,byte param_2);  // 0x361e0
undefined8 FUN_00036280(void);  // 0x36280
undefined8 FUN_000362e0(void);  // 0x362e0
undefined8 FUN_00036340(void);  // 0x36340
undefined8 FUN_000363a0(void);  // 0x363a0
undefined8 FUN_00036400(void);  // 0x36400
undefined8 FUN_00036460(void);  // 0x36460
undefined8 FUN_00036520(void);  // 0x36520
undefined8 FUN_00036550(void);  // 0x36550
undefined8 FUN_000365b0(void);  // 0x365b0
undefined8 FUN_00036610(void);  // 0x36610
undefined8 FUN_00036670(void);  // 0x36670
undefined8 FUN_000366a0(undefined4 param_1,byte param_2);  // 0x366a0
undefined8 FUN_00036810(void);  // 0x36810
undefined8 FUN_00036870(void);  // 0x36870
undefined8 FUN_000368a0(void);  // 0x368a0
undefined8 FUN_00036900(void);  // 0x36900
undefined8 FUN_00036960(void);  // 0x36960
undefined8 FUN_000369c0(void);  // 0x369c0
undefined8 FUN_00036a20(void);  // 0x36a20
undefined8 FUN_00036a80(void);  // 0x36a80
undefined8 FUN_00036ae0(void);  // 0x36ae0
undefined8 FUN_00036b40(void);  // 0x36b40
undefined8 FUN_00036ba0(void);  // 0x36ba0
undefined8 FUN_00036c00(void);  // 0x36c00
undefined8 FUN_00036c60(void);  // 0x36c60
undefined8 FUN_00036cc0(void);  // 0x36cc0
undefined8 FUN_00036d20(void);  // 0x36d20
undefined8 FUN_00036d50(undefined4 param_1,byte param_2);  // 0x36d50
undefined8 FUN_00036e60(void);  // 0x36e60
undefined8 FUN_00036ea0(undefined4 param_1,long param_2,int param_3);  // 0x36ea0
undefined8 FUN_00036f10(void);  // 0x36f10
undefined8 FUN_000370a0(void);  // 0x370a0
undefined4 FUN_00037160(int param_1);  // 0x37160
undefined8 FUN_00037210(undefined8 param_1,undefined4 param_2);  // 0x37210
undefined8 FUN_00037240(void);  // 0x37240
undefined8 FUN_000372d0(void);  // 0x372d0
bool FUN_00037350(int param_1,undefined4 param_2,int *param_3,int *param_4,int *param_5);  // 0x37350
undefined8 FUN_000374f0(void);  // 0x374f0
undefined8 FUN_00037700(void);  // 0x37700
undefined8 FUN_00037720(int param_1,int param_2,int param_3,byte param_4);  // 0x37720
undefined8 FUN_00037820(void);  // 0x37820
undefined8 FUN_00037850(void);  // 0x37850
undefined8 FUN_00037880(void);  // 0x37880
undefined8 FUN_000378c0(void);  // 0x378c0
undefined8 FUN_00037920(void);  // 0x37920
undefined8 FUN_000379b0(void);  // 0x379b0
undefined8 FUN_00037a70(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x37a70
undefined8 FUN_00037aa0(void);  // 0x37aa0
undefined8 FUN_00037b40(void);  // 0x37b40
undefined8 FUN_00037ba0(void);  // 0x37ba0
undefined8 FUN_00037bc0(undefined8 param_1);  // 0x37bc0
undefined8 FUN_00037bf0(void);  // 0x37bf0
undefined8 FUN_00037c10(void);  // 0x37c10
undefined8 FUN_00037c30(void);  // 0x37c30
undefined8 FUN_00037c50(void);  // 0x37c50
undefined8 FUN_00037c70(void);  // 0x37c70
undefined8 FUN_00037c90(void);  // 0x37c90
undefined8 FUN_00037cb0(void);  // 0x37cb0
undefined8 FUN_00037df0(void);  // 0x37df0
undefined8 FUN_00037e10(void);  // 0x37e10
undefined8 FUN_00037e50(void);  // 0x37e50
undefined8 FUN_00037e90(void);  // 0x37e90
undefined8 FUN_00037f00(void);  // 0x37f00
undefined8 FUN_00037f20(undefined4 param_1);  // 0x37f20
undefined8 FUN_00037fa0(void);  // 0x37fa0
undefined8 FUN_00037fd0(long param_1,int param_2);  // 0x37fd0
undefined8 FUN_00038020(void);  // 0x38020
undefined8 FUN_00038060(void);  // 0x38060
undefined8 FUN_00038090(void);  // 0x38090
undefined8 FUN_000380c0(void);  // 0x380c0
undefined8 FUN_000380f0(void);  // 0x380f0
undefined8 FUN_00038130(void);  // 0x38130
undefined8 FUN_00038190(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8);  // 0x38190
undefined8 FUN_00038200(void);  // 0x38200
undefined8 FUN_00038230(void);  // 0x38230
undefined8 FUN_00038290(void);  // 0x38290
undefined8 FUN_00038300(void);  // 0x38300
undefined8 FUN_00038360(void);  // 0x38360
undefined8 FUN_000383c0(void);  // 0x383c0
undefined8 FUN_00038420(void);  // 0x38420
undefined8 FUN_00038480(void);  // 0x38480
undefined8 FUN_000384e0(void);  // 0x384e0
undefined8 FUN_00038510(void);  // 0x38510
undefined8 FUN_00038570(void);  // 0x38570
undefined8 FUN_000385d0(void);  // 0x385d0
undefined8 FUN_00038630(void);  // 0x38630
undefined8 FUN_00038660(void);  // 0x38660
undefined8 FUN_000386a0(void);  // 0x386a0
undefined8 _0xCA94551B50B4932C__guess(undefined4 param_1);  // 0x38720
undefined8 FUN_00038740(void);  // 0x38740
undefined4 * FUN_000387d0(void);  // 0x387d0
undefined * FUN_000387e0(void);  // 0x387e0
undefined8 FUN_00038830(void);  // 0x38830
undefined8 FUN_00038870(void);  // 0x38870
undefined8 FUN_00038950(char *param_1);  // 0x38950
undefined1 FUN_000389b0(int *param_1,int *param_2);  // 0x389b0
undefined8 FUN_00038c00(void);  // 0x38c00
undefined8 FUN_00038c40(void);  // 0x38c40
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_38e60(undefined4 param_1);  // 0x38e60
undefined8 FUN_00038e80(void);  // 0x38e80
undefined8 FUN_00038ec0(byte param_1,byte param_2);  // 0x38ec0
byte FUN_00038fb0(undefined4 param_1);  // 0x38fb0
undefined8 FUN_00039020(void);  // 0x39020
undefined8 FUN_00039060(void);  // 0x39060
undefined8 FUN_000390a0(void);  // 0x390a0
undefined8 FUN_000390e0(void);  // 0x390e0
undefined8 STAT_SET_INT_39120(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x39120
undefined8 STAT_SET_BOOL(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x39150
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess(void);  // 0x39180
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess_2(void);  // 0x39190
undefined8 STAT_LOAD_PENDING__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x391a0
undefined8 TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME__guess(undefined8 param_1);  // 0x391e0
bool FUN_00039200(void);  // 0x39200
undefined8 NETWORK_IS_SESSION_BUSY(void);  // 0x39270
undefined8 GET_PLAYER_SWITCH_STATE__guess_39280(void);  // 0x39280
undefined8 FUN_00039290(void);  // 0x39290
undefined8 FUN_00039340(long *param_1);  // 0x39340
bool FUN_00039400(int param_1);  // 0x39400
bool FUN_00039490(undefined4 param_1);  // 0x39490
undefined4 FUN_000394d0(void);  // 0x394d0
undefined8 FUN_00039510(void);  // 0x39510
undefined4 FUN_00039520(undefined4 param_1);  // 0x39520
char * FUN_00039560(void);  // 0x39560
bool FUN_000395c0(undefined4 param_1,int param_2);  // 0x395c0
bool FUN_00039620(ulong param_1);  // 0x39620
undefined8 FUN_00039680(undefined4 param_1);  // 0x39680
undefined8 FUN_000396f0(void);  // 0x396f0
undefined8 FUN_00039830(undefined4 param_1,uint param_2,undefined8 param_3);  // 0x39830
undefined8 FUN_00039890(undefined4 param_1,uint param_2,undefined8 param_3);  // 0x39890
undefined8 FUN_000398f0(uint param_1,undefined8 param_2,int param_3);  // 0x398f0
undefined8 FUN_000399f0(long *param_1,int param_2,int param_3,int param_4,int param_5,int param_6, int param_7,int param_8);  // 0x399f0
undefined8 STAT_SET_DATE__guess(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x39a70
undefined8 STAT_GET_FLOAT__guess_39ab0(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x39ab0
undefined8 _0xF434A10BA01C37D0__guess_39ae0(undefined4 param_1);  // 0x39ae0
undefined8 FUN_00039b00(undefined4 param_1,byte param_2);  // 0x39b00
undefined1 FUN_00039be0(long param_1,int param_2,int *param_3);  // 0x39be0
undefined8 _0xBED9F5693F34ED17__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x39cd0
undefined8 FUN_00039d00(undefined8 param_1,byte param_2);  // 0x39d00
undefined8 FUN_00039d40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x39d40
undefined8 STAT_SAVE__guess_39d90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x39d90
undefined8 FUN_00039dc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,byte param_4);  // 0x39dc0
undefined8 FUN_00039e20(undefined4 param_1,byte param_2);  // 0x39e20
undefined8 _0xBED9F5693F34ED17__guess_2_39f20(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x39f20
undefined8 SET_PED_AMMO_39f50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x39f50
undefined8 GET_DLC_WEAPON_DATA__guess_39f90(undefined4 param_1,undefined8 param_2);  // 0x39f90
undefined8 FUN_00039fc0(undefined4 param_1,byte param_2);  // 0x39fc0
undefined8 FUN_0003a090(undefined4 param_1,byte param_2);  // 0x3a090
undefined8 FUN_0003a3f0(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x3a3f0
undefined8 FUN_0003a430(undefined4 param_1,undefined8 param_2,int param_3,undefined4 param_4);  // 0x3a430
undefined8 FUN_0003a4b0(undefined4 param_1,char *param_2,uint param_3,byte param_4);  // 0x3a4b0
undefined8 FUN_0003a570(int param_1,byte param_2,undefined4 param_3);  // 0x3a570
undefined8 STAT_GET_MASKED_INT__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5);  // 0x3a6a0
undefined8 FUN_0003a6e0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3a6e0
undefined8 FUN_0003a750(void);  // 0x3a750
undefined8 GET_INTERIOR_GROUP_ID__guess_3_3a820(undefined4 param_1);  // 0x3a820
undefined8 _LOAD_INTERIOR__guess_3a840(undefined4 param_1);  // 0x3a840
undefined8 _ENABLE_INTERIOR_PROP__guess_3(undefined4 param_1,undefined8 param_2);  // 0x3a860
undefined8 _ENABLE_INTERIOR_PROP__guess_2(undefined4 param_1,undefined8 param_2);  // 0x3a890
undefined8 REFRESH_INTERIOR__guess_3a8c0(undefined4 param_1);  // 0x3a8c0
undefined8 STAT_GET_DATE__guess(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x3a8e0
undefined8 FUN_0003a920(undefined4 param_1,long param_2,int param_3);  // 0x3a920
undefined8 FUN_0003a990(long param_1,int param_2);  // 0x3a990
undefined8 FUN_0003a9f0(long param_1,int param_2);  // 0x3a9f0
undefined4 FUN_0003aa60(undefined8 *param_1,uint param_2);  // 0x3aa60
undefined8 STAT_GET_LICENSE_PLATE__guess(undefined4 param_1);  // 0x3aad0
undefined8 STAT_GET_LICENSE_PLATE__guess_2(undefined4 param_1);  // 0x3aaf0
undefined8 STAT_GET_LICENSE_PLATE__guess_3(undefined4 param_1);  // 0x3ab10
undefined8 STAT_DELETE_SLOT__guess(undefined4 param_1);  // 0x3ab30
undefined8 FUN_0003ab50(undefined4 param_1);  // 0x3ab50
undefined8 FUN_0003abd0(undefined4 param_1);  // 0x3abd0
undefined8 FUN_0003ac50(undefined4 param_1,undefined4 param_2);  // 0x3ac50
undefined8 FUN_0003ac80(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x3ac80
int FUN_0003ae00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3ae00
uint FUN_0003ae30(int param_1,int param_2,uint param_3,uint param_4,uint param_5,uint param_6);  // 0x3ae30
undefined8 FUN_0003afb0(undefined4 param_1,undefined4 param_2,undefined8 param_3,byte param_4);  // 0x3afb0
int FUN_0003b030(int param_1,int param_2,int param_3);  // 0x3b030
undefined8 FUN_0003b100(int param_1,uint param_2,uint param_3,uint param_4,byte param_5);  // 0x3b100
undefined4 FUN_0003b210(undefined4 param_1,int param_2,int param_3,int param_4,byte param_5);  // 0x3b210
undefined8 FUN_0003b3a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x3b3a0
undefined8 FUN_0003b3f0(undefined4 param_1,long param_2,int param_3);  // 0x3b3f0
undefined8 FUN_0003b450(undefined4 param_1,long param_2,int param_3);  // 0x3b450
undefined8 FUN_0003b4b0(long param_1,int param_2);  // 0x3b4b0
undefined8 FUN_0003b500(long param_1,int param_2);  // 0x3b500
undefined8 FUN_0003b550(void);  // 0x3b550
undefined8 FUN_0003b5f0(void);  // 0x3b5f0
undefined8 FUN_0003b750(int param_1);  // 0x3b750
undefined1 FUN_0003b7c0(undefined8 param_1,int param_2,int param_3,int param_4,int param_5,int *param_6, int *param_7);  // 0x3b7c0
bool FUN_0003b890(char *param_1);  // 0x3b890
undefined8 invoke_i_iiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x3b8f0
undefined8 invoke_i_ipiii(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5);  // 0x3b950
undefined8 invoke_i_iiiis(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined8 param_6);  // 0x3b9b0
undefined8 invoke_i_ifi(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x3ba20
char * FUN_0003ba70(void);  // 0x3ba70
char * FUN_0003bad0(void);  // 0x3bad0
undefined * FUN_0003bb30(void);  // 0x3bb30
undefined * FUN_0003bb90(int param_1);  // 0x3bb90
undefined * FUN_0003bbe0(void);  // 0x3bbe0
undefined * FUN_0003bc40(void);  // 0x3bc40
undefined * FUN_0003bca0(void);  // 0x3bca0
undefined * FUN_0003bd00(void);  // 0x3bd00
undefined * FUN_0003bd60(void);  // 0x3bd60
undefined * FUN_0003bdc0(void);  // 0x3bdc0
undefined8 FUN_0003be20(void);  // 0x3be20
bool FUN_0003be60(void);  // 0x3be60
undefined8 FUN_0003beb0(void);  // 0x3beb0
undefined8 FUN_0003bf50(void);  // 0x3bf50
undefined8 STAT_SET_INT_3bfb0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3bfb0
undefined8 GET_HASH_KEY_3bfe0(undefined8 param_1);  // 0x3bfe0
undefined8 FUN_0003c000(void);  // 0x3c000
bool FUN_0003c070(undefined8 param_1);  // 0x3c070
undefined8 FUN_0003c0a0(byte param_1,undefined8 param_2,undefined8 param_3);  // 0x3c0a0
byte FUN_0003c160(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x3c160
undefined8 FUN_0003c1a0(void);  // 0x3c1a0
undefined8 FUN_0003c210(void);  // 0x3c210
byte FUN_0003c280(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x3c280
undefined8 FUN_0003c2c0(void);  // 0x3c2c0
undefined8 FUN_0003c330(void);  // 0x3c330
undefined8 FUN_0003c3f0(void);  // 0x3c3f0
undefined8 FUN_0003c520(void);  // 0x3c520
undefined8 FUN_0003c570(void);  // 0x3c570
undefined8 FUN_0003c5e0(void);  // 0x3c5e0
undefined8 FUN_0003c650(void);  // 0x3c650
byte FUN_0003c700(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0x3c700
undefined8 FUN_0003c740(void);  // 0x3c740
undefined8 STAT_GET_INT_3c880(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x3c880
undefined8 FUN_0003c8b0(void);  // 0x3c8b0
undefined8 FUN_0003c920(void);  // 0x3c920
undefined8 FUN_0003c950(byte param_1,undefined4 param_2);  // 0x3c950
undefined8 FUN_0003cb00(void);  // 0x3cb00
undefined8 FUN_0003cb30(void);  // 0x3cb30
undefined8 FUN_0003cba0(void);  // 0x3cba0
undefined8 FUN_0003cc10(void);  // 0x3cc10
undefined8 FUN_0003ccb0(void);  // 0x3ccb0
undefined8 FUN_0003ccf0(void);  // 0x3ccf0
undefined8 FUN_0003cd30(void);  // 0x3cd30
undefined8 FUN_0003ce20(void);  // 0x3ce20
undefined8 FUN_0003cec0(void);  // 0x3cec0
undefined8 FUN_0003cef0(undefined8 param_1,undefined4 param_2);  // 0x3cef0
undefined8 FUN_0003cf60(void);  // 0x3cf60
undefined8 FUN_0003d000(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, int param_5);  // 0x3d000
undefined8 FUN_0003d110(void);  // 0x3d110
undefined8 FUN_0003d180(void);  // 0x3d180
undefined8 FUN_0003d1d0(void);  // 0x3d1d0
undefined8 FUN_0003d280(void);  // 0x3d280
undefined8 FUN_0003d2b0(undefined4 param_1);  // 0x3d2b0
undefined8 FUN_0003d300(void);  // 0x3d300
undefined8 FUN_0003d330(void);  // 0x3d330
undefined8 FUN_0003d340(void);  // 0x3d340
undefined8 FUN_0003d3b0(void);  // 0x3d3b0
undefined8 FUN_0003d420(void);  // 0x3d420
undefined8 FUN_0003d490(void);  // 0x3d490
undefined8 FUN_0003d540(void);  // 0x3d540
undefined8 FUN_0003d5b0(void);  // 0x3d5b0
undefined8 FUN_0003d680(void);  // 0x3d680
undefined8 FUN_0003d6c0(void);  // 0x3d6c0
undefined8 FUN_0003d710(void);  // 0x3d710
undefined8 FUN_0003d780(void);  // 0x3d780
undefined8 FUN_0003d860(void);  // 0x3d860
undefined8 FUN_0003d8c0(void);  // 0x3d8c0
undefined8 FUN_0003d900(void);  // 0x3d900
byte FUN_0003d9a0(undefined8 param_1,undefined4 param_2);  // 0x3d9a0
undefined8 FUN_0003d9f0(void);  // 0x3d9f0
undefined8 FUN_0003da40(void);  // 0x3da40
undefined8 FUN_0003dac0(void);  // 0x3dac0
undefined8 FUN_0003daf0(void);  // 0x3daf0
undefined8 FUN_0003dbd0(void);  // 0x3dbd0
undefined8 FUN_0003dc50(void);  // 0x3dc50
undefined8 FUN_0003dcc0(void);  // 0x3dcc0
undefined8 FUN_0003dd50(void);  // 0x3dd50
undefined8 FUN_0003dda0(void);  // 0x3dda0
undefined8 FUN_0003dde0(void);  // 0x3dde0
undefined8 FUN_0003de50(void);  // 0x3de50
undefined8 FUN_0003de90(void);  // 0x3de90
undefined8 FUN_0003ded0(void);  // 0x3ded0
undefined8 FUN_0003df40(void);  // 0x3df40
undefined8 FUN_0003dfa0(void);  // 0x3dfa0
undefined8 FUN_0003dfe0(void);  // 0x3dfe0
undefined8 FUN_0003e020(void);  // 0x3e020
undefined8 FUN_0003e090(void);  // 0x3e090
undefined8 FUN_0003e0d0(void);  // 0x3e0d0
undefined8 FUN_0003e140(void);  // 0x3e140
undefined8 FUN_0003e170(void);  // 0x3e170
undefined8 FUN_0003e1b0(void);  // 0x3e1b0
undefined8 FUN_0003e200(void);  // 0x3e200
undefined8 FUN_0003e270(void);  // 0x3e270
undefined8 FUN_0003e2e0(void);  // 0x3e2e0
undefined8 FUN_0003e3b0(void);  // 0x3e3b0
undefined8 FUN_0003e420(void);  // 0x3e420
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_3e4e0(undefined4 param_1);  // 0x3e4e0
undefined4 FUN_0003e500(int param_1);  // 0x3e500
int FUN_0003e540(void);  // 0x3e540
undefined8 PLAYER_ID_3e580(void);  // 0x3e580
undefined8 FUN_0003e590(void);  // 0x3e590
bool FUN_0003e5c0(void);  // 0x3e5c0
undefined8 FUN_0003e610(byte param_1);  // 0x3e610
undefined8 FUN_0003e6e0(void);  // 0x3e6e0
undefined8 FUN_0003e710(void);  // 0x3e710
undefined8 FUN_0003e740(void);  // 0x3e740
undefined8 FUN_0003e790(void);  // 0x3e790
undefined8 FUN_0003e7c0(void);  // 0x3e7c0
undefined8 FUN_0003e850(void);  // 0x3e850
undefined8 FUN_0003e890(void);  // 0x3e890
undefined8 STAT_SET_INT_3e900(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3e900
undefined8 GET_HASH_KEY_3e930(undefined8 param_1);  // 0x3e930
undefined8 FUN_0003e950(void);  // 0x3e950
undefined8 FUN_0003ea00(void);  // 0x3ea00
undefined8 FUN_0003ea90(void);  // 0x3ea90
undefined8 FUN_0003eaf0(void);  // 0x3eaf0
undefined8 FUN_0003eb40(void);  // 0x3eb40
byte FUN_0003ebf0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x3ebf0
undefined8 FUN_0003ec30(byte param_1,undefined8 param_2,undefined8 param_3);  // 0x3ec30
undefined8 FUN_0003ecf0(void);  // 0x3ecf0
undefined8 FUN_0003ed40(void);  // 0x3ed40
undefined8 FUN_0003edb0(void);  // 0x3edb0
undefined8 FUN_0003ee20(void);  // 0x3ee20
undefined4 FUN_0003ef70(void);  // 0x3ef70
undefined8 FUN_0003eff0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x3eff0
undefined8 REQUEST_MODEL_3f020(undefined4 param_1);  // 0x3f020
undefined8 HAS_MODEL_LOADED_3f040(undefined4 param_1);  // 0x3f040
undefined8 WAIT__guess(undefined4 param_1);  // 0x3f060
undefined8 FUN_0003f080(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x3f080
undefined8 SET_ENTITY_AS_MISSION_ENTITY_3f0d0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3f0d0
undefined8 FREEZE_ENTITY_POSITION_3f100(undefined4 param_1,undefined4 param_2);  // 0x3f100
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_3f130(undefined4 param_1);  // 0x3f130
undefined8 FUN_0003f150(void);  // 0x3f150
undefined1 FUN_0003f1d0(int *param_1);  // 0x3f1d0
undefined8 PLAYER_ID_3f270(void);  // 0x3f270
undefined8 FUN_0003f280(int param_1,undefined8 param_2,undefined4 param_3);  // 0x3f280
undefined8 FUN_0003f2d0(void);  // 0x3f2d0
undefined8 SET_ENTITY_VISIBLE_3f330(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3f330
undefined8 NETWORK_SET_ENTITY_CAN_BLEND__guess(undefined4 param_1,undefined4 param_2);  // 0x3f360
undefined8 FUN_0003f390(void);  // 0x3f390
undefined8 FUN_0003f3f0(undefined4 param_1);  // 0x3f3f0
undefined8 FUN_0003f440(void);  // 0x3f440
undefined8 FUN_0003f4e0(void);  // 0x3f4e0
undefined8 FUN_0003f4f0(void);  // 0x3f4f0
undefined8 FUN_0003f5e0(void);  // 0x3f5e0
undefined8 GET_PLAYER_PED_3f6f0(undefined4 param_1);  // 0x3f6f0
undefined8 DOES_ENTITY_EXIST_3f710(undefined4 param_1);  // 0x3f710
undefined8 IS_PED_IN_ANY_VEHICLE_3f730(undefined4 param_1,undefined4 param_2);  // 0x3f730
undefined8 GET_VEHICLE_PED_IS_IN_3f760(undefined4 param_1,undefined4 param_2);  // 0x3f760
bool FUN_0003f790(int param_1);  // 0x3f790
undefined8 TASK_LEAVE_VEHICLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3f800
undefined8 CLEAR_PED_TASKS_IMMEDIATELY_3f830(undefined4 param_1);  // 0x3f830
undefined8 FUN_0003f850(void);  // 0x3f850
undefined8 FUN_0003f8d0(void);  // 0x3f8d0
undefined8 FUN_0003f940(void);  // 0x3f940
undefined1 FUN_0003f9c0(int *param_1,int *param_2);  // 0x3f9c0
undefined8 FUN_0003fa50(undefined4 param_1,long param_2,int param_3);  // 0x3fa50
undefined8 FUN_0003faa0(void);  // 0x3faa0
undefined8 FUN_0003fb30(void);  // 0x3fb30
undefined8 SET_PED_CAN_RAGDOLL_3fc40(undefined4 param_1,undefined4 param_2);  // 0x3fc40
undefined8 SET_PED_TO_RAGDOLL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x3fc70
undefined8 FUN_0003fcc0(void);  // 0x3fcc0
undefined8 REMOVE_ALL_PED_WEAPONS_3fd30(undefined4 param_1,undefined4 param_2);  // 0x3fd30
undefined8 FUN_0003fd60(void);  // 0x3fd60
undefined8 NETWORK_IS_PLAYER_ACTIVE_3fe00(undefined4 param_1);  // 0x3fe00
undefined8 FUN_0003fe20(undefined8 param_1,undefined4 param_2);  // 0x3fe20
undefined8 FUN_0003fe50(undefined4 param_1,undefined8 param_2);  // 0x3fe50
undefined8 FUN_0003fe90(undefined8 param_1,byte param_2);  // 0x3fe90
undefined8 FUN_0003fed0(undefined8 param_1);  // 0x3fed0
undefined8 FUN_0003ff30(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3ff30
undefined8 STAT_SET_BOOL_3ff60(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x3ff60
undefined8 STAT_SET_DATE__guess_3ff90(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x3ff90
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_3ffd0(undefined4 param_1);  // 0x3ffd0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_3fff0(undefined4 param_1);  // 0x3fff0
undefined8 invoke_i_iiiiiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x40010
undefined8 FUN_00040090(void);  // 0x40090
undefined8 FUN_00040160(long param_1,int param_2);  // 0x40160
undefined8 FUN_000401d0(undefined4 param_1);  // 0x401d0
undefined8 FUN_000402f0(long param_1,int param_2,undefined4 param_3);  // 0x402f0
undefined * FUN_00040550(void);  // 0x40550
undefined8 FUN_00040570(void);  // 0x40570
undefined8 FUN_00040620(void);  // 0x40620
undefined8 FUN_00040630(int param_1);  // 0x40630
int FUN_000409d0(long param_1);  // 0x409d0
char * FUN_00040aa0(void);  // 0x40aa0
undefined8 * FUN_00040ab0(void);  // 0x40ab0
int FUN_00040ac0(void);  // 0x40ac0
undefined ** FUN_00040b10(void);  // 0x40b10
undefined8 FUN_00040b20(void);  // 0x40b20
undefined8 * FUN_00040b30(void);  // 0x40b30
int FUN_00040b40(int param_1);  // 0x40b40
undefined4 FUN_00040b80(long param_1);  // 0x40b80
bool FUN_00040c00(char *param_1);  // 0x40c00
undefined8 FUN_00040c40(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x40c40
undefined8 STAT_SET_INT_40c70(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x40c70
undefined8 GET_HASH_KEY_40ca0(undefined8 param_1);  // 0x40ca0
int FUN_00040cc0(void);  // 0x40cc0
undefined8 STAT_GET_INT_40d30(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x40d30
undefined8 STAT_GET_FLOAT__guess_40d60(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x40d60
long FUN_00040d90(undefined4 param_1);  // 0x40d90
bool FUN_00040e40(uint param_1);  // 0x40e40
long FUN_00040ec0(uint param_1);  // 0x40ec0
bool FUN_00040f90(ulong param_1);  // 0x40f90
undefined8 FUN_00040ff0(undefined4 param_1);  // 0x40ff0
bool menu_sg_ok(undefined4 param_1);  // 0x41010
undefined4 FUN_00041040(undefined4 param_1);  // 0x41040
undefined4 FUN_00041080(undefined4 param_1);  // 0x41080
undefined4 FUN_000410c0(undefined4 param_1);  // 0x410c0
bool FUN_00041120(undefined4 param_1,undefined4 param_2);  // 0x41120
bool FUN_00041170(undefined4 param_1,undefined4 param_2);  // 0x41170
bool FUN_000411c0(undefined4 param_1,undefined4 param_2);  // 0x411c0
bool FUN_00041210(char *param_1);  // 0x41210
undefined8 NETWORK_GET_HOST_OF_SCRIPT__guess_41280(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x41280
undefined8 PLAYER_ID_412b0(void);  // 0x412b0
undefined1 FUN_000412c0(char *param_1,byte param_2);  // 0x412c0
undefined8 NETWORK_IS_SESSION_STARTED_41560(void);  // 0x41560
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_41570(undefined4 param_1);  // 0x41570
undefined8 GET_HASH_KEY_41590(undefined8 param_1);  // 0x41590
undefined1 FUN_000415b0(undefined8 param_1);  // 0x415b0
byte FUN_00041670(long param_1,long param_2);  // 0x41670
undefined8 FUN_00041700(void);  // 0x41700
byte FUN_000417c0(undefined8 param_1);  // 0x417c0
undefined8 FUN_000417f0(void);  // 0x417f0
undefined8 menu_script_host_tick(void);  // 0x41830
undefined8 GET_FRAME_COUNT_41990(void);  // 0x41990
undefined8 FUN_000419a0(void);  // 0x419a0
undefined8 FUN_000419c0(void);  // 0x419c0
undefined8 FUN_000419e0(long param_1);  // 0x419e0
bool FUN_00041a60(long param_1);  // 0x41a60
undefined8 FUN_00041b10(void);  // 0x41b10
undefined8 FUN_00041b60(uint param_1);  // 0x41b60
undefined1 FUN_00041be0(long *param_1,long param_2);  // 0x41be0
byte FUN_00041c90(undefined8 param_1);  // 0x41c90
bool FUN_00041cb0(ulong param_1);  // 0x41cb0
undefined8 PARTICIPANT_ID__guess(void);  // 0x41cf0
undefined * FUN_00041d00(void);  // 0x41d00
undefined8 FUN_00041d30(void);  // 0x41d30
undefined8 FUN_00041d40(undefined4 param_1);  // 0x41d40
long FUN_00041d60(int param_1,char *param_2);  // 0x41d60
undefined8 FUN_00041eb0(undefined4 param_1);  // 0x41eb0
undefined1 FUN_00041ed0(char *param_1,undefined4 param_2,undefined4 param_3);  // 0x41ed0
undefined8 GET_HASH_KEY_41f80(undefined8 param_1);  // 0x41f80
long FUN_00041fa0(long param_1,int param_2);  // 0x41fa0
undefined8 FUN_00042070(undefined *param_1);  // 0x42070
char FUN_000420d0(char *param_1,int param_2,int param_3,undefined4 param_4,long param_5,int param_6);  // 0x420d0
undefined1 FUN_00042220(char *param_1,undefined4 param_2,undefined4 *param_3);  // 0x42220
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_422e0(undefined4 param_1);  // 0x422e0
undefined8 FUN_00042300(int param_1);  // 0x42300
long FUN_00042490(int param_1,long param_2);  // 0x42490
long FUN_00042680(undefined4 param_1);  // 0x42680
byte FUN_000427e0(undefined8 param_1);  // 0x427e0
bool FUN_00042800(long param_1);  // 0x42800
undefined4 FUN_00042880(long param_1);  // 0x42880
bool FUN_000428a0(ulong param_1);  // 0x428a0
undefined1 FUN_000428e0(long param_1,char *param_2);  // 0x428e0
undefined8 FUN_000429d0(int param_1);  // 0x429d0
undefined8 FUN_00042a40(void);  // 0x42a40
uint FUN_00042a50(uint param_1);  // 0x42a50
undefined8 FUN_00042bb0(void);  // 0x42bb0
undefined4 FUN_00042c40(byte param_1);  // 0x42c40
bool FUN_00042cb0(undefined4 param_1);  // 0x42cb0
undefined8 FUN_00042ce0(undefined4 param_1);  // 0x42ce0
undefined8 FUN_00042d70(char param_1,long param_2);  // 0x42d70
undefined8 FUN_00042e50(void);  // 0x42e50
byte FUN_00042f00(void);  // 0x42f00
undefined8 FUN_00042f20(byte param_1,byte param_2);  // 0x42f20
undefined8 FUN_00043290(char param_1);  // 0x43290
uint FUN_00043360(uint param_1);  // 0x43360
int FUN_000434c0(byte param_1,undefined8 param_2);  // 0x434c0
int FUN_00043790(void);  // 0x43790
undefined8 GET_HASH_KEY_437f0(undefined8 param_1);  // 0x437f0
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_43810(undefined4 param_1);  // 0x43810
long FUN_00043830(int param_1);  // 0x43830
bool FUN_00043920(ulong param_1);  // 0x43920
long FUN_00043960(long param_1,int param_2);  // 0x43960
bool FUN_00043a80(long param_1,int param_2);  // 0x43a80
undefined1 FUN_00043b50(undefined8 param_1,undefined4 param_2,void *param_3,ulong param_4);  // 0x43b50
undefined1 FUN_00043bd0(long param_1,uint param_2,long *param_3,long param_4);  // 0x43bd0
undefined8 FUN_00043cf0(ulong param_1);  // 0x43cf0
undefined1 FUN_00043d30(undefined8 param_1,int param_2,undefined1 *param_3,int *param_4);  // 0x43d30
bool FUN_00043db0(undefined8 param_1,undefined4 param_2,void *param_3,ulong param_4);  // 0x43db0
undefined8 FUN_00043e20(void);  // 0x43e20
undefined8 FUN_00044260(void);  // 0x44260
undefined4 FUN_00044410(void);  // 0x44410
undefined8 FUN_000444b0(void);  // 0x444b0
undefined8 FUN_000447a0(void);  // 0x447a0
undefined8 FUN_00044c50(void);  // 0x44c50
undefined * FUN_00044c60(void);  // 0x44c60
undefined8 FUN_00044c70(undefined4 param_1);  // 0x44c70
undefined8 PLAYER_PED_ID_44d60(void);  // 0x44d60
undefined8 DOES_ENTITY_EXIST_44d70(undefined4 param_1);  // 0x44d70
undefined8 GET_ENTITY_MODEL_44d90(undefined4 param_1);  // 0x44d90
undefined8 FUN_00044db0(undefined4 param_1,long param_2,long param_3,long param_4,long param_5);  // 0x44db0
undefined8 GET_PED_DRAWABLE_VARIATION(undefined4 param_1,undefined4 param_2);  // 0x44eb0
undefined8 GET_PED_TEXTURE_VARIATION(undefined4 param_1,undefined4 param_2);  // 0x44ee0
undefined8 FUN_00044f10(undefined4 param_1,long param_2,long param_3,long param_4,long param_5);  // 0x44f10
undefined8 FUN_00045050(void);  // 0x45050
bool FUN_00045170(void);  // 0x45170
undefined1 FUN_000451b0(void);  // 0x451b0
undefined8 PLAYER_ID_45270(void);  // 0x45270
int FUN_00045280(int param_1,int param_2);  // 0x45280
int FUN_000452a0(void);  // 0x452a0
undefined8 NETWORK_IS_PLAYER_ACTIVE_452b0(undefined4 param_1);  // 0x452b0
undefined1 FUN_000452d0(void);  // 0x452d0
undefined8 FUN_00045670(void);  // 0x45670
char * FUN_000456a0(int param_1);  // 0x456a0
undefined1 FUN_000456e0(int param_1,char *param_2,long param_3,long param_4,long param_5,long param_6);  // 0x456e0
undefined8 FUN_00045950(void *param_1,undefined8 param_2,long param_3,int param_4);  // 0x45950
undefined4 FUN_000459f0(undefined8 param_1);  // 0x459f0
undefined8 FUN_00045b60(undefined4 *param_1);  // 0x45b60
undefined8 FUN_00045c30(char *param_1);  // 0x45c30
int FUN_00045db0(char *param_1);  // 0x45db0
undefined8 FUN_00045e70(int *param_1,int *param_2,int *param_3);  // 0x45e70
int FUN_00046020(char *param_1,undefined8 *param_2,undefined1 *param_3);  // 0x46020
int FUN_00046150(char *param_1,long param_2,int param_3);  // 0x46150
undefined8 FUN_000462e0(void);  // 0x462e0
undefined8 FUN_00046430(void);  // 0x46430
undefined8 FUN_00046450(void);  // 0x46450
undefined8 FUN_00046460(void);  // 0x46460
undefined8 FUN_00046480(void);  // 0x46480
undefined8 FUN_000464b0(void);  // 0x464b0
undefined8 FUN_00046540(void);  // 0x46540
undefined8 FUN_00046650(void);  // 0x46650
undefined8 FUN_00046a00(void);  // 0x46a00
undefined8 FUN_00046b60(int param_1);  // 0x46b60
undefined8 FUN_00046d40(int param_1);  // 0x46d40
undefined8 menu_self_component_count(void);  // 0x46f30
undefined * menu_self_component_options(void);  // 0x46f40
undefined8 FUN_00046f60(void);  // 0x46f60
undefined ** FUN_00046f70(void);  // 0x46f70
undefined8 FUN_00046f80(void);  // 0x46f80
undefined8 FUN_00046f90(void);  // 0x46f90
undefined * FUN_00047100(void);  // 0x47100
undefined8 FUN_00047120(void);  // 0x47120
undefined8 FUN_00047130(void);  // 0x47130
undefined * FUN_000471f0(void);  // 0x471f0
undefined * FUN_00047210(void);  // 0x47210
char * FUN_00047260(void);  // 0x47260
undefined * FUN_000472d0(void);  // 0x472d0
undefined8 FUN_00047320(int param_1,char *param_2,int param_3);  // 0x47320
undefined * FUN_00047520(void);  // 0x47520
undefined8 FUN_000475e0(void);  // 0x475e0
undefined1 FUN_000476c0(char *param_1);  // 0x476c0
undefined8 FUN_00047770(int param_1);  // 0x47770
undefined8 FUN_000477a0(void);  // 0x477a0
undefined8 FUN_000477f0(void);  // 0x477f0
undefined1 FUN_000479a0(int param_1,char *param_2,long param_3,long param_4,long param_5,long param_6);  // 0x479a0
undefined8 FUN_00047c40(void);  // 0x47c40
undefined8 FUN_00047cd0(char *param_1);  // 0x47cd0
undefined8 FUN_00047e00(void);  // 0x47e00
undefined8 FUN_00047e10(void);  // 0x47e10
undefined8 FUN_00047e60(void);  // 0x47e60
undefined1 FUN_00047ec0(int param_1);  // 0x47ec0
undefined8 FUN_00047f50(void);  // 0x47f50
undefined8 FUN_00047fd0(long param_1,char *param_2,int param_3);  // 0x47fd0
undefined8 FUN_00048190(void);  // 0x48190
undefined8 FUN_00048270(int param_1);  // 0x48270
bool FUN_000482b0(void);  // 0x482b0
byte FUN_000483a0(void);  // 0x483a0
undefined8 FUN_000483c0(int param_1);  // 0x483c0
undefined8 FUN_00048400(void);  // 0x48400
undefined8 FUN_00048450(void);  // 0x48450
undefined8 NETWORK_BUY_HEALTHCARE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x48480
undefined8 FUN_000484b0(void);  // 0x484b0
byte FUN_00048520(undefined8 param_1,byte param_2);  // 0x48520
undefined8 FUN_00048560(void);  // 0x48560
undefined8 FUN_000485b0(void);  // 0x485b0
undefined8 FUN_00048630(void);  // 0x48630
undefined8 FUN_00048680(void);  // 0x48680
int FUN_00048750(void);  // 0x48750
int FUN_000487a0(undefined4 param_1);  // 0x487a0
undefined8 FUN_00048800(void);  // 0x48800
undefined8 SET_ENTITY_HEALTH_48840(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x48840
undefined8 FUN_00048870(undefined1 *param_1);  // 0x48870
undefined8 FUN_00048ad0(void);  // 0x48ad0
undefined8 FUN_00048b90(void);  // 0x48b90
undefined8 FUN_00048c70(byte param_1);  // 0x48c70
undefined8 FUN_00048d20(void);  // 0x48d20
undefined8 FUN_00048d30(undefined4 param_1,undefined4 param_2);  // 0x48d30
undefined8 STAT_GET_INT_48d60(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x48d60
undefined8 GET_HASH_KEY_48d90(undefined8 param_1);  // 0x48d90
undefined8 FUN_00048db0(void);  // 0x48db0
undefined8 STAT_SET_INT_48df0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x48df0
byte FUN_00048e20(void);  // 0x48e20
byte FUN_00048e50(undefined4 param_1,int param_2);  // 0x48e50
undefined8 FUN_00048ef0(long param_1,long param_2);  // 0x48ef0
undefined8 FUN_00048f40(char *param_1,ulong param_2,undefined4 param_3,int param_4);  // 0x48f40
undefined8 FUN_000490d0(char *param_1,ulong param_2);  // 0x490d0
undefined4 FUN_00049230(undefined4 param_1);  // 0x49230
char * FUN_000492a0(undefined4 param_1);  // 0x492a0
byte FUN_000493d0(void);  // 0x493d0
undefined8 FUN_00049400(void);  // 0x49400
undefined8 FUN_00049510(void);  // 0x49510
int FUN_00049530(void);  // 0x49530
undefined * FUN_00049570(void);  // 0x49570
undefined * FUN_00049580(void);  // 0x49580
undefined8 FUN_000495f0(void);  // 0x495f0
undefined8 FUN_00049630(void);  // 0x49630
undefined8 FUN_000497f0(void);  // 0x497f0
undefined8 FUN_00049800(void);  // 0x49800
undefined8 FUN_00049810(void);  // 0x49810
undefined8 FUN_00049840(void);  // 0x49840
undefined4 FUN_00049910(int param_1);  // 0x49910
undefined8 FUN_00049980(undefined4 param_1,int param_2);  // 0x49980
undefined8 FUN_00049a90(void);  // 0x49a90
undefined8 FUN_00049aa0(undefined4 param_1);  // 0x49aa0
undefined8 FUN_00049af0(void);  // 0x49af0
undefined8 FUN_00049b00(void);  // 0x49b00
undefined8 FUN_00049b40(void);  // 0x49b40
undefined8 FUN_00049b80(char *param_1,long param_2);  // 0x49b80
undefined8 FUN_00049ff0(void *param_1);  // 0x49ff0
undefined8 menu_self_tick(void);  // 0x4a1e0
undefined8 IS_ENTITY_DEAD_4a460(undefined4 param_1,undefined4 param_2);  // 0x4a460
undefined8 FUN_0004a490(int param_1);  // 0x4a490
undefined8 SET_SUPER_JUMP_THIS_FRAME(undefined4 param_1);  // 0x4aa20
undefined8 FUN_0004aa40(undefined4 param_1,undefined4 param_2);  // 0x4aa40
undefined8 FUN_0004aa70(void);  // 0x4aa70
undefined8 SET_PED_CONFIG_FLAG_4ab00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4ab00
undefined8 SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(undefined4 param_1,undefined4 param_2);  // 0x4ab30
undefined8 FUN_0004ab60(void);  // 0x4ab60
undefined8 FUN_0004acf0(void);  // 0x4acf0
int FUN_0004b000(void);  // 0x4b000
int FUN_0004b010(void);  // 0x4b010
undefined8 FUN_0004b020(undefined4 param_1);  // 0x4b020
undefined8 FUN_0004b040(undefined4 param_1,char *param_2,long param_3);  // 0x4b040
int FUN_0004b1a0(char *param_1);  // 0x4b1a0
undefined8 FUN_0004b2a0(undefined4 param_1,char *param_2,long param_3);  // 0x4b2a0
undefined8 FUN_0004b340(int param_1,char *param_2,long param_3);  // 0x4b340
undefined8 FUN_0004b530(long param_1,int param_2);  // 0x4b530
undefined8 GET_PED_PROP_INDEX(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4b5e0
undefined8 GET_PED_PROP_TEXTURE_INDEX(undefined4 param_1,undefined4 param_2);  // 0x4b610
undefined8 NETWORK_IS_SESSION_STARTED_4b640(void);  // 0x4b640
undefined8 NETWORK_IS_IN_SESSION__guess(void);  // 0x4b650
undefined8 _0x89023FBBF9200E9F__guess_4b660(void);  // 0x4b660
undefined8 SET_PED_COMPONENT_VARIATION(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x4b670
undefined8 CLEAR_PED_PROP(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4b6b0
undefined8 SET_PED_PROP_INDEX(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x4b6e0
undefined1 FUN_0004b720(void);  // 0x4b720
undefined1 FUN_0004b7f0(void);  // 0x4b7f0
undefined1 FUN_0004b9a0(int param_1,int param_2,int *param_3);  // 0x4b9a0
int FUN_0004ba50(int param_1,int param_2,int param_3,int param_4);  // 0x4ba50
int FUN_0004bb80(void);  // 0x4bb80
int FUN_0004bbd0(void);  // 0x4bbd0
int FUN_0004bbf0(void);  // 0x4bbf0
int FUN_0004bc00(void);  // 0x4bc00
int FUN_0004bc30(void);  // 0x4bc30
int FUN_0004bc60(void);  // 0x4bc60
undefined8 FUN_0004bca0(undefined4 param_1,int param_2);  // 0x4bca0
undefined4 FUN_0004bd20(undefined4 param_1,int param_2,int param_3);  // 0x4bd20
undefined8 FUN_0004bdb0(undefined4 param_1,undefined4 param_2);  // 0x4bdb0
undefined4 FUN_0004be20(undefined4 param_1,undefined4 param_2,int param_3);  // 0x4be20
undefined8 GET_NUMBER_OF_PED_DRAWABLE_VARIATIONS__guess(undefined4 param_1,undefined4 param_2);  // 0x4beb0
int FUN_0004bee0(int param_1,int param_2,int param_3);  // 0x4bee0
undefined8 GET_NUMBER_OF_PED_TEXTURE_VARIATIONS__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4bf90
undefined8 GET_NUMBER_OF_PED_PROP_DRAWABLE_VARIATIONS(undefined4 param_1,undefined4 param_2);  // 0x4bfc0
undefined8 GET_NUMBER_OF_PED_PROP_TEXTURE_VARIATIONS(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4bff0
undefined8 FUN_0004c020(void);  // 0x4c020
undefined8 FUN_0004c120(void);  // 0x4c120
undefined8 FUN_0004c1a0(void);  // 0x4c1a0
undefined8 FUN_0004c220(void);  // 0x4c220
undefined8 FUN_0004c2a0(char *param_1,byte param_2);  // 0x4c2a0
undefined8 FUN_0004c330(long param_1,char *param_2,int param_3);  // 0x4c330
undefined1 FUN_0004c540(char *param_1,int *param_2);  // 0x4c540
undefined1 FUN_0004c740(char *param_1,undefined4 *param_2);  // 0x4c740
undefined8 FUN_0004c810(long param_1,char *param_2,int param_3);  // 0x4c810
undefined1 FUN_0004ca40(char *param_1,undefined4 *param_2);  // 0x4ca40
undefined1 FUN_0004cac0(undefined8 param_1,undefined8 param_2);  // 0x4cac0
undefined8 FUN_0004cb50(long param_1,int param_2);  // 0x4cb50
bool FUN_0004cc70(long param_1,long param_2,int *param_3);  // 0x4cc70
undefined8 FUN_0004cd00(long param_1,long param_2,int param_3);  // 0x4cd00
undefined8 FUN_0004cf10(undefined8 param_1);  // 0x4cf10
undefined8 FUN_0004cfd0(undefined8 param_1);  // 0x4cfd0
undefined8 FUN_0004d0a0(undefined8 param_1);  // 0x4d0a0
undefined8 FUN_0004d160(void);  // 0x4d160
byte FUN_0004d1c0(undefined4 param_1,undefined4 param_2);  // 0x4d1c0
undefined8 FUN_0004d1f0(int param_1,char *param_2);  // 0x4d1f0
bool FUN_0004d450(ulong param_1,int param_2);  // 0x4d450
undefined8 FUN_0004d490(ulong param_1,long param_2,int param_3);  // 0x4d490
undefined8 NETWORK_EARN_FROM_IMPORT_EXPORT__guess(undefined4 param_1,undefined8 param_2);  // 0x4d510
undefined1 FUN_0004d540(undefined8 param_1,long param_2,byte param_3,byte param_4);  // 0x4d540
undefined8 FUN_0004d680(undefined4 param_1);  // 0x4d680
undefined1 FUN_0004d780(long *param_1,undefined8 param_2);  // 0x4d780
undefined8 NETWORK_GET_VC_WALLET_BALANCE_4d810(undefined4 param_1);  // 0x4d810
undefined4 FUN_0004d830(undefined4 param_1);  // 0x4d830
undefined8 CLEAR_PED_TASKS_IMMEDIATELY_4d8a0(undefined4 param_1);  // 0x4d8a0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_4d8c0(undefined4 param_1);  // 0x4d8c0
undefined8 SET_VEHICLE_ENGINE_ON_4d8e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x4d8e0
undefined8 FUN_0004d920(undefined4 param_1,byte param_2);  // 0x4d920
undefined8 SET_ENTITY_INVINCIBLE_4d9e0(undefined4 param_1,undefined4 param_2);  // 0x4d9e0
undefined8 SET_ENTITY_HAS_GRAVITY__guess(undefined4 param_1,undefined4 param_2);  // 0x4da10
undefined8 IS_PED_IN_ANY_VEHICLE_4da40(undefined4 param_1,undefined4 param_2);  // 0x4da40
undefined8 GET_VEHICLE_PED_IS_IN_4da70(undefined4 param_1,undefined4 param_2);  // 0x4da70
undefined8 SET_ENTITY_COLLISION_4daa0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4daa0
undefined8 FUN_0004dad0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x4dad0
undefined8 FREEZE_ENTITY_POSITION_4db10(undefined4 param_1,undefined4 param_2);  // 0x4db10
undefined8 GET_ENTITY_TYPE__guess_4db40(undefined4 param_1);  // 0x4db40
bool FUN_0004db60(void);  // 0x4db60
undefined1 FUN_0004dbd0(void);  // 0x4dbd0
undefined8 FUN_0004dc80(void);  // 0x4dc80
undefined8 FUN_0004dcc0(undefined4 param_1);  // 0x4dcc0
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_4dce0(undefined4 param_1);  // 0x4dce0
undefined8 FUN_0004dd00(byte param_1);  // 0x4dd00
undefined1 FUN_0004dda0(undefined4 param_1);  // 0x4dda0
bool FUN_0004dea0(int param_1);  // 0x4dea0
undefined8 IS_DISABLED_CONTROL_PRESSED_4df40(undefined4 param_1,undefined4 param_2);  // 0x4df40
undefined8 IS_CONTROL_PRESSED_4df70(undefined4 param_1,undefined4 param_2);  // 0x4df70
char * FUN_0004dfa0(undefined4 param_1);  // 0x4dfa0
undefined8 DISABLE_CONTROL_ACTION_4e0a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x4e0a0
undefined8 FUN_0004e0d0(undefined8 param_1,undefined4 param_2);  // 0x4e0d0
undefined4 FUN_0004e100(undefined4 param_1);  // 0x4e100
undefined8 FUN_0004e180(undefined4 param_1);  // 0x4e180
bool FUN_0004e1b0(undefined4 param_1);  // 0x4e1b0
undefined8 FUN_0004e230(undefined4 param_1);  // 0x4e230
undefined8 FUN_0004e260(undefined4 param_1);  // 0x4e260
undefined8 FUN_0004e290(undefined4 param_1);  // 0x4e290
undefined8 FUN_0004e2c0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x4e2c0
undefined8 FUN_0004e2f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x4e2f0
undefined8 FUN_0004e340(undefined4 param_1,undefined4 param_2);  // 0x4e340
undefined8 GET_CONTROL_NORMAL(undefined4 param_1,undefined4 param_2);  // 0x4e370
undefined8 GET_DISABLED_CONTROL_NORMAL(undefined4 param_1,undefined4 param_2);  // 0x4e3a0
undefined4 FUN_0004e3d0(void);  // 0x4e3d0
undefined8 _LOAD_MP_DLC_MAPS__guess_3(void);  // 0x4e410
undefined8 _0xF70EFA14FE091429__guess(undefined4 param_1);  // 0x4e420
bool FUN_0004e440(uint param_1);  // 0x4e440
bool FUN_0004e470(undefined4 param_1,int param_2);  // 0x4e470
undefined8 _LOAD_MP_DLC_MAPS__guess(void);  // 0x4e550
undefined8 _LOAD_MP_DLC_MAPS__guess_2(void);  // 0x4e560
undefined8 NET_GAMESERVER_TRANSACTION_IN_PROGRESS(void);  // 0x4e570
undefined8 _NULLIFY__guess_2(undefined8 param_1,undefined8 param_2);  // 0x4e580
undefined8 _NULLIFY__guess_3(undefined4 param_1,undefined4 param_2);  // 0x4e5b0
undefined8 invoke_p_iiiiii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x4e5e0
undefined8 invoke_f_ii(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x4e650
undefined8 invoke_i_pipi(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x4e690
undefined8 FUN_0004e6e0(void);  // 0x4e6e0
undefined ** FUN_0004e6f0(void);  // 0x4e6f0
undefined8 menu_self_anims_count(void);  // 0x4e700
undefined ** menu_self_anims_options(void);  // 0x4e710
undefined8 FUN_0004e720(void);  // 0x4e720
undefined ** FUN_0004e730(void);  // 0x4e730
undefined8 FUN_0004e740(void);  // 0x4e740
undefined ** FUN_0004e750(void);  // 0x4e750
undefined8 FUN_0004e760(char *param_1);  // 0x4e760
undefined8 GET_HASH_KEY_4e810(undefined8 param_1);  // 0x4e810
undefined8 IS_MODEL_IN_CDIMAGE_4e830(undefined4 param_1);  // 0x4e830
undefined8 IS_MODEL_VALID_4e850(undefined4 param_1);  // 0x4e850
undefined8 FUN_0004e870(void);  // 0x4e870
undefined8 REQUEST_MODEL_4e8b0(undefined4 param_1);  // 0x4e8b0
undefined8 FUN_0004e8d0(char *param_1);  // 0x4e8d0
undefined8 FUN_0004e9b0(void);  // 0x4e9b0
bool FUN_0004e9f0(char *param_1,void *param_2,int param_3,char *param_4,int param_5);  // 0x4e9f0
undefined8 REQUEST_ANIM_DICT(undefined8 param_1);  // 0x4eb20
undefined8 FUN_0004eb40(char *param_1);  // 0x4eb40
undefined8 PLAYER_PED_ID_4ebc0(void);  // 0x4ebc0
undefined8 DOES_ENTITY_EXIST_4ebd0(undefined4 param_1);  // 0x4ebd0
undefined8 CLEAR_PED_TASKS_IMMEDIATELY_4ebf0(undefined4 param_1);  // 0x4ebf0
undefined8 TASK_START_SCENARIO_IN_PLACE(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x4ec10
undefined8 FUN_0004ec50(char *param_1);  // 0x4ec50
undefined8 FUN_0004ed10(undefined4 param_1,undefined4 param_2);  // 0x4ed10
undefined8 REQUEST_CLIP_SET__guess(undefined8 param_1);  // 0x4ed40
undefined8 menu_self_ped_tick(void);  // 0x4ed60
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_4ee80(undefined4 param_1);  // 0x4ee80
undefined8 HAS_MODEL_LOADED_4eea0(undefined4 param_1);  // 0x4eea0
undefined8 FUN_0004eec0(void);  // 0x4eec0
undefined8 HAS_ANIM_DICT_LOADED(undefined8 param_1);  // 0x4ef70
undefined8 FUN_0004ef90(void);  // 0x4ef90
undefined8 HAS_CLIP_SET_LOADED__guess(undefined8 param_1);  // 0x4f020
undefined8 FUN_0004f040(void);  // 0x4f040
undefined8 PLAYER_ID_4f0a0(void);  // 0x4f0a0
undefined8 SET_PLAYER_MODEL(undefined4 param_1,undefined4 param_2);  // 0x4f0b0
undefined8 SET_PED_DEFAULT_COMPONENT_VARIATION__guess_4f0e0(undefined4 param_1);  // 0x4f0e0
undefined8 SET_PED_RANDOM_COMPONENT_VARIATION__guess(undefined4 param_1,undefined4 param_2);  // 0x4f100
undefined8 CLEAR_PED_TASKS_4f130(undefined4 param_1);  // 0x4f130
undefined8 FUN_0004f150(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11);  // 0x4f150
undefined8 FUN_0004f1d0(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x4f1d0
undefined8 invoke_p_isii(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4, undefined4 param_5);  // 0x4f200
undefined8 invoke_p_issffiifiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined8 param_6,undefined8 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12);  // 0x4f260
undefined8 invoke_p_isf(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4);  // 0x4f320
undefined8 menu_settings_load(void);  // 0x4f380
undefined8 FUN_0004f520(void);  // 0x4f520
undefined8 FUN_0004f540(char *param_1);  // 0x4f540
undefined8 FUN_0004f6c0(char *param_1,undefined8 param_2,undefined1 *param_3,undefined8 param_4);  // 0x4f6c0
undefined8 menu_settings_save(void);  // 0x518e0
float FUN_00052b60(char *param_1,undefined1 *param_2);  // 0x52b60
float FUN_00052d90(float param_1);  // 0x52d90
int FUN_00052e50(char *param_1,undefined1 *param_2);  // 0x52e50
undefined8 FUN_00052f40(int *param_1);  // 0x52f40
undefined8 menu_sp_stats_count(void);  // 0x52f80
undefined ** menu_sp_stats_options(void);  // 0x52f90
undefined * FUN_00052fa0(void);  // 0x52fa0
undefined8 menu_sp_stats_tick(void);  // 0x53000
undefined8 _STOP_ALL_SCREEN_EFFECTS__guess(void);  // 0x53210
undefined8 GET_PLAYER_SWITCH_STATE__guess_53220(void);  // 0x53220
undefined8 NETWORK_IS_SESSION_STARTED_53230(void);  // 0x53230
undefined8 NETWORK_IS_GAME_IN_PROGRESS_53240(void);  // 0x53240
undefined8 SET_MISSION_FLAG__guess(undefined4 param_1);  // 0x53250
undefined8 FUN_00053270(undefined4 param_1,undefined4 param_2);  // 0x53270
undefined8 TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME__guess_532b0(undefined8 param_1);  // 0x532b0
int FUN_000532d0(void);  // 0x532d0
undefined8 FUN_00053340(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x53340
undefined8 FUN_00053390(void);  // 0x53390
undefined8 FUN_00053400(void);  // 0x53400
undefined8 FUN_000534b0(void);  // 0x534b0
undefined8 FUN_00053540(void);  // 0x53540
undefined8 FUN_000535d0(void);  // 0x535d0
undefined8 FUN_00053630(void);  // 0x53630
undefined8 FUN_000536b0(void);  // 0x536b0
undefined8 FUN_00053730(void);  // 0x53730
undefined8 FUN_000537a0(void);  // 0x537a0
undefined8 FUN_00053820(void);  // 0x53820
undefined8 FUN_00053880(void);  // 0x53880
undefined8 FUN_000538e0(void);  // 0x538e0
undefined8 FUN_00053940(void);  // 0x53940
undefined8 FUN_000539a0(void);  // 0x539a0
undefined8 FUN_000539b0(void);  // 0x539b0
undefined8 FUN_000539c0(void);  // 0x539c0
undefined8 FUN_00053af0(void);  // 0x53af0
undefined8 FUN_00053d30(void);  // 0x53d30
undefined8 FUN_00053df0(void);  // 0x53df0
undefined8 FUN_00053e50(void);  // 0x53e50
undefined8 FUN_00053ee0(void);  // 0x53ee0
undefined8 FUN_00053f10(void);  // 0x53f10
undefined8 FUN_00053f20(void);  // 0x53f20
undefined8 FUN_00053f30(void);  // 0x53f30
undefined4 FUN_000540e0(int *param_1);  // 0x540e0
undefined8 FUN_000541c0(undefined4 param_1,int param_2);  // 0x541c0
undefined8 FUN_00054210(void);  // 0x54210
undefined8 STAT_GET_INT_54250(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x54250
undefined8 FUN_00054280(uint param_1,undefined8 param_2);  // 0x54280
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess_542c0(void);  // 0x542c0
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess_2_542d0(void);  // 0x542d0
undefined8 STAT_LOAD_PENDING__guess_542e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x542e0
undefined8 GET_HASH_KEY_54320(undefined8 param_1);  // 0x54320
undefined8 _0xF434A10BA01C37D0__guess_54340(undefined4 param_1);  // 0x54340
undefined8 FUN_00054360(undefined4 param_1);  // 0x54360
undefined8 FUN_00054440(undefined4 param_1);  // 0x54440
undefined8 FUN_00054570(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x54570
undefined8 FUN_000545c0(undefined4 param_1,undefined8 param_2,int param_3);  // 0x545c0
undefined8 FUN_000546a0(undefined4 param_1,undefined8 param_2,int param_3);  // 0x546a0
undefined8 FUN_000547a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x547a0
undefined8 FUN_000547d0(long *param_1,int param_2,int param_3,int param_4,int param_5,int param_6, int param_7,int param_8);  // 0x547d0
undefined8 STAT_SET_DATE__guess_54850(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4);  // 0x54850
undefined8 FUN_00054890(undefined4 param_1);  // 0x54890
undefined8 IS_SPECIAL_ABILITY_ENABLED__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x548e0
undefined8 PLAYER_ID_54910(void);  // 0x54910
undefined8 _0xF10B44FD479D69F3__guess(undefined4 param_1,undefined4 param_2);  // 0x54920
undefined8 SPECIAL_ABILITY_FILL_METER(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x54950
undefined8 SPECIAL_ABILITY_DEPLETE_METER__guess(undefined4 param_1,undefined4 param_2);  // 0x54980
undefined4 FUN_000549b0(int param_1);  // 0x549b0
undefined8 SPECIAL_ABILITY_CHARGE_CONTINUOUS__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x54a10
undefined8 FUN_00054a50(void);  // 0x54a50
undefined8 FUN_00054b60(undefined8 param_1,undefined4 param_2);  // 0x54b60
undefined8 FUN_00054ba0(int param_1,int param_2);  // 0x54ba0
undefined8 FUN_00054c00(void);  // 0x54c00
undefined8 STAT_SET_INT_54cd0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x54cd0
undefined8 _0xBED9F5693F34ED17__guess_54d00(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x54d00
bool FUN_00054d30(void);  // 0x54d30
undefined1 FUN_00054e70(void);  // 0x54e70
bool FUN_00054fb0(int param_1);  // 0x54fb0
bool FUN_00055020(int param_1);  // 0x55020
bool FUN_00055170(int param_1);  // 0x55170
undefined8 FUN_000551c0(undefined4 param_1);  // 0x551c0
undefined8 FUN_00055250(int param_1);  // 0x55250
undefined8 FUN_000555c0(undefined4 param_1,uint param_2);  // 0x555c0
undefined8 FUN_00055610(undefined4 param_1);  // 0x55610
undefined8 _0x690A61A6D13583F6__guess(undefined4 param_1);  // 0x55660
undefined8 FUN_00055680(int param_1);  // 0x55680
undefined8 FUN_000557a0(void);  // 0x557a0
undefined8 FUN_00055850(undefined8 param_1,byte param_2);  // 0x55850
int FUN_000558b0(int param_1,int param_2);  // 0x558b0
undefined8 FUN_00055960(undefined4 param_1);  // 0x55960
undefined8 FUN_00055ae0(undefined4 param_1);  // 0x55ae0
undefined8 STAT_SET_BOOL_55c40(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x55c40
int FUN_00055c70(void);  // 0x55c70
undefined4 FUN_00055d90(int param_1);  // 0x55d90
undefined4 FUN_00055dd0(undefined4 param_1);  // 0x55dd0
undefined8 FUN_00055e30(void);  // 0x55e30
undefined8 FUN_00055ef0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x55ef0
undefined8 SET_BLIP_SPRITE(undefined4 param_1,undefined4 param_2);  // 0x55f30
undefined8 SET_BLIP_COLOUR(undefined4 param_1,undefined4 param_2);  // 0x55f60
undefined8 FUN_00055f90(undefined4 param_1,undefined4 param_2);  // 0x55f90
undefined8 SET_BLIP_AS_SHORT_RANGE__guess(undefined4 param_1,undefined4 param_2);  // 0x55fc0
undefined8 SET_BLIP_CATEGORY__guess(undefined4 param_1,undefined4 param_2);  // 0x55ff0
undefined8 SET_BLIP_CATEGORY__guess_2(undefined4 param_1,undefined4 param_2);  // 0x56020
undefined8 BEGIN_TEXT_COMMAND_SET_BLIP_NAME(undefined8 param_1);  // 0x56050
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME_56070(undefined8 param_1);  // 0x56070
undefined8 END_TEXT_COMMAND_SET_BLIP_NAME(undefined4 param_1);  // 0x56090
undefined8 DOES_BLIP_EXIST_560b0(undefined4 param_1);  // 0x560b0
undefined8 REMOVE_BLIP__guess(undefined8 param_1);  // 0x560d0
undefined8 FUN_000560f0(void);  // 0x560f0
undefined8 FUN_00056160(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0x56160
undefined8 GET_INTERIOR_GROUP_ID__guess_561a0(undefined4 param_1);  // 0x561a0
undefined8 DISABLE_INTERIOR__guess_561c0(undefined4 param_1,undefined4 param_2);  // 0x561c0
undefined8 _IS_INTERIOR_PROP_ENABLED__guess_561f0(undefined4 param_1,undefined4 param_2);  // 0x561f0
undefined8 _0x405DC2AEF6AF95B9__guess_56220(undefined4 param_1);  // 0x56220
undefined8 REFRESH_INTERIOR__guess_56240(undefined4 param_1);  // 0x56240
undefined8 FUN_00056260(undefined4 param_1);  // 0x56260
undefined8 FUN_00056370(void);  // 0x56370
undefined8 _0x6FDDF453C0C756EC__guess(void);  // 0x56450
undefined8 GET_PROFILE_SETTING__guess(undefined4 param_1);  // 0x56460
undefined8 _0xA0F93D5465B3094D__guess(undefined4 param_1);  // 0x56480
undefined8 FUN_000564a0(void);  // 0x564a0
undefined8 FUN_000564c0(void);  // 0x564c0
undefined8 FUN_000564e0(undefined4 param_1);  // 0x564e0
undefined8 FUN_00056540(byte param_1);  // 0x56540
undefined8 FUN_000567a0(byte param_1);  // 0x567a0
undefined8 FUN_00056a60(void);  // 0x56a60
undefined8 _0xFDD85225B2DEA55E__guess(void);  // 0x56b50
undefined8 CLEAR_HELP__guess_56b60(undefined4 param_1);  // 0x56b60
undefined8 CLEAR_ALL_HELP_MESSAGES__guess(void);  // 0x56b80
undefined8 SET_FRONTEND_ACTIVE__guess_56b90(undefined4 param_1);  // 0x56b90
undefined8 _0x22A249A53034450A__guess_56bb0(undefined4 param_1);  // 0x56bb0
undefined8 _0x71E7B2E657449AAD__guess_2(void);  // 0x56bd0
undefined8 _0x71E7B2E657449AAD__guess(void);  // 0x56be0
undefined8 CLEAR_FOCUS_56bf0(void);  // 0x56bf0
undefined8 PLAYER_PED_ID_56c00(void);  // 0x56c00
undefined8 DOES_ENTITY_EXIST_56c10(undefined4 param_1);  // 0x56c10
undefined8 CLEAR_PED_TASKS_IMMEDIATELY_56c30(undefined4 param_1);  // 0x56c30
undefined8 FREEZE_ENTITY_POSITION_56c50(undefined4 param_1,undefined4 param_2);  // 0x56c50
undefined8 IS_ENTITY_ATTACHED_56c80(undefined4 param_1);  // 0x56c80
undefined8 DETACH_ENTITY_56ca0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x56ca0
undefined8 FUN_00056cd0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x56cd0
undefined8 FUN_00056d00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x56d00
undefined8 FUN_00056d60(undefined4 param_1,undefined4 param_2);  // 0x56d60
undefined8 SET_PLAYER_CONTROL__guess_56d90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x56d90
undefined8 ENABLE_ALL_CONTROL_ACTIONS__guess_56dc0(undefined4 param_1);  // 0x56dc0
undefined8 DISPLAY_HUD__guess(undefined4 param_1);  // 0x56de0
undefined8 DISPLAY_RADAR__guess(undefined4 param_1);  // 0x56e00
undefined8 IS_SCREEN_FADING_IN__guess_2(void);  // 0x56e20
undefined8 DO_SCREEN_FADE_OUT__guess(undefined4 param_1);  // 0x56e30
undefined8 FUN_00056e50(char *param_1,undefined4 param_2);  // 0x56e50
undefined8 RENDER_SCRIPT_CAMS(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x56f10
undefined8 DESTROY_ALL_CAMS__guess(undefined4 param_1);  // 0x56f60
undefined8 REQUEST_SCRIPT(undefined8 param_1);  // 0x56f80
undefined8 HAS_SCRIPT_LOADED(undefined8 param_1);  // 0x56fa0
undefined8 START_NEW_SCRIPT(undefined8 param_1,undefined4 param_2);  // 0x56fc0
undefined8 SET_SCRIPT_AS_NO_LONGER_NEEDED(undefined8 param_1);  // 0x56ff0
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_2_57010(void);  // 0x57010
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_57020(void);  // 0x57020
undefined8 HAS_THIS_CUTSCENE_LOADED__guess_57030(undefined4 param_1);  // 0x57030
undefined8 _0xB56BBBCC2955D9CB__guess_57050(void);  // 0x57050
undefined8 REMOVE_CUTSCENE__guess(void);  // 0x57060
undefined8 _0x0150B6FF25A9E2E5__guess(void);  // 0x57070
undefined8 _0x302C91AB2D477F7E__guess(void);  // 0x57080
int FUN_00057090(void);  // 0x57090
undefined8 CLEAR_PLAYER_WANTED_LEVEL_57180(undefined4 param_1);  // 0x57180
undefined8 IS_PED_IN_ANY_VEHICLE_571a0(undefined4 param_1,undefined4 param_2);  // 0x571a0
undefined8 GET_VEHICLE_PED_IS_IN_571d0(undefined4 param_1,undefined4 param_2);  // 0x571d0
undefined8 TASK_LEAVE_VEHICLE__guess_57200(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x57200
undefined8 DO_SCREEN_FADE_OUT__guess_2(undefined4 param_1);  // 0x57230
undefined8 FUN_00057250(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x57250
undefined8 WAIT__guess_57290(undefined4 param_1);  // 0x57290
undefined8 _SET_NORTH_YANKTON_MAP__guess(undefined4 param_1);  // 0x572b0
undefined8 _SET_MINIMAP_REVEALED__guess(undefined4 param_1);  // 0x572d0
undefined8 FUN_000572f0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x572f0
undefined8 FUN_00057330(undefined4 param_1);  // 0x57330
undefined8 SET_ENTITY_HEALTH_573a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x573a0
undefined8 GET_ENTITY_MAX_HEALTH_573d0(undefined4 param_1);  // 0x573d0
undefined8 SET_PED_ARMOUR_573f0(undefined4 param_1,undefined4 param_2);  // 0x573f0
undefined8 ADD_ARMOUR_TO_PED__guess_57420(undefined4 param_1,undefined4 param_2);  // 0x57420
undefined8 FUN_00057450(undefined4 param_1,undefined4 param_2);  // 0x57450
undefined8 SET_MAX_WANTED_LEVEL__guess_57480(undefined4 param_1);  // 0x57480
undefined4 FUN_000574a0(int param_1);  // 0x574a0
undefined8 GET_ENTITY_MODEL_57540(undefined4 param_1);  // 0x57540
undefined8 FUN_00057560(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x57560
undefined8 FUN_00057590(undefined4 param_1,undefined4 param_2);  // 0x57590
undefined8 FUN_000575c0(undefined4 param_1,undefined4 param_2);  // 0x575c0
undefined8 FUN_000575f0(undefined4 param_1,undefined4 param_2);  // 0x575f0
undefined8 invoke_i_fffs(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5);  // 0x57620
undefined8 invoke_p_ifffiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x57690
undefined8 invoke_i_si(undefined8 param_1,undefined8 param_2,undefined4 param_3);  // 0x57720
bool FUN_00057770(undefined4 param_1);  // 0x57770
undefined * FUN_000577a0(int param_1);  // 0x577a0
undefined8 FUN_00057820(void);  // 0x57820
undefined8 FUN_00057830(undefined4 param_1);  // 0x57830
undefined8 FUN_00057870(int param_1,int param_2);  // 0x57870
undefined8 FUN_00057bd0(void);  // 0x57bd0
undefined ** FUN_00057be0(void);  // 0x57be0
undefined4 menu_tattoos_zone_count(void);  // 0x57bf0
undefined8 * menu_tattoos_zone_options(void);  // 0x57c00
char * FUN_00057c10(undefined4 param_1);  // 0x57c10
byte FUN_00057cf0(int param_1);  // 0x57cf0
undefined1 FUN_00057d80(int param_1,int param_2);  // 0x57d80
bool FUN_00057e00(undefined4 param_1);  // 0x57e00
undefined8 menu_tattoos_tick(void);  // 0x57eb0
undefined8 FUN_00057ee0(void);  // 0x57ee0
undefined8 PLAYER_PED_ID_57f30(void);  // 0x57f30
undefined8 DOES_ENTITY_EXIST_57f40(undefined4 param_1);  // 0x57f40
undefined8 IS_ENTITY_DEAD_57f60(undefined4 param_1,undefined4 param_2);  // 0x57f60
undefined8 FUN_00057f90(undefined4 param_1);  // 0x57f90
undefined8 FUN_00058020(void);  // 0x58020
undefined4 FUN_000582a0(undefined4 param_1);  // 0x582a0
undefined8 _0xC17AD0E5752BECDA__guess(undefined4 param_1);  // 0x58310
undefined8 _0x341DE7ED1D2A1BFD__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x58330
undefined8 _GET_TATTOO_ZONE__guess(undefined4 param_1,undefined4 param_2);  // 0x58360
undefined4 FUN_00058390(int param_1);  // 0x58390
undefined8 FUN_000585c0(char *param_1,int param_2,char *param_3,uint param_4,uint param_5);  // 0x585c0
undefined8 FUN_000586b0(undefined1 *param_1,int param_2,char *param_3);  // 0x586b0
undefined8 FUN_00058780(int param_1,int param_2,undefined4 param_3);  // 0x58780
undefined8 FUN_00058840(void);  // 0x58840
undefined8 GET_HASH_KEY_58ac0(undefined8 param_1);  // 0x58ac0
undefined8 GET_ENTITY_MODEL_58ae0(undefined4 param_1);  // 0x58ae0
undefined8 DOES_TEXT_LABEL_EXIST__guess_58b00(undefined8 param_1);  // 0x58b00
undefined8 _GET_LABEL_TEXT__guess_58b20(undefined8 param_1);  // 0x58b20
int FUN_00058b40(void);  // 0x58b40
ulong FUN_00058b80(undefined4 param_1,byte param_2);  // 0x58b80
undefined8 FUN_00058ca0(int param_1,int param_2);  // 0x58ca0
undefined8 CLEAR_PED_DECORATIONS__guess_58d90(undefined4 param_1);  // 0x58d90
undefined8 FUN_00058db0(void);  // 0x58db0
undefined8 ADD_PED_DECORATION_FROM_HASHES_58e10(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x58e10
int FUN_00058e40(int param_1);  // 0x58e40
int FUN_00058e70(void);  // 0x58e70
undefined1 FUN_00058ee0(undefined4 param_1,uint param_2,undefined4 *param_3);  // 0x58ee0
undefined8 FUN_00058f60(undefined4 param_1,uint param_2,undefined4 param_3);  // 0x58f60
bool FUN_00058fc0(uint param_1,undefined8 param_2,undefined4 *param_3);  // 0x58fc0
undefined8 FUN_00059050(uint param_1,undefined8 param_2,undefined4 param_3);  // 0x59050
undefined8 STAT_GET_INT_590b0(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x590b0
undefined8 STAT_SET_INT_590e0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x590e0
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess_59110(void);  // 0x59110
undefined8 STAT_SAVE_PENDING_OR_REQUESTED__guess_2_59120(void);  // 0x59120
undefined8 STAT_LOAD_PENDING__guess_59130(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x59130
undefined8 FUN_00059170(void);  // 0x59170
undefined8 FUN_00059260(void);  // 0x59260
undefined8 FUN_000592d0(void);  // 0x592d0
undefined8 FUN_00059320(void);  // 0x59320
undefined ** FUN_00059330(void);  // 0x59330
undefined8 FUN_00059340(void);  // 0x59340
undefined ** menu_tp_shops_options(void);  // 0x59350
undefined8 menu_tp_shops_count(void);  // 0x59360
undefined ** FUN_00059370(void);  // 0x59370
undefined8 FUN_00059380(void);  // 0x59380
undefined ** menu_tp_story_options(void);  // 0x59390
undefined8 menu_tp_story_count(void);  // 0x593a0
undefined ** menu_tp_interiors_options(void);  // 0x593b0
undefined8 menu_tp_interiors_count(void);  // 0x593c0
undefined8 FUN_000593d0(void);  // 0x593d0
undefined8 FUN_00059510(void);  // 0x59510
undefined8 FUN_000595e0(void);  // 0x595e0
undefined8 FUN_00059620(int param_1);  // 0x59620
undefined4 menu_theme_id(void);  // 0x59660
byte menu_theme_rainbow(void);  // 0x59670
undefined8 FUN_00059690(byte param_1);  // 0x59690
undefined8 menu_theme_tick(void);  // 0x596b0
undefined8 FUN_000597b0(float *param_1);  // 0x597b0
undefined8 GET_FRAME_TIME(void);  // 0x59850
float FUN_00059860(float param_1);  // 0x59860
float FUN_00059920(float param_1);  // 0x59920
undefined8 FUN_00059990(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x59990
undefined8 FUN_00059a00(float *param_1,float *param_2);  // 0x59a00
undefined8 FUN_00059b80(undefined4 param_1,float param_2,float param_3,int *param_4,int *param_5, int *param_6);  // 0x59b80
undefined8 FUN_00059e60(int *param_1);  // 0x59e60
undefined8 FUN_00059ea0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0x59ea0
undefined4 FUN_00059f10(void);  // 0x59f10
undefined8 FUN_00059f20(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x59f20
undefined8 FUN_0005a0b0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x5a0b0
undefined8 FUN_0005a0f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x5a0f0
undefined8 FUN_0005a2f0(int *param_1,int *param_2,int *param_3);  // 0x5a2f0
undefined8 FUN_0005a350(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4);  // 0x5a350
undefined8 FUN_0005a3f0(void);  // 0x5a3f0
undefined8 FUN_0005a490(void);  // 0x5a490
float FUN_0005a4e0(float param_1);  // 0x5a4e0
undefined8 FUN_0005a520(void);  // 0x5a520
undefined8 FUN_0005a5e0(void);  // 0x5a5e0
undefined8 _SET_HUD_COLOUR__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x5a690
undefined8 FUN_0005a6d0(void);  // 0x5a6d0
undefined8 FUN_0005a7b0(long param_1);  // 0x5a7b0
undefined8 FUN_0005a840(long param_1);  // 0x5a840
undefined8 FUN_0005a950(void);  // 0x5a950
undefined8 PLAYER_PED_ID_5adf0(void);  // 0x5adf0
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_2_5ae00(void);  // 0x5ae00
undefined8 NETWORK_IS_IN_SPECTATOR_MODE__guess_5ae10(void);  // 0x5ae10
undefined8 FUN_0005ae20(byte param_1);  // 0x5ae20
undefined8 DOES_ENTITY_EXIST_5ae80(undefined4 param_1);  // 0x5ae80
undefined8 SET_WEAPON_ANIMATION_OVERRIDE__guess(undefined4 param_1,undefined4 param_2);  // 0x5aea0
undefined8 SET_PED_CAN_SWITCH_WEAPON(undefined4 param_1,undefined4 param_2);  // 0x5aed0
undefined8 _0x06A320535F5F0248__guess(undefined4 param_1);  // 0x5af00
undefined8 _0xA48931185F0536FE__guess(void);  // 0x5af20
undefined8 GET_CURRENT_PED_WEAPON_5af30(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x5af30
byte FUN_0005af60(int param_1);  // 0x5af60
bool FUN_0005afa0(int param_1);  // 0x5afa0
undefined8 SET_CURRENT_PED_WEAPON_5aff0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5aff0
undefined8 HAS_PED_GOT_WEAPON_5b020(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5b020
undefined8 PLAYER_ID_5b050(void);  // 0x5b050
undefined8 DISABLE_PLAYER_FIRING__guess(undefined4 param_1,undefined4 param_2);  // 0x5b060
undefined8 SET_DISABLE_AMBIENT_MELEE_MOVE__guess(undefined4 param_1,undefined4 param_2);  // 0x5b090
undefined8 HIDE_PED_WEAPON_FOR_SCRIPTED_CUTSCENE__guess(undefined4 param_1,undefined4 param_2);  // 0x5b0c0
undefined8 SET_PED_CURRENT_WEAPON_VISIBLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x5b0f0
undefined8 SET_PED_CONFIG_FLAG_5b130(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5b130
undefined8 RESET_HUD_COMPONENT_VALUES__guess(undefined4 param_1);  // 0x5b160
undefined8 FUN_0005b180(undefined4 param_1);  // 0x5b180
undefined8 FUN_0005b1c0(void);  // 0x5b1c0
undefined8 STOP_CUTSCENE_IMMEDIATELY__guess_5b780(void);  // 0x5b780
undefined8 _STOP_ALL_SCREEN_EFFECTS__guess_5b790(void);  // 0x5b790
undefined8 GET_PLAYER_SWITCH_STATE__guess_5b7a0(void);  // 0x5b7a0
undefined8 FUN_0005b7b0(void);  // 0x5b7b0
undefined8 SET_ENTITY_INVINCIBLE_5b8d0(undefined4 param_1,undefined4 param_2);  // 0x5b8d0
undefined8 SET_ENTITY_CAN_BE_DAMAGED__guess_5b900(undefined4 param_1,undefined4 param_2);  // 0x5b900
undefined8 SET_ENTITY_PROOFS_5b930(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x5b930
undefined8 NETWORK_DISABLE_INVINCIBLE_FLASHING__guess(undefined4 param_1,undefined4 param_2);  // 0x5b9a0
undefined8 SET_PLAYER_INVINCIBLE_5b9d0(undefined4 param_1,undefined4 param_2);  // 0x5b9d0
undefined8 SET_PED_CAN_RAGDOLL_5ba00(undefined4 param_1,undefined4 param_2);  // 0x5ba00
undefined8 SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(undefined4 param_1,undefined4 param_2);  // 0x5ba30
undefined8 SET_PED_RAGDOLL_ON_COLLISION__guess(undefined4 param_1,undefined4 param_2);  // 0x5ba60
undefined8 SET_ENTITY_VISIBLE_5ba90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5ba90
undefined8 SET_MAX_WANTED_LEVEL__guess_5bac0(undefined4 param_1);  // 0x5bac0
undefined8 SET_POLICE_IGNORE_PLAYER__guess_5bae0(undefined4 param_1,undefined4 param_2);  // 0x5bae0
undefined8 SET_DISPATCH_COPS_FOR_PLAYER__guess_5bb10(undefined4 param_1,undefined4 param_2);  // 0x5bb10
undefined8 GET_PLAYER_WANTED_LEVEL_5bb40(undefined4 param_1);  // 0x5bb40
undefined8 CLEAR_PLAYER_WANTED_LEVEL_5bb60(undefined4 param_1);  // 0x5bb60
undefined8 SET_PLAYER_WANTED_LEVEL__guess_5bb80(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5bb80
undefined8 SET_PLAYER_WANTED_LEVEL_NOW_5bbb0(undefined4 param_1,undefined4 param_2);  // 0x5bbb0
undefined8 SET_PED_INFINITE_AMMO_CLIP(undefined4 param_1,undefined4 param_2);  // 0x5bbe0
undefined8 _0x78857FC65CADB909__guess_5bc10(undefined4 param_1);  // 0x5bc10
undefined8 ENABLE_CONTROL_ACTION__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5bc30
undefined8 FUN_0005bc60(undefined4 param_1,undefined4 param_2);  // 0x5bc60
undefined8 FUN_0005bc90(undefined4 param_1,undefined4 param_2);  // 0x5bc90
undefined8 FUN_0005bcc0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x5bcc0
undefined8 SET_EXPLOSIVE_MELEE_THIS_FRAME(undefined4 param_1);  // 0x5bcf0
undefined8 GET_HUD_COLOUR__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5);  // 0x5bd10
undefined1 FUN_0005bd50(undefined4 param_1);  // 0x5bd50
bool FUN_0005bdc0(int param_1);  // 0x5bdc0
undefined8 FUN_0005be00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined8 param_6);  // 0x5be00
undefined8 invoke_p_ipipipipi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0x5be70
undefined4 FUN_0005bee0(void);  // 0x5bee0
char * FUN_0005bef0(void);  // 0x5bef0
undefined8 FUN_0005bf70(void);  // 0x5bf70
undefined8 menu_tunables_count(void);  // 0x5c000
undefined8 FUN_0005c010(void);  // 0x5c010
int FUN_0005c020(void);  // 0x5c020
undefined1 FUN_0005c080(undefined4 *param_1);  // 0x5c080
undefined4 FUN_0005c0d0(void);  // 0x5c0d0
byte FUN_0005c140(void);  // 0x5c140
undefined8 FUN_0005c180(char *param_1,int param_2);  // 0x5c180
undefined8 FUN_0005c2c0(void);  // 0x5c2c0
undefined1 FUN_0005c3a0(void);  // 0x5c3a0
float FUN_0005c500(void);  // 0x5c500
float FUN_0005c560(void);  // 0x5c560
undefined8 FUN_0005c5c0(void);  // 0x5c5c0
undefined8 FUN_0005c600(void);  // 0x5c600
undefined8 FUN_0005c710(void);  // 0x5c710
undefined8 FUN_0005c870(undefined1 *param_1);  // 0x5c870
undefined8 FUN_0005ca50(void);  // 0x5ca50
undefined8 FUN_0005cab0(void);  // 0x5cab0
undefined8 FUN_0005cb60(void);  // 0x5cb60
int FUN_0005ccd0(void);  // 0x5ccd0
undefined8 FUN_0005d3b0(void);  // 0x5d3b0
undefined8 FUN_0005d450(void);  // 0x5d450
undefined8 menu_tunables_tick(void);  // 0x5d460
char FUN_0005d580(void);  // 0x5d580
undefined8 FUN_0005d720(char *param_1,char *param_2);  // 0x5d720
undefined8 FUN_0005dbb0(void *param_1);  // 0x5dbb0
undefined8 FUN_0005ddb0(void);  // 0x5ddb0
undefined8 FUN_0005def0(void);  // 0x5def0
undefined8 FUN_0005df40(void);  // 0x5df40
undefined8 FUN_0005df90(void);  // 0x5df90
undefined8 FUN_0005dff0(void);  // 0x5dff0
undefined8 FUN_0005e050(void);  // 0x5e050
undefined8 FUN_0005e080(void);  // 0x5e080
undefined8 FUN_0005e0b0(void);  // 0x5e0b0
undefined8 FUN_0005e100(void);  // 0x5e100
undefined8 _0x10BD227A753B0D84__guess_2(void);  // 0x5e150
undefined1 FUN_0005e160(void);  // 0x5e160
undefined8 NETWORK_IS_SESSION_STARTED_5e1d0(void);  // 0x5e1d0
byte FUN_0005e1e0(void);  // 0x5e1e0
undefined8 NETWORK_IS_GAME_IN_PROGRESS_5e230(void);  // 0x5e230
undefined8 NETWORK_IS_IN_SESSION__guess_5e240(void);  // 0x5e240
undefined8 NETWORK_IS_SESSION_ACTIVE(void);  // 0x5e250
undefined8 _STOP_ALL_SCREEN_EFFECTS__guess_2(void);  // 0x5e260
undefined1 FUN_0005e270(void);  // 0x5e270
undefined8 GET_HASH_KEY_5e2e0(undefined8 param_1);  // 0x5e2e0
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_5e300(undefined4 param_1);  // 0x5e300
undefined8 NETWORK_IS_ACTIVITY_SESSION__guess(void);  // 0x5e320
undefined8 FUN_0005e330(byte param_1);  // 0x5e330
undefined8 _0x10BD227A753B0D84__guess(void);  // 0x5e3a0
undefined8 _0x10BD227A753B0D84__guess_3(void);  // 0x5e3b0
undefined8 FUN_0005e3c0(byte param_1);  // 0x5e3c0
undefined8 FUN_0005e420(void);  // 0x5e420
undefined8 FUN_0005e490(long param_1,byte param_2);  // 0x5e490
char * FUN_0005e660(long param_1);  // 0x5e660
undefined8 _NETWORK_ACCESS_TUNABLE_FLOAT_HASH__guess_2(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x5e750
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_3(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x5e780
undefined8 _NETWORK_ACCESS_TUNABLE_FLOAT_HASH__guess(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x5e7b0
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x5e7e0
undefined8 _NETWORK_DOES_TUNABLE_EXIST_HASH__guess(undefined8 param_1,undefined8 param_2);  // 0x5e810
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH__guess_2(undefined4 param_1,undefined4 param_2);  // 0x5e840
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH__guess(undefined8 param_1,undefined8 param_2);  // 0x5e870
undefined8 _0x0EDE326D47CD0F3E__guess(undefined4 param_1,undefined4 param_2);  // 0x5e8a0
undefined1 FUN_0005e8d0(long param_1,long param_2);  // 0x5e8d0
undefined8 NETWORK_SET_SCRIPT_IS_SAFE_FOR_NETWORK_GAME__guess(void);  // 0x5e9c0
undefined8 _0x7DB53B37A2F211A0__guess(void);  // 0x5e9d0
int FUN_0005e9e0(long param_1,int param_2);  // 0x5e9e0
undefined8 FUN_0005ebe0(long param_1,int param_2);  // 0x5ebe0
undefined8 FUN_0005ec70(undefined4 param_1,undefined4 param_2);  // 0x5ec70
undefined8 NETWORK_ACCESS_TUNABLE_BOOL__guess(undefined4 param_1,undefined4 param_2);  // 0x5eca0
undefined8 NETWORK_DOES_TUNABLE_EXIST__guess(undefined4 param_1,undefined4 param_2);  // 0x5ecd0
undefined8 FUN_0005ed00(void);  // 0x5ed00
undefined8 GET_POSIX_TIME__guess(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6);  // 0x5eeb0
undefined8 _0x10BD227A753B0D84__guess_4(void);  // 0x5ef00
undefined8 _0x67A5589628E0CFF6__guess(void);  // 0x5ef10
undefined1 FUN_0005ef20(long param_1,int *param_2,int param_3);  // 0x5ef20
undefined8 _0x4A2D4E8BF4265B0F__guess(undefined8 param_1);  // 0x5eff0
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_4(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x5f010
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_2(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x5f040
undefined8 _NETWORK_ACCESS_TUNABLE_BOOL_HASH_FAIL_VAL__guess_5(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x5f070
undefined8 FUN_0005f0a0(int param_1,undefined4 param_2);  // 0x5f0a0
int FUN_0005f120(void);  // 0x5f120
undefined1 * FUN_0005f170(void);  // 0x5f170
undefined1 FUN_0005f700(ulong param_1);  // 0x5f700
bool FUN_0005f760(ulong param_1);  // 0x5f760
undefined8 FUN_0005f780(int param_1);  // 0x5f780
undefined8 FUN_0005f7c0(uint param_1,ulong *param_2);  // 0x5f7c0
undefined1 FUN_0005f810(float param_1);  // 0x5f810
undefined8 FUN_0005f880(ulong *param_1,uint param_2);  // 0x5f880
bool FUN_0005f8d0(void);  // 0x5f8d0
undefined1 * FUN_0005f980(undefined1 *param_1,long param_2);  // 0x5f980
long FUN_0005fc80(long param_1,long param_2);  // 0x5fc80
bool FUN_0005fcb0(undefined8 *param_1,undefined8 param_2,undefined8 param_3);  // 0x5fcb0
undefined1 FUN_0005fdb0(undefined *param_1,undefined8 param_2,undefined8 param_3,byte param_4);  // 0x5fdb0
undefined1 FUN_0005fe90(byte *param_1,byte param_2);  // 0x5fe90
bool FUN_0005ff60(int param_1,int param_2,int param_3);  // 0x5ff60
long FUN_0005ffb0(uint param_1);  // 0x5ffb0
bool FUN_00060130(uint param_1);  // 0x60130
byte FUN_000601c0(long param_1);  // 0x601c0
undefined8 FUN_00060220(void);  // 0x60220
undefined8 FUN_000603f0(void);  // 0x603f0
undefined8 FUN_000605c0(undefined8 param_1);  // 0x605c0
undefined8 invoke_i_sspf(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x605e0
undefined8 invoke_i_iipf(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0x60640
undefined8 invoke_i_sspi(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x60690
undefined8 invoke_i_ss(undefined8 param_1,undefined8 param_2,undefined8 param_3);  // 0x606f0
undefined8 invoke_f_if(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x60740
undefined8 invoke_p_pipipipipipi(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7);  // 0x60790
undefined8 menu_lsc_forge_tick(void);  // 0x60810
undefined8 FUN_00060e90(void);  // 0x60e90
undefined8 FUN_000612d0(void);  // 0x612d0
undefined8 DOES_ENTITY_EXIST_61970(undefined4 param_1);  // 0x61970
undefined8 IS_ENTITY_A_VEHICLE(undefined4 param_1);  // 0x61990
undefined8 FUN_000619b0(void);  // 0x619b0
undefined8 FUN_00061a30(void);  // 0x61a30
undefined8 _GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH__guess_61aa0(undefined4 param_1);  // 0x61aa0
undefined8 PLAYER_PED_ID_61ac0(void);  // 0x61ac0
bool FUN_00061ad0(undefined4 param_1);  // 0x61ad0
undefined8 FUN_00061b60(void);  // 0x61b60
int FUN_00061c80(void);  // 0x61c80
undefined8 GET_INTERIOR_GROUP_ID__guess_3_61d60(undefined4 param_1);  // 0x61d60
undefined8 FUN_00061d80(int param_1);  // 0x61d80
undefined8 FUN_00062120(int param_1);  // 0x62120
bool FUN_00062210(void);  // 0x62210
undefined8 IS_ENTITY_A_MISSION_ENTITY__guess_622b0(undefined4 param_1);  // 0x622b0
undefined8 SET_ENTITY_AS_MISSION_ENTITY_622d0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x622d0
undefined8 FUN_00062300(undefined4 param_1);  // 0x62300
int FUN_00062350(void);  // 0x62350
undefined8 FUN_00062440(undefined *param_1,uint param_2);  // 0x62440
bool FUN_00062710(int param_1);  // 0x62710
undefined8 DECOR_EXIST_ON__guess_627b0(undefined4 param_1,undefined8 param_2);  // 0x627b0
undefined8 FUN_000627e0(undefined4 param_1);  // 0x627e0
undefined8 DECOR_GET_INT__guess_628a0(undefined4 param_1,undefined8 param_2);  // 0x628a0
undefined8 FUN_000628d0(int param_1);  // 0x628d0
undefined8 menu_spawn_vehicle(char *param_1);  // 0x62960
undefined8 GET_HASH_KEY_62a10(undefined8 param_1);  // 0x62a10
undefined8 IS_MODEL_IN_CDIMAGE_62a30(undefined4 param_1);  // 0x62a30
undefined8 IS_MODEL_VALID_62a50(undefined4 param_1);  // 0x62a50
undefined8 REQUEST_MODEL_62a70(undefined4 param_1);  // 0x62a70
undefined8 menu_spawn_vehicle_tick(void);  // 0x62a90
undefined8 HAS_MODEL_LOADED_62da0(undefined4 param_1);  // 0x62da0
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_62dc0(undefined4 param_1);  // 0x62dc0
undefined8 IS_PED_IN_ANY_VEHICLE_62de0(undefined4 param_1,undefined4 param_2);  // 0x62de0
undefined8 GET_VEHICLE_PED_IS_IN_62e10(undefined4 param_1,undefined4 param_2);  // 0x62e10
undefined8 DELETE_VEHICLE_62e40(undefined8 param_1);  // 0x62e40
undefined8 FUN_00062e60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x62e60
undefined8 GET_ENTITY_HEADING_62eb0(undefined4 param_1);  // 0x62eb0
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_3_62ed0(undefined4 param_1);  // 0x62ed0
undefined8 CAN_REGISTER_MISSION_PEDS__guess_62ef0(undefined4 param_1);  // 0x62ef0
undefined8 FUN_00062f10(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x62f10
undefined8 _NETWORK_HAS_CONTROL_OF_PAVEMENT_STATS__guess_62f70(undefined4 param_1);  // 0x62f70
undefined8 NETWORK_DOES_NETWORK_ID_EXIST__guess_62f90(undefined4 param_1);  // 0x62f90
undefined8 _SET_ENTITY_SOMETHING__guess_62fb0(undefined4 param_1,undefined4 param_2);  // 0x62fb0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_2_62fe0(undefined4 param_1,undefined4 param_2);  // 0x62fe0
undefined8 SET_VEHICLE_HAS_BEEN_OWNED_BY_PLAYER__guess_63010(undefined4 param_1,undefined4 param_2);  // 0x63010
undefined8 _0x0CDDA42F9E360CA6__guess_63040(undefined4 param_1,undefined4 param_2);  // 0x63040
undefined8 SET_VEHICLE_DOORS_LOCKED_63070(undefined4 param_1,undefined4 param_2);  // 0x63070
undefined8 FUN_000630a0(undefined4 param_1,undefined4 param_2);  // 0x630a0
undefined8 FUN_000630d0(undefined4 param_1,int param_2);  // 0x630d0
undefined8 SET_PED_INTO_VEHICLE_631a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x631a0
undefined8 SET_VEHICLE_ENGINE_ON_631d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x631d0
undefined8 SET_VEHICLE_NEEDS_TO_BE_HOTWIRED__guess_63210(undefined4 param_1,undefined4 param_2);  // 0x63210
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_63240(undefined4 param_1);  // 0x63240
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_63260(undefined4 param_1,undefined4 param_2);  // 0x63260
undefined8 SET_ENTITY_VISIBLE_IN_CUTSCENE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x63290
undefined8 SET_ENTITY_VISIBLE_632c0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x632c0
undefined8 SET_ENTITY_LOCALLY_VISIBLE__guess(undefined4 param_1);  // 0x632f0
undefined8 RESET_ENTITY_ALPHA__guess(undefined4 param_1);  // 0x63310
undefined8 FUN_00063330(undefined4 param_1);  // 0x63330
int FUN_00063380(void);  // 0x63380
undefined8 FUN_000635a0(void);  // 0x635a0
undefined8 IS_ENTITY_VISIBLE(undefined4 param_1);  // 0x63710
undefined8 _0x422F32CC7E56ABAD__guess(undefined4 param_1);  // 0x63730
undefined8 GET_ENTITY_ALPHA(undefined4 param_1);  // 0x63750
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_63770(undefined4 param_1);  // 0x63770
undefined8 FUN_00063790(undefined4 param_1);  // 0x63790
undefined8 IS_PED_IN_VEHICLE__guess_638a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x638a0
undefined8 HAS_VEHICLE_ASSET_LOADED__guess(undefined4 param_1);  // 0x638d0
undefined8 _SET_VEHICLE_SILENT__guess(undefined4 param_1,undefined4 param_2);  // 0x638f0
undefined8 _GET_VEHICLE_OWNER__guess(undefined4 param_1,undefined4 param_2);  // 0x63920
undefined8 GET_PLAYERS_LAST_VEHICLE__guess(void);  // 0x63950
bool FUN_00063960(undefined4 param_1);  // 0x63960
bool FUN_00063a00(float param_1,undefined4 param_2,undefined4 param_3);  // 0x63a00
undefined8 FUN_00063ae0(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x63ae0
undefined8 FUN_00063b10(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x63b10
undefined8 NET_TO_ENT__guess(undefined4 param_1);  // 0x63b60
undefined8 PLAYER_ID_63b80(void);  // 0x63b80
long FUN_00063b90(long param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4);  // 0x63b90
undefined8 FUN_00063c70(undefined4 param_1,int param_2,undefined4 param_3);  // 0x63c70
undefined8 FUN_00063cd0(undefined8 *param_1);  // 0x63cd0
undefined8 FUN_00063d80(undefined8 *param_1);  // 0x63d80
undefined8 FUN_00063e20(undefined8 *param_1);  // 0x63e20
undefined8 FUN_00063eb0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x63eb0
bool FUN_00063f60(char *param_1);  // 0x63f60
undefined8 FUN_00063fe0(undefined *param_1,undefined4 param_2,int param_3,undefined4 param_4);  // 0x63fe0
undefined1 FUN_000640c0(int param_1);  // 0x640c0
bool FUN_000641a0(int param_1);  // 0x641a0
undefined8 SET_ENTITY_ALPHA(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x64220
undefined8 REQUEST_VEHICLE_HIGH_DETAIL_MODEL__guess(undefined4 param_1);  // 0x64250
undefined8 SET_ENTITY_COLLISION_64270(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x64270
undefined8 FUN_000642a0(uint param_1);  // 0x642a0
undefined8 NETWORK_HAS_CONTROL_OF_NETWORK_ID__guess_64360(undefined4 param_1);  // 0x64360
undefined8 NETWORK_REQUEST_CONTROL_OF_NETWORK_ID__guess_64380(undefined4 param_1);  // 0x64380
byte FUN_000643a0(undefined4 param_1);  // 0x643a0
undefined8 FUN_000643e0(uint param_1,undefined8 param_2,uint param_3);  // 0x643e0
undefined8 DECOR_SET_INT__guess(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x64470
undefined8 NETWORK_FADE_OUT_ENTITY__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x644a0
undefined8 SET_ENTITY_LOCALLY_INVISIBLE__guess(undefined4 param_1);  // 0x644d0
undefined8 FUN_000644f0(uint param_1);  // 0x644f0
undefined8 SET_OBJECT_AS_NO_LONGER_NEEDED__guess_64550(undefined8 param_1);  // 0x64550
undefined8 FUN_00064570(undefined4 param_1);  // 0x64570
undefined8 GET_PED_IN_VEHICLE_SEAT(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x64610
undefined8 OBJ_TO_NET__guess(undefined4 param_1);  // 0x64640
undefined8 _SET_NETWORK_ID_SYNC_TO_PLAYER__guess_64660(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x64660
undefined8 SET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess_64690(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x64690
undefined8 GET_VEHICLE_DOORS_LOCKED_FOR_PLAYER__guess_646c0(undefined4 param_1,undefined4 param_2);  // 0x646c0
undefined8 NETWORK_IS_PLAYER_ACTIVE_646f0(undefined4 param_1);  // 0x646f0
bool FUN_00064710(int param_1);  // 0x64710
bool FUN_000647b0(int param_1);  // 0x647b0
undefined8 IS_VEHICLE_DRIVEABLE__guess(undefined4 param_1,undefined4 param_2);  // 0x64850
undefined8 _0x428BACCDF5E26EAD__guess_64880(undefined4 param_1,undefined4 param_2);  // 0x64880
undefined8 FUN_000648b0(void);  // 0x648b0
undefined8 FUN_000649d0(long *param_1);  // 0x649d0
undefined8 FUN_00064ab0(long *param_1);  // 0x64ab0
undefined8 FUN_00064bd0(undefined8 *param_1);  // 0x64bd0
undefined8 FUN_00065050(undefined8 param_1);  // 0x65050
undefined8 FUN_000650f0(undefined8 param_1);  // 0x650f0
undefined8 FUN_00065190(undefined4 *param_1);  // 0x65190
bool FUN_00065260(void);  // 0x65260
undefined8 FUN_00065350(void);  // 0x65350
bool FUN_00065360(ulong param_1);  // 0x65360
undefined4 FUN_000653b0(undefined8 param_1);  // 0x653b0
undefined4 FUN_000653f0(long param_1);  // 0x653f0
undefined8 invoke_i_ffffii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined8 param_5,undefined4 param_6,undefined4 param_7);  // 0x65460
undefined8 invoke_i_isi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4);  // 0x654e0
char * FUN_00065530(int param_1);  // 0x65530
undefined * FUN_000655e0(int param_1);  // 0x655e0
undefined8 FUN_00065630(undefined4 param_1);  // 0x65630
undefined8 FUN_000656d0(void);  // 0x656d0
undefined8 FUN_00065770(int param_1);  // 0x65770
undefined8 FUN_000657b0(void);  // 0x657b0
undefined ** FUN_00065a50(void);  // 0x65a50
undefined8 FUN_00065a70(void);  // 0x65a70
undefined ** FUN_00065a80(void);  // 0x65a80
undefined4 FUN_00065a90(void);  // 0x65a90
char * FUN_00065aa0(void);  // 0x65aa0
undefined4 FUN_00065ab0(void);  // 0x65ab0
bool FUN_00065b30(int param_1);  // 0x65b30
undefined8 FUN_00065bb0(void);  // 0x65bb0
bool FUN_00065c00(int param_1);  // 0x65c00
undefined8 DOES_ENTITY_EXIST_65ca0(undefined4 param_1);  // 0x65ca0
undefined8 PLAYER_PED_ID_65cc0(void);  // 0x65cc0
undefined8 GET_PED_IN_VEHICLE_SEAT_65cd0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x65cd0
undefined8 IS_PED_SITTING_IN_VEHICLE__guess(undefined4 param_1,undefined4 param_2);  // 0x65d00
undefined8 FUN_00065d30(void);  // 0x65d30
undefined4 FUN_00065da0(void);  // 0x65da0
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_65e30(undefined4 param_1);  // 0x65e30
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_65e50(undefined4 param_1);  // 0x65e50
undefined8 FUN_00065e70(undefined4 param_1,undefined4 param_2);  // 0x65e70
undefined8 menu_vehicle_options_tick(void);  // 0x65ea0
undefined8 FUN_00066000(int param_1);  // 0x66000
undefined8 FUN_00066170(void);  // 0x66170
undefined8 FUN_000661e0(int param_1);  // 0x661e0
undefined8 FUN_00066280(int param_1);  // 0x66280
undefined8 FUN_00066340(int param_1);  // 0x66340
undefined8 FUN_00066440(int param_1);  // 0x66440
undefined8 FUN_000664a0(int param_1);  // 0x664a0
undefined8 FUN_00066760(int param_1);  // 0x66760
undefined8 FUN_00066990(int param_1);  // 0x66990
undefined8 FUN_00066c00(int param_1);  // 0x66c00
undefined8 IS_PED_IN_ANY_VEHICLE_66e00(undefined4 param_1,undefined4 param_2);  // 0x66e00
undefined8 GET_VEHICLE_PED_IS_IN_66e30(undefined4 param_1,undefined4 param_2);  // 0x66e30
undefined8 GET_ENTITY_SPEED_66e60(undefined4 param_1);  // 0x66e60
undefined8 SET_TEXT_FONT_66e80(undefined4 param_1);  // 0x66e80
undefined8 FUN_00066ea0(undefined4 param_1,undefined4 param_2);  // 0x66ea0
undefined8 SET_TEXT_COLOUR_66ed0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x66ed0
undefined8 SET_TEXT_CENTRE_66f10(undefined4 param_1);  // 0x66f10
undefined8 SET_TEXT_RIGHT_JUSTIFY_66f30(undefined4 param_1);  // 0x66f30
undefined8 FUN_00066f50(undefined4 param_1,undefined4 param_2);  // 0x66f50
undefined8 SET_TEXT_DROPSHADOW_66f80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x66f80
undefined8 SET_TEXT_OUTLINE_66fc0(void);  // 0x66fc0
undefined8 BEGIN_TEXT_COMMAND_DISPLAY_TEXT_66fd0(undefined8 param_1);  // 0x66fd0
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME_66ff0(undefined8 param_1);  // 0x66ff0
undefined8 FUN_00067010(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x67010
undefined8 SET_ENTITY_AS_MISSION_ENTITY_67050(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x67050
undefined8 DELETE_OBJECT_67080(undefined8 param_1);  // 0x67080
undefined8 NETWORK_IS_IN_SESSION__guess_670a0(void);  // 0x670a0
undefined8 NETWORK_GET_ENTITY_FROM_NETWORK_ID__guess_670b0(undefined4 param_1);  // 0x670b0
undefined8 NETWORK_GET_PRIMARY_CLAN_DATA_START__guess_670d0(undefined4 param_1,undefined4 param_2);  // 0x670d0
undefined8 NETWORK_HAS_CONTROL_OF_NETWORK_ID__guess_67100(undefined4 param_1);  // 0x67100
undefined8 NETWORK_REQUEST_CONTROL_OF_NETWORK_ID__guess_67120(undefined4 param_1);  // 0x67120
undefined8 SET_AGGRESSIVE_HORNS__guess(undefined4 param_1);  // 0x67140
undefined8 FUN_00067160(undefined4 param_1,undefined4 param_2);  // 0x67160
undefined8 FUN_00067190(undefined4 param_1,undefined4 param_2);  // 0x67190
undefined8 IS_VEHICLE_ON_ALL_WHEELS(undefined4 param_1);  // 0x671c0
undefined8 FUN_000671e0(undefined4 param_1,undefined4 param_2);  // 0x671e0
undefined8 SET_ENTITY_INVINCIBLE_67210(undefined4 param_1,undefined4 param_2);  // 0x67210
undefined8 SET_ENTITY_CAN_BE_DAMAGED__guess_67240(undefined4 param_1,undefined4 param_2);  // 0x67240
undefined8 SET_ENTITY_PROOFS_67270(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x67270
undefined8 _0x1AA8A837D2169D94__guess(undefined4 param_1,undefined4 param_2);  // 0x672e0
undefined8 SET_VEHICLE_STRONG__guess(undefined4 param_1,undefined4 param_2);  // 0x67310
undefined8 SET_VEHICLE_TYRES_CAN_BURST__guess(undefined4 param_1,undefined4 param_2);  // 0x67340
undefined8 SET_VEHICLE_WHEELS_CAN_BREAK__guess(undefined4 param_1,undefined4 param_2);  // 0x67370
undefined8 SET_VEHICLE_FRICTION_OVERRIDE__guess(undefined4 param_1,undefined4 param_2);  // 0x673a0
undefined8 SET_VEHICLE_CAN_BREAK__guess(undefined4 param_1,undefined4 param_2);  // 0x673d0
undefined8 _0x2311DD7159F00582__guess(undefined4 param_1,undefined4 param_2);  // 0x67400
undefined8 SET_VEHICLE_ENGINE_CAN_DEGRADE__guess(undefined4 param_1,undefined4 param_2);  // 0x67430
undefined8 _0x192547247864DFDD__guess(undefined4 param_1,undefined4 param_2);  // 0x67460
undefined8 SET_DISABLE_VEHICLE_PETROL_TANK_FIRES__guess(undefined4 param_1,undefined4 param_2);  // 0x67490
undefined8 SET_VEHICLE_NAME_DEBUG__guess(undefined4 param_1,undefined4 param_2);  // 0x674c0
undefined8 SET_VEHICLE_EXPLODES_ON_HIGH_EXPLOSION_DAMAGE__guess(undefined4 param_1,undefined4 param_2);  // 0x674f0
undefined8 FUN_00067520(undefined4 param_1,undefined4 param_2);  // 0x67520
undefined8 FUN_00067550(undefined4 param_1,undefined4 param_2);  // 0x67550
undefined8 FUN_00067580(undefined4 param_1,undefined4 param_2);  // 0x67580
undefined8 FUN_000675b0(undefined4 param_1,undefined4 param_2);  // 0x675b0
undefined8 FUN_000675e0(undefined4 param_1,undefined4 param_2);  // 0x675e0
undefined8 SET_VEHICLE_UNDRIVEABLE(undefined4 param_1,undefined4 param_2);  // 0x67610
undefined8 FUN_00067640(undefined4 param_1,undefined4 param_2);  // 0x67640
undefined8 GET_GAME_TIMER_67670(void);  // 0x67670
undefined8 FUN_00067680(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x67680
undefined1 FUN_000676d0(undefined4 param_1);  // 0x676d0
undefined8 GET_VEHICLE_DIRT_LEVEL__guess(undefined4 param_1);  // 0x677e0
undefined8 FUN_00067800(undefined8 param_1,undefined4 param_2);  // 0x67800
undefined8 SET_VEHICLE_FIXED__guess(undefined4 param_1);  // 0x67830
undefined8 SET_VEHICLE_DEFORMATION_FIXED__guess(undefined4 param_1);  // 0x67850
undefined8 FUN_00067870(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x67870
undefined8 GET_IS_VEHICLE_ENGINE_RUNNING(undefined4 param_1);  // 0x678b0
undefined8 SET_VEHICLE_ENGINE_ON_678d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x678d0
undefined8 FUN_00067910(undefined4 param_1,undefined4 param_2);  // 0x67910
undefined8 REMOVE_DECALS_FROM_VEHICLE__guess(undefined4 param_1);  // 0x67940
undefined8 IS_VEHICLE_DRIVEABLE__guess_67960(undefined4 param_1,undefined4 param_2);  // 0x67960
undefined8 GET_VEHICLE_ENGINE_HEALTH(undefined4 param_1);  // 0x67990
undefined8 GET_VEHICLE_BODY_HEALTH(undefined4 param_1);  // 0x679b0
undefined8 GET_VEHICLE_PETROL_TANK_HEALTH__guess(undefined4 param_1);  // 0x679d0
undefined8 ARE_ANY_VEHICLE_SEATS_FREE__guess(undefined4 param_1);  // 0x679f0
undefined8 IS_VEHICLE_TYRE_BURST__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x67a10
undefined8 SET_VEHICLE_TYRE_FIXED__guess(undefined4 param_1,undefined4 param_2);  // 0x67a40
undefined8 IS_ENTITY_IN_AIR(undefined4 param_1);  // 0x67a70
undefined8 _0x5BFF36D6ED83E0AE__guess(void);  // 0x67a90
bool FUN_00067aa0(void);  // 0x67aa0
bool FUN_00067b10(void);  // 0x67b10
bool FUN_00067b80(void);  // 0x67b80
undefined8 FUN_00067bf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14);  // 0x67bf0
undefined8 GET_ENTITY_MODEL_67c90(undefined4 param_1);  // 0x67c90
undefined8 IS_THIS_MODEL_A_BOAT__guess(undefined4 param_1);  // 0x67cb0
undefined8 IS_THIS_MODEL_A_HELI__guess(undefined4 param_1);  // 0x67cd0
undefined8 SET_INPUT_EXCLUSIVE_67cf0(undefined4 param_1,undefined4 param_2);  // 0x67cf0
bool FUN_00067d20(undefined4 param_1);  // 0x67d20
undefined8 FUN_00067d50(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x67d50
undefined8 FUN_00067d80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x67d80
undefined8 IS_CONTROL_JUST_PRESSED(undefined4 param_1,undefined4 param_2);  // 0x67dd0
undefined8 IS_CONTROL_PRESSED_67e00(undefined4 param_1,undefined4 param_2);  // 0x67e00
undefined8 GET_HASH_KEY_67e30(undefined8 param_1);  // 0x67e30
undefined8 FUN_00067e50(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x67e50
undefined8 FUN_00067e80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4);  // 0x67e80
undefined8 IS_ENTITY_AN_OBJECT(undefined4 param_1);  // 0x67ec0
undefined8 REQUEST_MODEL_67ee0(undefined4 param_1);  // 0x67ee0
undefined8 HAS_MODEL_LOADED_67f00(undefined4 param_1);  // 0x67f00
undefined8 FUN_00067f20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x67f20
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_67f70(undefined4 param_1);  // 0x67f70
undefined8 SET_ENTITY_VISIBLE_67f90(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x67f90
undefined8 FREEZE_ENTITY_POSITION_67fc0(undefined4 param_1,undefined4 param_2);  // 0x67fc0
undefined8 FUN_00067ff0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x67ff0
undefined8 invoke_p_iiffffffiiiiii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14,undefined4 param_15);  // 0x68050
undefined8 invoke_i_fffpf(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined8 param_5);  // 0x68130
undefined8 FUN_000681a0(void);  // 0x681a0
undefined4 FUN_000681b0(void);  // 0x681b0
undefined8 FUN_00068230(void);  // 0x68230
undefined8 FUN_000682a0(int param_1);  // 0x682a0
undefined8 FUN_00068340(undefined1 *param_1,int param_2,long param_3);  // 0x68340
undefined8 FUN_000684c0(undefined8 param_1);  // 0x684c0
undefined1 * FUN_000685b0(void);  // 0x685b0
undefined4 * FUN_000685c0(void);  // 0x685c0
undefined4 * FUN_000685d0(void);  // 0x685d0
undefined4 * FUN_000685e0(void);  // 0x685e0
undefined4 * FUN_000685f0(void);  // 0x685f0
undefined4 * FUN_00068600(void);  // 0x68600
undefined * FUN_00068610(void);  // 0x68610
undefined * FUN_00068660(void);  // 0x68660
undefined ** FUN_000686b0(void);  // 0x686b0
undefined8 GET_MOD_TEXT_LABEL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x687b0
undefined8 DOES_TEXT_LABEL_EXIST__guess_687e0(undefined8 param_1);  // 0x687e0
undefined8 _GET_LABEL_TEXT__guess_68800(undefined8 param_1);  // 0x68800
undefined * FUN_00068820(void);  // 0x68820
undefined ** FUN_00068870(void);  // 0x68870
undefined8 FUN_000688e0(void);  // 0x688e0
undefined8 FUN_00068910(int param_1);  // 0x68910
undefined8 FUN_00068a00(void);  // 0x68a00
undefined8 FUN_00068a30(int param_1);  // 0x68a30
undefined8 FUN_00068a90(void);  // 0x68a90
undefined8 FUN_00068ac0(int param_1);  // 0x68ac0
undefined8 FUN_00068b50(void);  // 0x68b50
undefined8 FUN_00068bf0(undefined4 param_1);  // 0x68bf0
undefined8 FUN_00068c10(undefined4 param_1,undefined4 param_2);  // 0x68c10
undefined8 TOGGLE_VEHICLE_MOD(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x68c60
undefined8 SET_VEHICLE_TYRES_CAN_BURST__guess_68c90(undefined4 param_1,undefined4 param_2);  // 0x68c90
undefined8 FUN_00068cc0(void);  // 0x68cc0
undefined8 FUN_00069240(void);  // 0x69240
undefined8 SET_VEHICLE_NUMBER_PLATE_TEXT(undefined4 param_1,undefined8 param_2);  // 0x692d0
undefined8 SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(undefined4 param_1,undefined4 param_2);  // 0x69300
undefined8 FUN_00069330(void);  // 0x69330
undefined8 FUN_00069370(int param_1);  // 0x69370
undefined8 DOES_ENTITY_EXIST_694f0(undefined4 param_1);  // 0x694f0
undefined8 FUN_00069510(int param_1);  // 0x69510
bool FUN_00069550(int param_1);  // 0x69550
undefined8 REMOVE_VEHICLE_MOD__guess(undefined4 param_1,undefined4 param_2);  // 0x695c0
int FUN_000695f0(undefined4 param_1,undefined4 param_2);  // 0x695f0
undefined8 SET_VEHICLE_MOD(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x696a0
undefined8 SET_VEHICLE_COLOUR_COMBINATION__guess(undefined4 param_1,undefined4 param_2);  // 0x696e0
undefined8 _SET_VEHICLE_NEON_LIGHT_ENABLED__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x69710
undefined8 SET_VEHICLE_WINDOW_TINT(undefined4 param_1,undefined4 param_2);  // 0x69740
undefined8 FUN_00069770(undefined4 param_1);  // 0x69770
undefined8 FUN_00069880(undefined8 param_1,undefined4 param_2);  // 0x69880
undefined8 SET_VEHICLE_FIXED__guess_698b0(undefined4 param_1);  // 0x698b0
undefined8 SET_VEHICLE_DEFORMATION_FIXED__guess_698d0(undefined4 param_1);  // 0x698d0
undefined8 FUN_000698f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x698f0
undefined8 FUN_00069930(undefined4 param_1,undefined4 param_2);  // 0x69930
undefined8 FUN_00069960(undefined4 param_1,undefined4 param_2);  // 0x69960
undefined8 FUN_00069990(undefined4 param_1,undefined4 param_2);  // 0x69990
undefined8 SET_VEHICLE_UNDRIVEABLE_699c0(undefined4 param_1,undefined4 param_2);  // 0x699c0
undefined8 SET_VEHICLE_TYRE_FIXED__guess_699f0(undefined4 param_1,undefined4 param_2);  // 0x699f0
undefined8 SET_VEHICLE_ENGINE_ON_69a20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x69a20
undefined8 FUN_00069a60(undefined4 param_1,undefined4 param_2);  // 0x69a60
undefined8 FUN_00069a90(undefined4 param_1,undefined4 param_2);  // 0x69a90
undefined8 REMOVE_DECALS_FROM_VEHICLE__guess_69ac0(undefined4 param_1);  // 0x69ac0
undefined8 GET_ENTITY_HEADING_69ae0(undefined4 param_1);  // 0x69ae0
undefined8 FUN_00069b00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x69b00
undefined8 FUN_00069b50(undefined4 param_1,undefined4 param_2);  // 0x69b50
undefined8 FUN_00069b80(undefined4 param_1,undefined4 param_2);  // 0x69b80
int FUN_00069c70(int param_1);  // 0x69c70
undefined8 CLEAR_VEHICLE_CUSTOM_PRIMARY_COLOUR__guess(undefined4 param_1);  // 0x69cc0
undefined8 CLEAR_VEHICLE_CUSTOM_SECONDARY_COLOUR__guess(undefined4 param_1);  // 0x69ce0
undefined8 FUN_00069d00(undefined4 param_1);  // 0x69d00
undefined4 FUN_00069dd0(undefined4 param_1);  // 0x69dd0
undefined8 menu_vehicle_upgrades_tick(void);  // 0x69e60
undefined8 FUN_0006a160(int param_1);  // 0x6a160
undefined8 SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6a1b0
undefined8 SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6a1f0
undefined8 _SET_VEHICLE_NEON_LIGHTS_COLOUR__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6a230
undefined8 SET_VEHICLE_TYRE_SMOKE_COLOR(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6a270
undefined8 FUN_0006a2b0(void);  // 0x6a2b0
int FUN_0006a6e0(undefined4 param_1,undefined4 param_2,int param_3);  // 0x6a6e0
undefined8 FUN_0006a760(undefined4 param_1,undefined4 param_2,undefined4 param_3,byte param_4);  // 0x6a760
undefined8 FUN_0006a7d0(undefined4 param_1);  // 0x6a7d0
undefined8 FUN_0006a870(undefined4 param_1,undefined4 param_2,undefined4 *param_3);  // 0x6a870
undefined8 FUN_0006a8c0(undefined4 param_1);  // 0x6a8c0
undefined8 FUN_0006ab90(undefined4 param_1);  // 0x6ab90
undefined8 FUN_0006abd0(undefined4 param_1);  // 0x6abd0
undefined8 FUN_0006ac10(undefined4 param_1);  // 0x6ac10
undefined8 FUN_0006ad40(undefined4 param_1);  // 0x6ad40
undefined8 FUN_0006add0(undefined4 param_1);  // 0x6add0
undefined8 FUN_0006ae50(undefined **param_1);  // 0x6ae50
undefined8 IS_VEHICLE_EXTRA_TURNED_ON__guess(undefined4 param_1,undefined4 param_2);  // 0x6b120
undefined8 SET_VEHICLE_EXTRA__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6b150
undefined8 FUN_0006b180(undefined4 param_1,undefined4 param_2);  // 0x6b180
undefined8 IS_TOGGLE_MOD_ON__guess_6b1b0(undefined4 param_1,undefined4 param_2);  // 0x6b1b0
undefined8 GET_VEHICLE_COLOURS__guess_6b1e0(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x6b1e0
undefined8 GET_VEHICLE_EXTRA_COLOURS__guess_6b210(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x6b210
undefined8 SET_RENDER_TRAIN_AS_DERAILED__guess_2(undefined4 param_1,undefined8 param_2);  // 0x6b240
undefined8 _0x206BC5DC9D1AC70A__guess_2(undefined4 param_1,undefined8 param_2);  // 0x6b270
undefined8 GET_VEHICLE_CUSTOM_PRIMARY_COLOUR__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x6b2a0
undefined8 GET_VEHICLE_CUSTOM_SECONDARY_COLOUR__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x6b2e0
undefined8 _IS_VEHICLE_NEON_LIGHT_ENABLED__guess(undefined4 param_1,undefined4 param_2);  // 0x6b320
undefined8 _GET_VEHICLE_NEON_LIGHTS_COLOUR__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x6b350
undefined8 GET_VEHICLE_COLOUR_COMBINATION__guess(undefined4 param_1);  // 0x6b390
undefined8 GET_VEHICLE_TYRE_SMOKE_COLOR__guess(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4);  // 0x6b3b0
undefined8 GET_VEHICLE_WHEEL_TYPE__guess_6b3f0(undefined4 param_1);  // 0x6b3f0
undefined8 GET_VEHICLE_MOD_VARIATION__guess(undefined4 param_1,undefined4 param_2);  // 0x6b410
undefined8 GET_VEHICLE_WINDOW_TINT__guess_6b440(undefined4 param_1);  // 0x6b440
undefined8 GET_VEHICLE_NUMBER_PLATE_TEXT_INDEX__guess_6b460(undefined4 param_1);  // 0x6b460
undefined8 FUN_0006b480(void);  // 0x6b480
undefined8 GET_VEHICLE_TYRES_CAN_BURST__guess(undefined4 param_1);  // 0x6b4d0
undefined8 FUN_0006b4f0(void);  // 0x6b4f0
undefined8 SET_VEHICLE_STEER_BIAS__guess(undefined4 param_1,undefined4 param_2);  // 0x6b6f0
undefined4 menu_vehicle_extras_count(void);  // 0x6b720
undefined ** menu_vehicle_extras_options(void);  // 0x6b730
undefined8 FUN_0006b740(void);  // 0x6b740
undefined8 FUN_0006b750(void);  // 0x6b750
undefined8 PLAYER_PED_ID_6b760(void);  // 0x6b760
undefined8 IS_PED_IN_ANY_VEHICLE_6b770(undefined4 param_1,undefined4 param_2);  // 0x6b770
undefined8 GET_VEHICLE_PED_IS_IN_6b7a0(undefined4 param_1,undefined4 param_2);  // 0x6b7a0
undefined8 GET_VEHICLE_NUMBER_PLATE_TEXT_6b7d0(undefined4 param_1);  // 0x6b7d0
int FUN_0006b7f0(char param_1);  // 0x6b7f0
bool FUN_0006b840(char param_1);  // 0x6b840
undefined8 FUN_0006b8a0(undefined8 param_1);  // 0x6b8a0
undefined8 FUN_0006b8f0(int param_1);  // 0x6b8f0
undefined8 SET_VEHICLE_MOD_KIT(undefined4 param_1,undefined4 param_2);  // 0x6b9a0
undefined8 GET_NUM_VEHICLE_MODS__guess(undefined4 param_1,undefined4 param_2);  // 0x6b9d0
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_6ba00(undefined4 param_1);  // 0x6ba00
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_6ba20(undefined4 param_1);  // 0x6ba20
bool FUN_0006ba40(int param_1);  // 0x6ba40
byte FUN_0006ba70(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6ba70
undefined1 FUN_0006bc00(char *param_1,char *param_2);  // 0x6bc00
undefined8 SET_VEHICLE_COLOURS(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6bd80
undefined8 GET_RANDOM_INT_IN_RANGE_6bdb0(undefined4 param_1,undefined4 param_2);  // 0x6bdb0
undefined8 SET_VEHICLE_EXTRA_COLOURS__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6bde0
undefined8 SET_RENDER_TRAIN_AS_DERAILED__guess(undefined4 param_1,undefined4 param_2);  // 0x6be10
undefined8 _0x206BC5DC9D1AC70A__guess(undefined4 param_1,undefined4 param_2);  // 0x6be40
undefined8 SET_VEHICLE_WHEEL_TYPE(undefined4 param_1,undefined4 param_2);  // 0x6be70
undefined8 GET_VEHICLE_MOD__guess_6bea0(undefined4 param_1,undefined4 param_2);  // 0x6bea0
int FUN_0006bed0(void);  // 0x6bed0
undefined8 GET_NUMBER_OF_VEHICLE_NUMBER_PLATES__guess(void);  // 0x6bf10
undefined8 invoke_s_iii(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6bf20
undefined8 invoke_p_ipi(undefined8 param_1,undefined4 param_2,undefined8 param_3);  // 0x6bf70
undefined8 invoke_p_ipipipi(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5);  // 0x6bfc0
undefined8 FUN_0006c020(void);  // 0x6c020
undefined8 GET_NUM_DLC_WEAPONS__guess_6c1a0(void);  // 0x6c1a0
undefined4 FUN_0006c1b0(undefined4 param_1);  // 0x6c1b0
undefined8 IS_WEAPON_VALID(undefined4 param_1);  // 0x6c210
undefined8 GET_HASH_KEY_6c230(undefined8 param_1);  // 0x6c230
bool FUN_0006c250(int param_1);  // 0x6c250
undefined8 FUN_0006c2a0(char *param_1,int param_2,int param_3,uint param_4);  // 0x6c2a0
undefined8 FUN_0006c440(void);  // 0x6c440
undefined4 menu_weapons_give_count(void);  // 0x6c550
undefined ** menu_weapons_give_options(void);  // 0x6c560
undefined8 FUN_0006c570(void);  // 0x6c570
undefined8 PLAYER_PED_ID_6c950(void);  // 0x6c950
undefined8 DOES_ENTITY_EXIST_6c960(undefined4 param_1);  // 0x6c960
undefined8 HAS_PED_GOT_WEAPON_6c980(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6c980
undefined8 _0xA13E93403F26C812__guess(undefined4 param_1);  // 0x6c9b0
int FUN_0006c9d0(int param_1);  // 0x6c9d0
undefined4 menu_weapons_loadout_count(void);  // 0x6ca50
undefined ** menu_weapons_loadout_options(void);  // 0x6ca60
undefined8 FUN_0006ca70(int param_1);  // 0x6ca70
undefined8 FUN_0006cc60(undefined1 *param_1,int param_2,long param_3);  // 0x6cc60
undefined8 GET_WEAPON_TINT_COUNT(undefined4 param_1);  // 0x6cd20
undefined8 GET_PED_WEAPON_TINT_INDEX(undefined4 param_1,undefined4 param_2);  // 0x6cd40
undefined8 FUN_0006cd70(void);  // 0x6cd70
undefined4 FUN_0006d200(void);  // 0x6d200
undefined ** FUN_0006d210(void);  // 0x6d210
char * FUN_0006d220(void);  // 0x6d220
undefined4 * FUN_0006d230(void);  // 0x6d230
undefined4 * FUN_0006d240(void);  // 0x6d240
char * FUN_0006d250(void);  // 0x6d250
undefined ** FUN_0006d2f0(void);  // 0x6d2f0
undefined8 FUN_0006d3c0(undefined1 *param_1,int param_2,char *param_3);  // 0x6d3c0
undefined8 FUN_0006d510(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6d510
undefined8 FUN_0006d540(int param_1,int param_2,int param_3);  // 0x6d540
undefined8 FUN_0006d5b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6d5b0
undefined8 FUN_0006d5e0(int param_1,int param_2,int param_3,undefined4 param_4);  // 0x6d5e0
undefined8 FUN_0006d680(byte *param_1);  // 0x6d680
undefined8 HAS_PED_GOT_WEAPON_COMPONENT__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6da00
undefined8 FUN_0006da30(int param_1,int param_2,int param_3);  // 0x6da30
undefined8 GIVE_WEAPON_COMPONENT_TO_PED__guess_6daa0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6daa0
undefined8 REMOVE_WEAPON_COMPONENT_FROM_PED__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6dad0
undefined8 FUN_0006db00(undefined4 param_1);  // 0x6db00
undefined8 SET_PED_WEAPON_TINT_INDEX_6dce0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6dce0
undefined8 FUN_0006dd10(undefined4 param_1,int param_2);  // 0x6dd10
undefined8 FUN_0006df60(undefined4 *param_1);  // 0x6df60
undefined8 FUN_0006e210(undefined4 param_1,int param_2);  // 0x6e210
undefined8 GET_MAX_AMMO_6e380(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x6e380
undefined8 SET_PED_AMMO_6e3b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x6e3b0
undefined ** FUN_0006e3f0(int param_1);  // 0x6e3f0
undefined8 FUN_0006e5f0(undefined4 param_1,int param_2,int param_3);  // 0x6e5f0
undefined8 GET_PED_AMMO_TYPE_FROM_WEAPON__guess(undefined4 param_1,undefined4 param_2);  // 0x6e680
undefined8 GET_PED_AMMO_TYPE_FROM_WEAPON__guess_2(undefined4 param_1,undefined4 param_2);  // 0x6e6b0
undefined8 GET_MAX_AMMO_IN_CLIP(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6e6e0
undefined8 SET_AMMO_IN_CLIP(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6e710
undefined8 _PED_SKIP_NEXT_RELOADING__guess_6e740(undefined4 param_1);  // 0x6e740
undefined8 FUN_0006e760(int param_1,int param_2);  // 0x6e760
undefined ** FUN_0006eab0(int param_1);  // 0x6eab0
undefined8 FUN_0006eb50(int param_1,byte param_2,undefined4 param_3);  // 0x6eb50
undefined8 FUN_0006ebc0(int param_1,undefined4 param_2,undefined4 param_3);  // 0x6ebc0
undefined4 FUN_0006ec10(int param_1,undefined4 param_2);  // 0x6ec10
undefined8 FUN_0006ec80(int param_1,int param_2,undefined4 param_3);  // 0x6ec80
undefined8 FUN_0006ecf0(undefined4 param_1);  // 0x6ecf0
undefined4 FUN_0006ed20(int param_1);  // 0x6ed20
undefined * FUN_0006efa0(int param_1);  // 0x6efa0
undefined8 FUN_0006f050(int param_1);  // 0x6f050
undefined8 FUN_0006f2e0(int param_1,int param_2,undefined4 param_3);  // 0x6f2e0
undefined8 FUN_0006f350(undefined4 param_1,byte param_2,undefined4 param_3);  // 0x6f350
undefined4 FUN_0006f420(int param_1,int param_2);  // 0x6f420
undefined8 FUN_0006f510(undefined4 param_1,undefined4 param_2);  // 0x6f510
undefined8 FUN_0006f540(undefined4 param_1);  // 0x6f540
undefined8 GET_AMMO_IN_PED_WEAPON(undefined4 param_1,undefined4 param_2);  // 0x6f660
undefined8 FUN_0006f690(undefined4 param_1,int param_2,int param_3,undefined4 param_4);  // 0x6f690
undefined8 FUN_0006f790(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6f790
undefined8 FUN_0006f8b0(int param_1,int param_2,undefined4 param_3);  // 0x6f8b0
undefined8 _0xC098810437312FFF__guess_6f9c0(undefined4 param_1);  // 0x6f9c0
undefined4 FUN_0006f9e0(undefined4 param_1,undefined4 param_2);  // 0x6f9e0
byte FUN_0006fa40(undefined4 param_1,undefined4 param_2);  // 0x6fa40
undefined8 SET_PED_CHANCE_OF_FIRING_BLANKS__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x6fab0
undefined8 FUN_0006fae0(int param_1,int param_2,undefined4 param_3);  // 0x6fae0
undefined8 GET_PED_AMMO_BY_TYPE__guess(undefined4 param_1,undefined4 param_2);  // 0x6fbf0
undefined8 GET_DLC_WEAPON_DATA__guess_6fc20(undefined4 param_1,undefined8 param_2);  // 0x6fc20
undefined * FUN_0006fc50(int param_1);  // 0x6fc50
undefined8 FUN_0006fd00(char *param_1,int param_2,char *param_3);  // 0x6fd00
undefined8 GIVE_WEAPON_TO_PED_700d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x700d0
undefined8 FUN_00070110(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x70110
undefined8 SET_CURRENT_PED_WEAPON_70250(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x70250
undefined8 DOES_WEAPON_TAKE_WEAPON_COMPONENT__guess_70280(undefined4 param_1,undefined4 param_2);  // 0x70280
undefined8 FUN_000702b0(undefined8 param_1,undefined *param_2,undefined *param_3,undefined *param_4);  // 0x702b0
undefined8 FUN_00070350(void);  // 0x70350
undefined8 FUN_000703e0(void);  // 0x703e0
undefined8 FUN_00070440(void);  // 0x70440
undefined8 FUN_000704b0(void);  // 0x704b0
undefined4 FUN_000705d0(int param_1);  // 0x705d0
undefined8 FUN_00070870(void);  // 0x70870
undefined8 FUN_000709d0(char *param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5);  // 0x709d0
undefined8 REMOVE_WEAPON_FROM_PED(undefined4 param_1,undefined4 param_2);  // 0x70a90
undefined8 FUN_00070ac0(undefined4 param_1);  // 0x70ac0
undefined8 GET_DLC_WEAPON_COMPONENT_DATA__guess_70bd0(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x70bd0
undefined8 _GET_LABEL_TEXT__guess_70c00(undefined8 param_1);  // 0x70c00
undefined8 IS_STRING_NULL_OR_EMPTY__guess(undefined8 param_1);  // 0x70c20
undefined8 DOES_TEXT_LABEL_EXIST__guess_70c40(undefined8 param_1);  // 0x70c40
undefined4 FUN_00070c60(int param_1);  // 0x70c60
undefined8 GET_WEAPON_HUD_STATS__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x710e0
undefined8 SET_PED_AMMO_BY_TYPE__guess(undefined4 param_1,undefined4 param_2,undefined8 param_3);  // 0x71120
undefined8 SET_PED_AMMO_BY_TYPE__guess_2(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x71150
undefined8 STAT_SAVE__guess_71180(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x71180
undefined8 STAT_SET_BOOL_711b0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x711b0
undefined8 STAT_SET_INT_711e0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x711e0
undefined8 STAT_GET_INT_71210(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x71210
undefined8 FUN_00071240(long param_1,int param_2,ulong param_3);  // 0x71240
undefined1 FUN_000712c0(long param_1);  // 0x712c0
undefined8 FUN_000714a0(char *param_1);  // 0x714a0
undefined8 CLEAR_OVERRIDE_WEATHER__guess(void);  // 0x71520
undefined8 SET_WEATHER_TYPE_NOW_PERSIST__guess(undefined8 param_1);  // 0x71530
undefined8 SET_OVERRIDE_WEATHER(undefined8 param_1);  // 0x71550
undefined8 FUN_00071570(void);  // 0x71570
undefined8 GET_CLOCK_HOURS__guess(void);  // 0x715a0
undefined8 GET_CLOCK_HOURS__guess_2(void);  // 0x715b0
undefined8 FUN_000715c0(void);  // 0x715c0
undefined8 FUN_000716d0(int param_1,int param_2,int param_3);  // 0x716d0
undefined8 FUN_000717c0(void);  // 0x717c0
undefined8 FUN_00071890(void);  // 0x71890
undefined8 FUN_00071920(void);  // 0x71920
undefined8 FUN_00071980(void);  // 0x71980
undefined8 PAUSE_CLOCK__guess(undefined4 param_1);  // 0x719c0
undefined8 NETWORK_CLEAR_CLOCK_TIME_OVERRIDE__guess(void);  // 0x719e0
undefined8 FUN_000719f0(void);  // 0x719f0
undefined8 FUN_00071a10(void);  // 0x71a10
undefined8 FUN_00071a30(void);  // 0x71a30
undefined8 FUN_00071a50(void);  // 0x71a50
undefined8 FUN_00071a70(void);  // 0x71a70
undefined8 CLEAR_WEATHER_TYPE_PERSIST__guess(void);  // 0x71ac0
undefined ** menu_world_options(void);  // 0x71ad0
undefined8 menu_world_count(void);  // 0x71ae0
undefined ** menu_world_weather_options(void);  // 0x71af0
undefined8 menu_world_weather_count(void);  // 0x71b00
undefined8 FUN_00071b10(void);  // 0x71b10
undefined8 FUN_00071c20(void);  // 0x71c20
undefined8 FUN_00071c70(void);  // 0x71c70
undefined8 FUN_00071ca0(void);  // 0x71ca0
undefined8 menu_world_fun_tick(void);  // 0x71cd0
undefined8 _STOP_ALL_SCREEN_EFFECTS__guess_72200(void);  // 0x72200
undefined8 GET_PLAYER_SWITCH_STATE__guess_72210(void);  // 0x72210
undefined8 PLAYER_PED_ID_72220(void);  // 0x72220
undefined8 DOES_ENTITY_EXIST_72230(undefined4 param_1);  // 0x72230
undefined8 IS_ENTITY_DEAD_72250(undefined4 param_1,undefined4 param_2);  // 0x72250
undefined8 FUN_00072280(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x72280
undefined8 FUN_000722b0(float *param_1);  // 0x722b0
undefined8 FUN_00072540(void);  // 0x72540
undefined8 FUN_00072570(void);  // 0x72570
undefined8 FUN_000725a0(long param_1,undefined4 param_2);  // 0x725a0
undefined8 FUN_00072860(void);  // 0x72860
undefined8 FUN_00072990(undefined4 param_1,undefined4 param_2,undefined4 param_3,long param_4, undefined8 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8);  // 0x72990
int FUN_00072ad0(int param_1);  // 0x72ad0
undefined8 FUN_00072b20(long param_1);  // 0x72b20
undefined8 FUN_00072b70(float *param_1);  // 0x72b70
undefined8 FUN_00072d90(void);  // 0x72d90
undefined8 FUN_00072dc0(float *param_1);  // 0x72dc0
undefined8 FUN_00072f50(void);  // 0x72f50
undefined8 FUN_00072fd0(undefined4 param_1,undefined8 param_2);  // 0x72fd0
undefined8 FUN_00073140(undefined4 param_1,float *param_2);  // 0x73140
ulong FUN_00073700(undefined4 param_1,float *param_2);  // 0x73700
undefined8 FUN_00073b50(void);  // 0x73b50
undefined8 FUN_00073b80(void);  // 0x73b80
undefined8 FUN_00073ba0(undefined4 param_1,float *param_2);  // 0x73ba0
undefined8 FUN_000740c0(undefined4 param_1,float *param_2);  // 0x740c0
undefined8 FUN_00074720(undefined4 param_1,float *param_2);  // 0x74720
undefined8 FUN_00074f70(void);  // 0x74f70
undefined8 FUN_00074fa0(undefined4 param_1);  // 0x74fa0
undefined8 FUN_000750e0(undefined4 param_1);  // 0x750e0
undefined8 FUN_00075220(undefined4 param_1);  // 0x75220
undefined8 FUN_000752d0(undefined4 param_1);  // 0x752d0
undefined8 FUN_000753c0(undefined4 param_1);  // 0x753c0
undefined8 FUN_000754c0(undefined4 param_1);  // 0x754c0
undefined8 FUN_000757e0(undefined4 param_1,float *param_2);  // 0x757e0
undefined8 NETWORK_OVERRIDE_CLOCK_TIME(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x75970
undefined8 SET_CLOCK_TIME(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x759a0
undefined8 NETWORK_IS_SESSION_STARTED_759d0(void);  // 0x759d0
undefined8 NETWORK_IS_GAME_IN_PROGRESS_759e0(void);  // 0x759e0
undefined8 REQUEST_NAMED_PTFX_ASSET(undefined8 param_1);  // 0x759f0
undefined8 FUN_00075a10(undefined8 param_1,undefined4 param_2,undefined4 param_3);  // 0x75a10
undefined8 HAS_NAMED_PTFX_ASSET_LOADED(undefined8 param_1);  // 0x75a40
undefined8 USE_PARTICLE_FX_ASSET(undefined8 param_1);  // 0x75a60
undefined8 FUN_00075a80(void);  // 0x75a80
undefined8 FUN_00075af0(undefined4 param_1);  // 0x75af0
undefined8 _SET_FORCE_PED_FOOTSTEPS_TRACKS__guess(undefined4 param_1);  // 0x75b20
undefined8 _SET_FORCE_VEHICLE_TRAILS__guess(undefined4 param_1);  // 0x75b40
undefined8 GET_HASH_KEY_75b60(undefined8 param_1);  // 0x75b60
undefined8 SET_WEATHER_TYPE_PERSIST__guess(undefined8 param_1);  // 0x75b80
undefined8 SET_WEATHER_TYPE_NOW__guess(undefined8 param_1);  // 0x75ba0
undefined8 FUN_00075bc0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x75bc0
undefined8 SET_RIOT_MODE_ENABLED(undefined4 param_1);  // 0x75bf0
undefined8 SET_CREATE_RANDOM_COPS__guess(undefined4 param_1);  // 0x75c10
undefined8 SET_GRAVITY_LEVEL(undefined4 param_1);  // 0x75c30
undefined8 FUN_00075c50(void);  // 0x75c50
undefined8 REQUEST_MODEL_75d00(undefined4 param_1);  // 0x75d00
undefined8 HAS_MODEL_LOADED_75d20(undefined4 param_1);  // 0x75d20
float FUN_00075d40(float param_1);  // 0x75d40
undefined8 GET_RANDOM_INT_IN_RANGE_75da0(undefined4 param_1,undefined4 param_2);  // 0x75da0
undefined8 FUN_00075dd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x75dd0
undefined8 FUN_00075f70(void);  // 0x75f70
int FUN_00075fb0(void);  // 0x75fb0
undefined8 FUN_00075ff0(float *param_1);  // 0x75ff0
undefined8 FUN_00076150(int param_1);  // 0x76150
undefined8 RESERVE_NETWORK_MISSION_OBJECTS__guess_3_76220(undefined4 param_1);  // 0x76220
undefined8 FUN_00076240(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8);  // 0x76240
undefined8 SET_ENTITY_AS_MISSION_ENTITY_762a0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x762a0
undefined8 SET_VEHICLE_ENGINE_ON_762d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x762d0
undefined8 FUN_00076310(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x76310
undefined8 SET_VEHICLE_OUT_OF_CONTROL__guess_76350(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x76350
undefined8 DELETE_VEHICLE_76380(undefined8 param_1);  // 0x76380
undefined8 SET_MODEL_AS_NO_LONGER_NEEDED_763a0(undefined4 param_1);  // 0x763a0
undefined8 IS_MODEL_IN_CDIMAGE_763c0(undefined4 param_1);  // 0x763c0
undefined8 IS_MODEL_VALID_763e0(undefined4 param_1);  // 0x763e0
undefined8 FUN_00076400(undefined4 param_1);  // 0x76400
int FUN_00076430(void);  // 0x76430
undefined8 FUN_000764f0(float *param_1,undefined4 param_2);  // 0x764f0
undefined8 FUN_00076770(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x76770
undefined8 SET_ENTITY_VISIBLE_767c0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x767c0
undefined8 FUN_000767f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6);  // 0x767f0
undefined8 FUN_00076840(int param_1,undefined4 param_2);  // 0x76840
undefined8 FUN_00076a40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6);  // 0x76a40
undefined4 FUN_00076a90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x76a90
undefined8 FUN_00076c40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x76c40
undefined8 FUN_00076c90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x76c90
undefined8 FREEZE_ENTITY_POSITION_76ce0(undefined4 param_1,undefined4 param_2);  // 0x76ce0
undefined8 SET_ENTITY_COLLISION_76d10(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x76d10
undefined8 RESET_ENTITY_ALPHA__guess_76d40(undefined4 param_1);  // 0x76d40
undefined8 SET_ENTITY_LOD_DIST(undefined4 param_1,undefined4 param_2);  // 0x76d60
undefined8 SET_ENTITY_HAS_GRAVITY__guess_76d90(undefined4 param_1,undefined4 param_2);  // 0x76d90
undefined8 SET_ENTITY_DYNAMIC__guess(undefined4 param_1,undefined4 param_2);  // 0x76dc0
undefined8 DELETE_OBJECT_76df0(undefined8 param_1);  // 0x76df0
undefined8 FUN_00076e10(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x76e10
undefined8 FUN_00076e80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9);  // 0x76e80
undefined8 FUN_00076ef0(long param_1);  // 0x76ef0
undefined8 FUN_00076fa0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, long param_5,undefined4 param_6);  // 0x76fa0
undefined8 FUN_00077150(long param_1);  // 0x77150
undefined8 FUN_000771a0(float param_1,undefined4 param_2,undefined4 param_3,long param_4,float *param_5, long param_6,int param_7);  // 0x771a0
undefined8 FUN_00077320(long param_1,int param_2);  // 0x77320
undefined8 FUN_000773e0(int param_1);  // 0x773e0
undefined8 CAN_CREATE_RANDOM_PED__guess(undefined4 param_1);  // 0x774b0
undefined8 FUN_000774d0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x774d0
undefined8 SET_PED_TO_RAGDOLL__guess_77510(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7);  // 0x77510
undefined8 DELETE_PED_77560(undefined8 param_1);  // 0x77560
undefined8 REMOVE_SCRIPT_FIRE__guess(undefined4 param_1);  // 0x77580
undefined8 FUN_000775a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x775a0
undefined8 FUN_000775f0(undefined4 param_1,undefined8 param_2);  // 0x775f0
int FUN_00077620(undefined4 param_1,long param_2,int param_3);  // 0x77620
undefined8 IS_ENTITY_A_VEHICLE_779c0(undefined4 param_1);  // 0x779c0
undefined8 FUN_000779e0(undefined4 param_1);  // 0x779e0
undefined8 NETWORK_HAS_CONTROL_OF_ENTITY_77a20(undefined4 param_1);  // 0x77a20
undefined8 GET_PED_NEARBY_VEHICLES__guess(undefined4 param_1,undefined8 param_2);  // 0x77a40
undefined8 IS_PED_IN_ANY_VEHICLE_77a70(undefined4 param_1,undefined4 param_2);  // 0x77a70
undefined8 GET_VEHICLE_PED_IS_IN_77aa0(undefined4 param_1,undefined4 param_2);  // 0x77aa0
undefined8 NETWORK_REQUEST_CONTROL_OF_ENTITY_77ad0(undefined4 param_1);  // 0x77ad0
float FUN_00077af0(void);  // 0x77af0
int FUN_00077b10(int param_1,long param_2,int param_3);  // 0x77b10
undefined8 GET_PED_NEARBY_PEDS_77ef0(undefined4 param_1,undefined8 param_2,undefined4 param_3);  // 0x77ef0
undefined8 IS_PED_A_PLAYER_77f20(undefined4 param_1);  // 0x77f20
undefined8 IS_PED_DEAD_OR_DYING__guess_77f40(undefined4 param_1,undefined4 param_2);  // 0x77f40
undefined8 FUN_00077f70(int param_1);  // 0x77f70
undefined8 CLONE_PED(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x78040
undefined8 SET_PED_CAN_BE_TARGETTED_78080(undefined4 param_1,undefined4 param_2);  // 0x78080
undefined8 SET_BLOCKING_OF_NON_TEMPORARY_EVENTS_780b0(undefined4 param_1,undefined4 param_2);  // 0x780b0
undefined8 SET_PED_COMBAT_ABILITY_780e0(undefined4 param_1,undefined4 param_2);  // 0x780e0
undefined8 SET_PED_COMBAT_ATTRIBUTES__guess_78110(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x78110
undefined8 SET_PED_KEEP_TASK__guess_78140(undefined4 param_1,undefined4 param_2);  // 0x78140
undefined8 ADD_ARMOUR_TO_PED__guess_78170(undefined4 param_1,undefined4 param_2);  // 0x78170
undefined8 GIVE_WEAPON_TO_PED_781a0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x781a0
undefined8 FUN_000781e0(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x781e0
undefined8 REGISTER_TARGET__guess(undefined4 param_1,undefined4 param_2);  // 0x78210
undefined8 TASK_SEEK_COVER_FROM_PED__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x78240
undefined8 FUN_00078280(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12, undefined4 param_13,undefined4 param_14);  // 0x78280
undefined8 FUN_00078320(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5);  // 0x78320
undefined8 FUN_00078370(undefined4 param_1,undefined4 param_2,float param_3,undefined4 param_4, undefined4 param_5,byte param_6);  // 0x78370
undefined8 FUN_00078500(undefined4 param_1);  // 0x78500
undefined8 FUN_000787d0(float param_1,float param_2,float param_3,undefined4 param_4,byte param_5);  // 0x787d0
undefined8 EXPLODE_VEHICLE__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x78930
undefined1 FUN_00078960(undefined4 param_1,undefined4 param_2,byte param_3);  // 0x78960
undefined8 FUN_00078b30(void);  // 0x78b30
undefined8 SET_PED_AS_ENEMY__guess(undefined4 param_1,undefined4 param_2);  // 0x78bf0
undefined8 FUN_00078c20(undefined4 param_1,undefined4 param_2);  // 0x78c20
undefined8 GET_PED_IN_VEHICLE_SEAT_78c50(undefined4 param_1,undefined4 param_2,undefined4 param_3);  // 0x78c50
undefined8 FUN_00078c80(undefined4 param_1,undefined4 param_2);  // 0x78c80
undefined8 FUN_00078cb0(undefined4 param_1,undefined4 param_2);  // 0x78cb0
undefined8 FUN_00078ce0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x78ce0
undefined8 SMASH_VEHICLE_WINDOW__guess(undefined4 param_1,undefined4 param_2);  // 0x78d20
undefined8 SET_VEHICLE_CUSTOM_PRIMARY_COLOUR_78d50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x78d50
undefined8 SET_VEHICLE_CUSTOM_SECONDARY_COLOUR_78d90(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4);  // 0x78d90
undefined8 _CREATE_LIGHTNING_THUNDER__guess(void);  // 0x78dd0
undefined8 invoke_p_fffifiifi(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8, undefined4 param_9,undefined4 param_10);  // 0x78de0
undefined8 invoke_i_fffii(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4, undefined4 param_5,undefined4 param_6);  // 0x78e90
undefined8 invoke_p_sf(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x78f00
undefined8 invoke_p_iiif(undefined4 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4, undefined4 param_5);  // 0x78f50
ulong FUN_00078fb0(undefined8 param_1,long param_2,ulong param_3);  // 0x78fb0
undefined8 FUN_00079050(long param_1,undefined8 *param_2,undefined8 param_3);  // 0x79050
undefined8 FUN_000790b0(long param_1,undefined4 *param_2,int param_3);  // 0x790b0
undefined8 FUN_00079110(undefined8 param_1,long param_2);  // 0x79110
undefined8 FUN_00079130(int *param_1,undefined8 param_2,undefined8 param_3);  // 0x79130
undefined8 FUN_000791c0(undefined4 *param_1,void *param_2,long param_3);  // 0x791c0
undefined8 FUN_000793d0(long param_1,void *param_2,long param_3);  // 0x793d0
undefined8 FUN_000795b0(int *param_1);  // 0x795b0
undefined8 FUN_000796e0(undefined4 *param_1,undefined4 param_2);  // 0x796e0
undefined8 FUN_00079790(long param_1);  // 0x79790
undefined8 FUN_000797c0(void);  // 0x797c0
undefined8 FUN_000797e0(undefined8 param_1,undefined8 param_2);  // 0x797e0
undefined8 FUN_00079810(undefined8 param_1);  // 0x79810
undefined4 FUN_00079830(long param_1);  // 0x79830
undefined8 FUN_00079870(undefined8 param_1);  // 0x79870
undefined8 FUN_00079890(undefined8 param_1);  // 0x79890
undefined8 FUN_000798b0(char *param_1,char *param_2);  // 0x798b0
undefined8 FUN_00079930(char *param_1,int param_2);  // 0x79930
byte FUN_00079990(byte *param_1,byte *param_2);  // 0x79990
undefined8 FUN_0007a850(undefined8 param_1,undefined8 param_2,ulong param_3);  // 0x7a850
undefined8 FUN_0007a880(undefined4 param_1,undefined8 param_2,undefined8 param_3);  // 0x7a880
undefined8 FUN_0007a8b0(undefined8 param_1,undefined8 param_2);  // 0x7a8b0
#ifdef __cplusplus
}
#endif

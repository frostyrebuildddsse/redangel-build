// main.c - auto-converted from Ghidra decompilation of LushModz-Expulsion-1.57.prx
#include "ghidra_types.h"
#include "ps4_imports.h"
#include "globals.h"
#include "natives157.h"
#include "invoker.h"
#include "functions.h"

// notify_icon @ 0x80  (export NID b3EiYgMPQFg)
undefined8 notify_icon(char *param_1,char *param_2)

{
  undefined4 local_c48 [4];
  undefined4 local_c38;
  undefined4 local_c20;
  undefined1 local_c1c;
  char acStack_c1b [1024];
  char acStack_81b [2051];
  char *local_18;
  char *local_10;
  
  local_18 = param_2;
  local_10 = param_1;
  memset(local_c48,0,0xc30);
  local_c48[0] = 0;
  local_c20 = 0;
  local_c1c = 1;
  local_c38 = 0xffffffff;
  strcpy(acStack_c1b,local_18);
  strcpy(acStack_81b,local_10);
  sceKernelSendNotificationRequest(0,local_c48,0xc30,0);
  return 0;
}

// Notify @ 0x120  (export NID vg0RlbnufGc = Notify)
undefined8 Notify(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8, char *param_9,char *param_10,undefined8 param_11,undefined8 param_12, undefined8 param_13,undefined8 param_14)

{
  uint8_t stack0x00000008[4096];
  char in_AL;
  undefined1 local_d18 [16];
  undefined8 local_d08;
  undefined8 local_d00;
  undefined8 local_cf8;
  undefined8 local_cf0;
  undefined8 local_ce8;
  undefined8 local_cd8;
  undefined8 local_cc8;
  undefined8 local_cb8;
  undefined8 local_ca8;
  undefined8 local_c98;
  undefined8 local_c88;
  undefined8 local_c78;
  undefined4 local_c68;
  undefined4 local_c64;
  undefined1 *local_c60;
  undefined1 *local_c58;
  undefined4 local_c48 [4];
  undefined4 local_c38;
  undefined4 local_c20;
  undefined1 local_c1c;
  char local_c1b [1024];
  char local_81b [2051];
  char *local_18;
  char *local_10;
  
  if (in_AL != '\0') {
    local_ce8 = param_1;
    local_cd8 = param_2;
    local_cc8 = param_3;
    local_cb8 = param_4;
    local_ca8 = param_5;
    local_c98 = param_6;
    local_c88 = param_7;
    local_c78 = param_8;
  }
  local_d08 = param_11;
  local_d00 = param_12;
  local_cf8 = param_13;
  local_cf0 = param_14;
  local_18 = param_10;
  local_10 = param_9;
  memset(local_c48,0,0xc30);
  local_c58 = local_d18;
  local_c60 = stack0x00000008;
  local_c64 = 0x30;
  local_c68 = 0x10;
  vsprintf(local_c1b,local_18,&local_c68);
  local_c48[0] = 0;
  local_c20 = 0;
  local_c1c = 1;
  local_c38 = 0xffffffff;
  strcpy(local_81b,local_10);
  sceKernelSendNotificationRequest(0,local_c48,0xc30,0);
  return 0;
}

// setVectors @ 0x260  (export NID kJWIDwuetUI)
undefined8 setVectors(void)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined4 local_20;
  undefined4 uStack_1c;
  undefined4 local_18;
  
  while (DAT_0017f458 != 0) {
    DAT_0017f458 = DAT_0017f458 - 1;
    puVar1 = *(undefined4 **)(DAT_0017f460 + (ulong)DAT_0017f458 * 8);
    uVar2 = *(undefined8 *)(&DAT_0017f480 + (ulong)DAT_0017f458 * 0x10);
    uVar3 = *(undefined8 *)(DAT_0017f488 + (ulong)DAT_0017f458 * 0x10);
    local_20 = (undefined4)uVar2;
    *puVar1 = local_20;
    uStack_1c = (undefined4)((ulong)uVar2 >> 0x20);
    puVar1[2] = uStack_1c;
    local_18 = (undefined4)uVar3;
    puVar1[4] = local_18;
  }
  return 0;
}

// callHash @ 0x310  (export NID nvazCBPW2-s)
undefined8 callHash(long param_1)

{
  ((GH_FN)((param_1 + 0x400000)))(nativeArg);
  return 0;
}

// resetArgs @ 0x340  (export NID 9xKII-EM+gg)
undefined8 resetArgs(void)

{
  int local_c;
  
  DAT_0017f448 = 0;
  DAT_0017f458 = 0;
  memcpy(nativeArg, &(DAT_0017f4c0), sizeof(nativeArg));
  DAT_0017f450 = DAT_0017f4c0;
  for (local_c = 0; local_c < 0x20; local_c = local_c + 1) {
    *(undefined8 *)(DAT_0017f4c0 + (long)local_c * 8) = 0;
  }
  return 0;
}

// FUN_000003c0 @ 0x3c0  (export NID EtahUzi40u4)
undefined8 FUN_000003c0(void)

{
  return 0;
}

// plugin_load @ 0x3d0  (export NID uceZ3OBMwsg = plugin_load)
undefined8 plugin_load(undefined4 param_1,undefined8 param_2)

{
  uint uVar1;
  ulong uVar2;
  void *local_20;
  undefined8 local_18;
  undefined4 local_c;
  
  local_18 = param_2;
  local_c = param_1;
  printf("[GoldHEN] %s Plugin Started.\n",g_pluginName);
  printf("[GoldHEN] <%s\\Ver.0x%08x> %s\n",g_pluginName,(ulong)g_pluginVersion,"plugin_load");
  printf("[GoldHEN] Plugin Author(s): %s\n",g_pluginAuthor);
  printf("Commit: %s Branch: %s Build: %i %s\n","local","gta_notify",1,"(Release)");
  printf("Built: %s\n","28/09/2026 19:50:13.04");
  printf("GoldHEN SDK Ver: 0x%08x\n",0x100);
  uVar1 = FUN_000797c0();
  printf("GoldHEN System SDK Ver: 0x%08x\n",(ulong)uVar1);
  printf("%s:%d HOOK32() Create sceVideoOutSetFlipRate\n","plugin_load",0xf3);
  FUN_000796e0(g_flipRateHook, 1);
  FUN_00079130(g_flipRateHook, 0, 0x3c0);
  printf(
        "[gta_notify] 60fps unlock: sceVideoOutSetFlipRate hooked (disable Patch Manager GTA 60 FPS Unlock)\n"
        );
  uVar2 = install_cam_hook();
  if ((uVar2 & 1) == 0) {
    printf("[gta_notify] stub hook failed - menu disabled\n");
  }
  printf("[gta_notify] plugin_load OK (notify delayed=%d draw_proof=%d arm=%ds unlock60=%d)\n",1,1,5
        );
  uVar1 = scePthreadCreate(&local_20,(void *)0x0,menu_arm_thread,(void *)0x0,"gta_notify_delay");
  if (uVar1 != 0) {
    printf("[gta_notify] scePthreadCreate failed: 0x%08x\n",(ulong)uVar1);
  }
  return 0;
}

// install_cam_hook @ 0x570
undefined1 install_cam_hook(void)

{
  ulong uVar1;
  long lVar2;
  undefined1 local_9;
  
  uVar1 = FUN_000007d0(&DAT_00d91400);
  if ((uVar1 & 1) == 0) {
    printf("[gta_notify] REFUSE DOES_CAM_EXIST @0x%llx bytes %02X %02X %02X %02X\n",&DAT_00d91400,
           (ulong)DAT_00d91400,(ulong)DAT_00d91401,(ulong)DAT_00d91402,(ulong)DAT_00d91403);
    local_9 = 0;
  }
  else {
    DAT_0017f608 = 0;
    lVar2 = FUN_0000dbe0(&DAT_00d91400, 0x800, 0xf);
    if (lVar2 == 0) {
      printf("[gta_notify] DOES_CAM_EXIST trampoline failed\n");
      local_9 = 0;
    }
    else {
      DAT_0017f618 = 1;
      DAT_0017f610 = lVar2;
      printf("[gta_notify] stub DOES_CAM_EXIST hook @0x%llx (menu inert, orig trampoline)\n",
             &DAT_00d91400);
      local_9 = 1;
    }
  }
  return local_9;
}

// menu_arm_thread @ 0x660
undefined8 menu_arm_thread(void)

{
  printf("[gta_notify] menu arm delay %d s (stub already installed)\n",5);
  FUN_00000970(5);
  notify_icon("cxml://psnotification/tex_icon_system", "~r~Red Angel~s~ Mod Menu");
  notify_icon("cxml://psnotification/tex_icon_system", "~r~Red Angel~s~  |  Credits: FrostyTheOne");
  if ((DAT_0017f618 & 1) == 0) {
    printf("[gta_notify] no stub hook - skip menu arm\n");
    scePthreadExit(0);
  }
  else {
    menu_settings_load();
    FUN_0001bf10();
    FUN_0005a6d0();
    DAT_0017f608 = 1;
    printf("[gta_notify] menu armed\n");
    scePthreadExit(0);
  }
  return 0;
}

// plugin_unload @ 0x740  (export NID -ogSa91YeZg = plugin_unload)
undefined8 plugin_unload(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4, undefined8 param_5,undefined8 param_6)

{
  FUN_00079790(g_flipRateHook);
  printf("[GoldHEN] <%s\\Ver.0x%08x> %s\n",g_pluginName,(ulong)g_pluginVersion,"plugin_unload"); /* BUG-FIX: removed stray params_5,6,2 */
  printf("[GoldHEN] %s Plugin Ended.\n",g_pluginName);
  return 0;
}

// FUN_000007b0 @ 0x7b0
undefined8 FUN_000007b0(void)

{
  return 0;
}

// FUN_000007c0 @ 0x7c0
undefined8 FUN_000007c0(void)

{
  return 0;
}

// FUN_000007d0 @ 0x7d0
bool FUN_000007d0(int *param_1)

{
  return *param_1 == -0x1a76b7ab;
}

// FUN_00000800 @ 0x800
undefined8 FUN_00000800(undefined8 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (((DAT_0017f608 & 1) == 0) || ((DAT_0017f619 & 1) != 0)) {
    FUN_00000900(param_1);
  }
  else {
    DAT_0017f619 = 1;
    iVar1 = GET_FRAME_COUNT();
    if (iVar1 == DAT_0017c04c) {
      FUN_0005a950();
      menu_anti_lockon_tick();
      FUN_00001810();
      FUN_000417f0();
      FUN_0000de10();
      DAT_0017f619 = 0;
      FUN_00000900(param_1);
    }
    else {
      DAT_0017c04c = iVar1;
      uVar2 = PLAYER_PED_ID();
      iVar1 = DOES_ENTITY_EXIST(uVar2);
      if (iVar1 == 0) {
        menu_session_guard_tick();
        menu_recovery_tick();
        menu_rockstar_tick();
        DAT_0017f619 = 0;
        FUN_00000900(param_1);
      }
      else {
        FUN_00015620();
        menu_session_guard_tick();
        FUN_0005b1c0();
        menu_netevents_tick();
        menu_monitor_buttons();
        FUN_0000b740();
        DAT_0017f619 = 0;
        FUN_00000900(param_1);
      }
    }
  }
  return 0;
}

// FUN_00000900 @ 0x900
undefined8 FUN_00000900(undefined8 param_1)

{
  if (DAT_0017f610 != (code *)0x0) {
    ((GH_FN)(DAT_0017f610))(param_1);
  }
  return 0;
}

// GET_FRAME_COUNT @ 0x930
undefined8 GET_FRAME_COUNT(void)

{
  invoke_i_void(N_GET_FRAME_COUNT);
  return 0;
}

// PLAYER_PED_ID @ 0x940
undefined8 PLAYER_PED_ID(void)

{
  invoke_i_void(N_PLAYER_PED_ID);
  return 0;
}

// DOES_ENTITY_EXIST @ 0x950
undefined8 DOES_ENTITY_EXIST(undefined4 param_1)

{
  invoke_i_i(N_DOES_ENTITY_EXIST, param_1);
  return 0;
}

// FUN_00000970 @ 0x970
undefined8 FUN_00000970(uint param_1)

{
  undefined4 local_10;
  
  for (local_10 = 0; local_10 < param_1; local_10 = local_10 + 1) {
    sceKernelUsleep(1000000);
  }
  return 0;
}

// invoke_i_void @ 0x9b0  (export NID u8bM+3AHDMU)
undefined8 invoke_i_void(undefined8 param_1)

{
  resetArgs();
  callHash(param_1);
  setVectors();
  getReturn_int();
  return 0;
}

// getReturn_int @ 0x9e0  (export NID ev1IktWJZG8)
undefined4 getReturn_int(void)

{
  return *nativeArg;
}

// invoke_i_i @ 0xa00  (export NID XtWMjv1YNww)
undefined8 invoke_i_i(undefined8 param_1,undefined4 param_2)

{
  resetArgs();
  pushArg_int(param_2);
  callHash(param_1);
  setVectors();
  getReturn_int();
  return 0;
}

// pushArg_int @ 0xa40  (export NID zD83+F8pH3s)
undefined8 pushArg_int(undefined4 param_1)

{
  *(undefined8 *)(DAT_0017f450 + (ulong)DAT_0017f448 * 8) = 0;
  *(undefined4 *)(DAT_0017f450 + (ulong)DAT_0017f448 * 8) = param_1;
  DAT_0017f448 = DAT_0017f448 + 1;
  return 0;
}

// menu_print @ 0xaa0  (export NID PDo60KST05o = menu_print(char const*))
undefined8 menu_print(undefined8 param_1)

{
  BEGIN_TEXT_COMMAND_PRINT("STRING");
  ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(param_1);
  END_TEXT_COMMAND_PRINT(2000, 1);
  return 0;
}

// BEGIN_TEXT_COMMAND_PRINT @ 0xae0
undefined8 BEGIN_TEXT_COMMAND_PRINT(undefined8 param_1)

{
  invoke_p_s(N_BEGIN_TEXT_COMMAND_PRINT, param_1);
  return 0;
}

// ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME @ 0xb00
undefined8 ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(undefined8 param_1)

{
  invoke_p_s(N_ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME, param_1);
  return 0;
}

// END_TEXT_COMMAND_PRINT @ 0xb20
undefined8 END_TEXT_COMMAND_PRINT(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_END_TEXT_COMMAND_PRINT, param_1, param_2);
  return 0;
}

// FUN_00000b50 @ 0xb50  (export NID lqEArEGhiHg)
undefined8 FUN_00000b50(void)

{
  undefined4 uVar1;
  
  g_wantedLevel = 0;
  g_YVAkQYPK6ss = 0;
  g_Tu4a3HQuo94 = 0;
  uVar1 = PLAYER_ID();
  CLEAR_PLAYER_WANTED_LEVEL(uVar1);
  menu_print("~g~Wanted level cleared");
  return 0;
}

// CLEAR_PLAYER_WANTED_LEVEL @ 0xb90
undefined8 CLEAR_PLAYER_WANTED_LEVEL(undefined4 param_1)

{
  invoke_p_i(N_CLEAR_PLAYER_WANTED_LEVEL, param_1);
  return 0;
}

// PLAYER_ID @ 0xbb0
undefined8 PLAYER_ID(void)

{
  invoke_i_void(N_PLAYER_ID);
  return 0;
}

// FUN_00000bc0 @ 0xbc0  (export NID ZGk0znsakbM)
undefined8 FUN_00000bc0(void)

{
  undefined4 uVar1;
  undefined4 local_c;
  
  local_c = g_wantedLevel;
  if (g_wantedLevel < 0) {
    local_c = 0;
  }
  if (5 < local_c) {
    local_c = 5;
  }
  g_wantedLevel = local_c;
  g_YVAkQYPK6ss = 0;
  g_Tu4a3HQuo94 = 0;
  uVar1 = PLAYER_ID();
  SET_MAX_WANTED_LEVEL__guess(5);
  SET_POLICE_IGNORE_PLAYER__guess(uVar1, 0);
  SET_DISPATCH_COPS_FOR_PLAYER__guess(uVar1, 1);
  SET_PLAYER_WANTED_LEVEL__guess(uVar1, local_c, 0);
  SET_PLAYER_WANTED_LEVEL_NOW(uVar1, 0);
  return 0;
}

// SET_MAX_WANTED_LEVEL__guess @ 0xc60
undefined8 SET_MAX_WANTED_LEVEL__guess(undefined4 param_1)

{
  invoke_p_i(N_SET_MAX_WANTED_LEVEL__guess, param_1);
  return 0;
}

// SET_POLICE_IGNORE_PLAYER__guess @ 0xc80
undefined8 SET_POLICE_IGNORE_PLAYER__guess(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_SET_POLICE_IGNORE_PLAYER__guess, param_1, param_2);
  return 0;
}

// SET_DISPATCH_COPS_FOR_PLAYER__guess @ 0xcb0
undefined8 SET_DISPATCH_COPS_FOR_PLAYER__guess(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_SET_DISPATCH_COPS_FOR_PLAYER__guess, param_1, param_2);
  return 0;
}

// SET_PLAYER_WANTED_LEVEL__guess @ 0xce0
undefined8 SET_PLAYER_WANTED_LEVEL__guess(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  invoke_p_iii(N_SET_PLAYER_WANTED_LEVEL__guess, param_1, param_2, param_3);
  return 0;
}

// SET_PLAYER_WANTED_LEVEL_NOW @ 0xd10
undefined8 SET_PLAYER_WANTED_LEVEL_NOW(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_SET_PLAYER_WANTED_LEVEL_NOW, param_1, param_2);
  return 0;
}

// FUN_00000d40 @ 0xd40  (export NID F9z8-yakTpI)
undefined8 FUN_00000d40(void)

{
  undefined4 uVar1;
  int local_4c;
  char local_48 [60];
  uint local_c;
  
  local_c = 0;
  uVar1 = GET_HASH_KEY("MPPLY_LAST_MP_CHAR");
  STAT_GET_INT(uVar1, &local_c, 0xffffffff);
  if (((int)local_c < 0) || (1 < (int)local_c)) {
    local_c = 0;
  }
  for (local_4c = 0; local_4c < 6; local_4c = local_4c + 1) {
    snprintf(local_48,0x30,"MP%d_%s",(ulong)local_c,(PTR_s_CHAR_ABILITY_1_UNLCK_0017c050)[local_4c]
            );
    uVar1 = GET_HASH_KEY(local_48);
    STAT_SET_INT(uVar1, 0xffffffff, 1);
  }
  menu_print("~g~Fast Run unlocked");
  return 0;
}

// STAT_GET_INT @ 0xe00
undefined8 STAT_GET_INT(undefined4 param_1,undefined8 param_2,undefined4 param_3)

{
  invoke_i_ipii(N_STAT_GET_INT, param_1, param_2, param_3);
  return 0;
}

// GET_HASH_KEY @ 0xe30
undefined8 GET_HASH_KEY(undefined8 param_1)

{
  invoke_i_s(N_GET_HASH_KEY, param_1);
  return 0;
}

// STAT_SET_INT @ 0xe50
undefined8 STAT_SET_INT(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  invoke_i_iii(N_STAT_SET_INT, param_1, param_2, param_3);
  return 0;
}

// FUN_00000e80 @ 0xe80  (export NID HmbAY8-WzwQ)
undefined8 FUN_00000e80(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = PLAYER_PED_ID_00f10();
  uVar2 = PLAYER_ID();
  iVar3 = DOES_ENTITY_EXIST_00f20(uVar1);
  if (iVar3 != 0) {
    uVar4 = GET_ENTITY_MAX_HEALTH(uVar1);
    SET_ENTITY_HEALTH(uVar1, uVar4, 0);
    SET_PLAYER_MAX_ARMOUR__guess(uVar2, 100);
    SET_PED_ARMOUR(uVar1, 100);
    CLEAR_PED_BLOOD_DAMAGE(uVar1);
    RESET_PED_VISIBLE_DAMAGE(uVar1);
    CLEAR_PED_WETNESS(uVar1);
    menu_print("~g~Healed");
  }
  return 0;
}

// PLAYER_PED_ID_00f10 @ 0xf10
undefined8 PLAYER_PED_ID_00f10(void)

{
  invoke_i_void(N_PLAYER_PED_ID);
  return 0;
}

// DOES_ENTITY_EXIST_00f20 @ 0xf20
undefined8 DOES_ENTITY_EXIST_00f20(undefined4 param_1)

{
  invoke_i_i(N_DOES_ENTITY_EXIST, param_1);
  return 0;
}

// GET_ENTITY_MAX_HEALTH @ 0xf40
undefined8 GET_ENTITY_MAX_HEALTH(undefined4 param_1)

{
  invoke_i_i(N_GET_ENTITY_MAX_HEALTH, param_1);
  return 0;
}

// SET_ENTITY_HEALTH @ 0xf60
undefined8 SET_ENTITY_HEALTH(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  invoke_p_iii(N_SET_ENTITY_HEALTH, param_1, param_2, param_3);
  return 0;
}

// SET_PLAYER_MAX_ARMOUR__guess @ 0xf90
undefined8 SET_PLAYER_MAX_ARMOUR__guess(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_SET_PLAYER_MAX_ARMOUR__guess, param_1, param_2);
  return 0;
}

// SET_PED_ARMOUR @ 0xfc0
undefined8 SET_PED_ARMOUR(undefined4 param_1,undefined4 param_2)

{
  invoke_p_ii(N_SET_PED_ARMOUR, param_1, param_2);
  return 0;
}

// CLEAR_PED_BLOOD_DAMAGE @ 0xff0
undefined8 CLEAR_PED_BLOOD_DAMAGE(undefined4 param_1)

{
  invoke_p_i(N_CLEAR_PED_BLOOD_DAMAGE, param_1);
  return 0;
}

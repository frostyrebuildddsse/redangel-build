// ghidra_types.h - type shims so Ghidra pseudo-C compiles
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
typedef uint8_t  undefined;  typedef uint8_t  undefined1; typedef uint16_t undefined2; typedef uint32_t undefined3;
typedef uint32_t undefined4; typedef uint64_t undefined5; typedef uint64_t undefined6; typedef uint64_t undefined7; typedef uint64_t undefined8;
typedef uint8_t  byte; typedef uint8_t uchar; typedef uint16_t ushort; typedef uint32_t uint; typedef uint64_t ulong;
typedef uint64_t ulonglong; typedef int64_t longlong; typedef int16_t sshort; typedef long double float10;
typedef void code; typedef void *pointer; typedef uint32_t dword; typedef uint16_t word; typedef uint64_t qword;
typedef long (*GH_FN)();
typedef union { uint8_t b[16]; uint32_t d[4]; uint64_t q[2]; } GH_VEC;
#define CONCAT11(a,b) ((uint16_t)(((uint16_t)(uint8_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT22(a,b) ((uint32_t)(((uint32_t)(uint16_t)(a)<<16)|(uint16_t)(b)))
#define CONCAT44(a,b) ((uint64_t)(((uint64_t)(uint32_t)(a)<<32)|(uint32_t)(b)))
#define CONCAT13(a,b) ((uint32_t)(((uint32_t)(uint8_t)(a)<<24)|((uint32_t)(b)&0xffffff)))
#define CONCAT31(a,b) ((uint32_t)(((uint32_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT17(a,b) ((uint64_t)(((uint64_t)(uint8_t)(a)<<56)|((uint64_t)(b)&0xffffffffffffffULL)))
#define CONCAT71(a,b) ((uint64_t)(((uint64_t)(a)<<8)|(uint8_t)(b)))
#define CONCAT26(a,b) ((uint64_t)(((uint64_t)(uint16_t)(a)<<48)|((uint64_t)(b)&0xffffffffffffULL)))
#define CONCAT62(a,b) ((uint64_t)(((uint64_t)(a)<<16)|(uint16_t)(b)))
#define CONCAT35(a,b) ((uint64_t)(((uint64_t)(a)<<40)|((uint64_t)(b)&0xffffffffffULL)))
#define CONCAT53(a,b) ((uint64_t)(((uint64_t)(a)<<24)|((uint64_t)(b)&0xffffffULL)))
#define SUB81(x,n) ((uint8_t)((uint64_t)(x)>>((n)*8)))
#define SUB82(x,n) ((uint16_t)((uint64_t)(x)>>((n)*8)))
#define SUB84(x,n) ((uint32_t)((uint64_t)(x)>>((n)*8)))
#define SUB41(x,n) ((uint8_t)((uint32_t)(x)>>((n)*8)))
#define SUB42(x,n) ((uint16_t)((uint32_t)(x)>>((n)*8)))
#define SUB21(x,n) ((uint8_t)((uint16_t)(x)>>((n)*8)))
#define ZEXT18(x) ((uint64_t)(uint8_t)(x))
#define ZEXT14(x) ((uint32_t)(uint8_t)(x))
#define ZEXT12(x) ((uint16_t)(uint8_t)(x))
#define ZEXT24(x) ((uint32_t)(uint16_t)(x))
#define ZEXT28(x) ((uint64_t)(uint16_t)(x))
#define ZEXT48(x) ((uint64_t)(uint32_t)(x))
#define ZEXT416(x) ((uint64_t)(uint32_t)(x))
#define ZEXT816(x) ((uint64_t)(x))
#define SEXT14(x) ((int32_t)(int8_t)(x))
#define SEXT18(x) ((int64_t)(int8_t)(x))
#define SEXT24(x) ((int32_t)(int16_t)(x))
#define SEXT28(x) ((int64_t)(int16_t)(x))
#define SEXT48(x) ((int64_t)(int32_t)(x))
#define halt_baddata() __builtin_trap()
typedef int32_t int3; typedef int64_t int5; typedef int64_t int6; typedef int64_t int7; typedef uint32_t uint3; typedef uint64_t uint5; typedef uint64_t uint6; typedef uint64_t uint7;
#define SQRT(x) __builtin_sqrtf(x)
#define builtin_strncpy(d, s, n) __builtin_memcpy((d), (s), (n))
#define builtin_memcpy(d, s, n) __builtin_memcpy((d), (s), (n))
#define builtin_strcpy(d, s) __builtin_strcpy((d), (s))
static inline void *invalidInstructionException(void) { __builtin_trap(); return 0; }
#define GHF8(x,o)  (*(uint8_t  *)((char*)&(x)+(o)))
#define GHF16(x,o) (*(uint16_t *)((char*)&(x)+(o)))
#define GHF32(x,o) (*(uint32_t *)((char*)&(x)+(o)))
#define GHF64(x,o) (*(uint64_t *)((char*)&(x)+(o)))

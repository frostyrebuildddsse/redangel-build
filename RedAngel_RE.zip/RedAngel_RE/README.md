# Red Angel.prx (Red Angel GTAO Mod Menu, intern `gta_notify`) – RE-Paket

GoldHEN-Plugin für GTA V **1.57** (CUSA00419), OpenOrbis/clang -O0, Windows-Build (`build\gta_notify.elf`,
gebaut 28/09/2026). „Originally by FrostyTheOne“ – basiert auf FrostyTheOnes
PS4-GTA-V-Menu-Base (Invoker 1:1 identisch). Imports: libkernel, libc, libSceSysmodule, libSceRtc, libSceVideoOut.

**Ablauf:** `plugin_load` → hookt `sceVideoOutSetFlipRate` (60-FPS-Unlock) → `install_cam_hook`: prüft Bytes am
Native-Handler DOES_CAM_EXIST (Eboot 0xd91400), legt per Detour ein Trampolin an (Menü-Tick läuft im Hook) →
Thread `gta_notify_delay` wartet 5 s, Notifies, lädt Settings (`menu_settings_load`), armt das Menü.
Natives werden per `callHash(offset)` = `(offset + 0x400000)(&nativeArg)` aufgerufen.

| Pfad | Inhalt |
|---|---|
| `source/` | **kompilierbarer C-Tree** – `make check` fehlerfrei, Host-Compile aller Objekte ok (siehe `source/README.md`) |
| `decompile/redangel_decompiled.c` | Pseudocode aller Funktionen mit allen Namen + `/*NATIVE*/`-Kommentaren |
| `decompile/natives_resolved.json` | 593 genutzte Native-Offsets → Name (202 exakt, 388 interpoliert mit Alternativen, 3 offen) |
| `elf/redangel.elf` / `redangel_ghidra.elf` | entpacktes ELF / Loader-freundlich mit 13.543 angewendeten Relocs |
| `symbols/` | Dynsym, Jump-Tables, Rename-Map, geknackte NIDs |
| `tools/` | Pipeline-Scripts |

**Namen:** 209 Originalnamen per NID-Crack rekonstruiert, Stil `menu_<bereich>_tick/options/count`
(`menu_self_tick`, `menu_recovery_tick`, `menu_player_kick_options`, `menu_spawn_vehicle(const char*)`,
`menu_settings_save`, `menu_teleport_to(float,float,float)` …) und Globals `g_spawn*Options`, `g_tunables*`,
`g_aimbotMode`, `g_noclipSpeed` usw. 1150 Native-Funktionen nach ihrem Native benannt.

**Native-Namen:** exakt = aus der 1.57-Validierungstabelle (aus Expulsion); `__guess` = monotone Interpolation
gegen FrostyTheOnes 1.27-`natives.h` + Argumentanzahl, Leave-one-out-Genauigkeit 89 %.
